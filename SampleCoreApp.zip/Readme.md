# Sample Core App
This is a sample .net Core application
Uses SOLID principle
S - Single-responsibility principle
There should be never more than one reason for a class to change

O - Open-closed principle
Software entities (classes, modules, functions, etc.) should be open for extension, but closed for modification

L - Liskov substitution principle
subtypes must be substitutable for their base types

I	- Interface segregation principle
Classes that implement interfaces, should not be forced to implement methods they do not use

D - Dependency Inversion Principle
High level modules should not depend on low level modules rather both should depend on abstraction. Abstraction should not depend on details; rather detail should depend on abstraction


## Environment

---

Web
> TargetFramework: net5.0  
> Sdk: Microsoft.NET.Sdk.Web  

Class libraries 
> TargetFramework: netstandard2.0  
> Sdk: Microsoft.NET.Sdk  
 
## Installation

---
These packages will be automatically added to the solution is compiled.  
Install the packages only if the they are not installed automaticallly  
using the syntax in the package manager console Install-Package packagename -Version X.X..

>Install the following packages in the .Infrastructure.Base project 

>>Microsoft.Extensions.Logging.Debug -Version 3.0.0  
>>Newtonsoft.Json -Version 12.0.3  
>>Microsoft.EntityFrameworkCore.SqlServer -Version 3.0.0  
>>Microsoft.EntityFrameworkCore.Tools -Version 3.0.0  
>>Swashbuckle.AspNetCore -Version 5.6.3  
>>Microsoft.VisualStudio.Web.BrowserLink -Version 2.2.0

>Install the following packages in the .Infrastructure project 
>>Microsoft.Extensions.Caching.Memory -Version 5.0.0

>Install the following packages in the .UnitOfWork project 
>>AutoMapper -Version 10.1.1

>Install the following packages in the .Web project 

>>Microsoft.AspNetCore.Mvc.Core -Version 2.2.5  
>>Microsoft.AspNetCore.Mvc.ViewFeatures -Version 2.2.0  
>>Microsoft.AspNetCore.Razor -Version 2.2.0  
>>Microsoft.CSharp -Version 4.7.0  
>>Newtonsoft.Json -Version 12.0.3  
>>System.Data.SqlClient -Version 4.8.1  
>>Microsoft.Extensions.Configuration.Abstractions -Version 3.1.3  
>>Microsoft.Extensions.Options -Version 3.1.3  
>>Microsoft.AspNetCore.Authentication.MicrosoftAccount -Version 5.0.0
>>Microsoft.AspNetCore.Authentication.Google -Version 5.0.0
>>Microsoft.Extensions.Caching.Memory -Version 5.0.0

> Database Scripts 
>> Executet the db related scripts from the Data folder

> Client Side libraries
>>bootstrap 4.3.1
>>font-awesome-4.7.0
>>jquery 3.5.1
>>jqueryui 1.12.1
>>jquery-validation 1.17.0
>>jquery-validation-unobtrusive 3.2.11

## Usage

---
>Instructions for models
>>Models are to 1 to 1 with columns from database (tables/procedures/views)  
>>Each model should inherit from BaseModel  
>>Each property in model should have the DbColumnName attribute if it has to be mapped to database column  

Example:  
    [Serializable]  
   public class EmployeeModel : BaseModel  
    {  
        [DbColumnName("employee_id")]  
        public int? EmployeeId { get; set; }  
    ...  
    }  
>Instructions for Dto's  
>> Dto's should be used in the view instead of models if the number of columns in the model are  
 more in the and we have to show only few columns in the view  
>> Dto's may or may not inherit from ParentModel(EmployeeModel)  
>> Model can be converted to Dto using Automapper/Linq  
  
Example:  
  [Serializable]   
   public class EmployeeDto  
   {  
   
   }  
     
>Instructions for ViewModels  
>> Should inherit from BaseViewModel
>> ViewModels will include the Models & Dto's  
>> Only ViewModels should be sent to View  
  
Example:  
    [Serializable]  
    public class EmployeeViewModel : BaseViewModel  
    {  
        public List<EmployeeModel> EmployeeModels { get; set; } //populating the grid  
  
        public EmployeeModel EmployeeModel { get; set; }//used for search/add/edit...  
  
        public SelectList DepartmentLookupModel { get; set; }//Populating the selectlist  
  
        public SelectList JobLookupModel { get; set; }//Populating the selectlist    
    }  

>Instructions to use automapper  
  Example:  
    //Initialize the mapper  
    var config = new MapperConfiguration(cfg =>  
            cfg.CreateMap<Employee, EmployeeDTO>()  
        );  
        or  
    //Initialize the mapper with different properties 
    var config = new MapperConfiguration(cfg =>  
            cfg.CreateMap<Employee, EmployeeDTO>()  
            .ForMember(dest => dest.FullName, act => act.MapFrom(src => src.Name))  
            .ForMember(dest => dest.Dept, act => act.MapFrom(src => src.Department))  
        );  

    //Creating the source object  
    Employee emp = new Employee  
    {
        Name = "James",  
        Salary = 20000,  
        Address = "London",  
        Department = "IT"  
    };  
    //Using automapper  
    var mapper = new Mapper(config);  
    var empDTO = mapper.Map<EmployeeDTO>(emp);  
  
>Unobstrucive Validation  
>>Set the attributes in the model  
     Example:   [Serializable]  
    public class EmployeeModel : BaseModel  
    {  
        [DbColumnName("first_name")]  
        [Required(AllowEmptyStrings =false, ErrorMessage ="First Name is required")]  
        public string FirstName { get; set; }  
        ...  
    }  
>>On load of form set the form in Unobstrusive mode using function SetFormUnobstrusiveMode in the markup  
>>Onclick of Save/Approve.... check for valid form using ValidateFormUnobstrusiveModeByClass.  
No need to call this function if the button type is submit  

## Contributing

1. Fork it!
2. Create your feature branch: `git checkout -b my-new-feature`
3. Commit your changes: `git commit -am 'Add some feature'`
4. Push to the branch: `git push origin my-new-feature`
5. Submit a pull request :D

## History

TODO: Write history

## Credits

Santosh Kumar Janapala

## License

TODO: Write license