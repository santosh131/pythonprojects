﻿using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using SampleCoreApp.Infrastructure.Base.ApplicationHelpers;
using SampleCoreApp.Infrastructure.Base.Interfaces;
using SampleCoreApp.Infrastructure.Base.Models;
using SampleCoreApp.Interfaces.Repositories;
using SampleCoreApp.Models.Models.SampleModuleModel;
using SampleCoreApp.Models;
using SampleCoreApp.Interfaces.UnitOfWork;
using SampleCoreApp.Infrastructure.BaseModels;

namespace SampleCoreApp.UnitOfWork
{
    public class DepartmentUnitOfWork : IDepartmentUnitOfWork
    {
        private readonly IDepartmentRepository _departmentRepository;
        public DepartmentUnitOfWork(IDepartmentRepository departmentRepository)
        {
            _departmentRepository = departmentRepository;
        }
        public IDepartmentRepository GetDepartmentRepository()
        {
            return _departmentRepository;
        }

        public List<FieldCodeModel> GetFieldCodeModels()
        {
            throw new NotImplementedException();
        }

        public List<TransactionModel> GetTransactionsModel()
        {
            return new List<TransactionModel>();
        }
    }
}
