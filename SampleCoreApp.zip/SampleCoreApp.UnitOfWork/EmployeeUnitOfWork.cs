﻿using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using SampleCoreApp.Infrastructure.Base.ApplicationHelpers;
using SampleCoreApp.Infrastructure.Base.Interfaces;
using SampleCoreApp.Infrastructure.Base.Models;
using SampleCoreApp.Interfaces.Repositories;
using SampleCoreApp.Models.Models.SampleModuleModel;
using SampleCoreApp.Models;
using SampleCoreApp.Interfaces.UnitOfWork;
using SampleCoreApp.Infrastructure.BaseModels;
using SampleCoreApp.Infrastructure.Constants;
using SampleCoreApp.Infrastructure.ApplicationHelpers;
using Microsoft.AspNetCore.Http;
using SampleCoreApp.Models.ViewModels.SampleModuleViewModels;
using SampleCoreApp.Infrastructure.Base.Constants;

namespace SampleCoreApp.UnitOfWork
{
    public class EmployeeUnitOfWork : RepositoryHelper, IEmployeeUnitOfWork
    {
        private readonly IEmployeeRepository _employeeRepository;
        private readonly ILookupRepository _lookupRepository;

        public EmployeeUnitOfWork(IDbHelper dbHelper,
            IEmployeeRepository employeeRepository, ILookupRepository lookupRepository)
            : base(dbHelper)
        {
            _employeeRepository = employeeRepository;
            _lookupRepository = lookupRepository;
        }

        public List<TransactionModel> GetTransactionsModel()
        {
            List<TransactionModel> transactionsModel = new()
            {
                new TransactionModel { TransactionCode = "", TransactionDescription = "View", IsAllowed = true },
                new TransactionModel { TransactionCode = "", TransactionDescription = "Add", IsAllowed = true }
            };
            return transactionsModel;
        }

        public IEmployeeRepository GetEmployeeRepository()
        {
            return _employeeRepository;
        }

        public ILookupRepository GetLookupRepository()
        {
            return _lookupRepository;
        }

        public List<FieldCodeModel> GetFieldCodeModels()
        {
            List<FieldCodeModel> fieldCodeModels = new();

            fieldCodeModels.AddToFieldCodeModelList("F1000", "PC1000");
            fieldCodeModels.AddToFieldCodeModelList("F1001", "PC1000");
            fieldCodeModels.AddToFieldCodeModelList("F1002", "PC1000");
            fieldCodeModels.AddToFieldCodeModelList("F1003", "PC1000");
            fieldCodeModels.AddToFieldCodeModelList("F1005", "PC1000");
            fieldCodeModels.AddToFieldCodeModelList("F1026", "PC1000");
            fieldCodeModels.AddToFieldCodeModelList("F1015", "PC1000");
            fieldCodeModels.AddToFieldCodeModelList("F1016", "PC1000");
            fieldCodeModels.AddToFieldCodeModelList("F1036", "PC1000");
            fieldCodeModels.AddToFieldCodeModelList("F1037", "PC1000");
            fieldCodeModels.AddToFieldCodeModelList("F1038", "PC1000");
            fieldCodeModels.AddToFieldCodeModelList("F1023", "PC1000");
            fieldCodeModels.AddToFieldCodeModelList("F1039", "PC1000");
            return fieldCodeModels;
        }



        /// <summary>
        /// Gets the EmployeeViewModel
        /// </summary>
        /// <param name="id">Id</param>
        /// <param name="cRUDOperationsConstants">CUDOperationsConstants</param>
        /// <returns></returns>
        public EmployeeViewModel GetEmployeeViewModel(int? id, string crudOperationsConstants)
        {
            EmployeeViewModel employeeViewModel = new();
            EmployeeModel employeeModel = new();
            CommonModel commonModel = new();
            MessageModel messageModel = new();
            List<DepartmentModel> departmentModels;
            commonModel.ActionCode = CRUDOperationsConstants.Get;

            if (id.HasValue)
            {
                employeeModel.EmployeeId = id;
                employeeModel = _employeeRepository.Get(employeeModel, commonModel, ref messageModel);
            } 

            departmentModels = _lookupRepository.GetDepartmentDropdownLookup(new DepartmentModel(), ref commonModel, ref messageModel).ToList();

            if (crudOperationsConstants == CRUDOperationsConstants.Create)
            {
                messageModel.MessageTypeCode = MessageTypeCodeConstants.Success;
            }
            employeeViewModel.MessageModel = messageModel.SetMessageDescriptions();
            employeeViewModel.EmployeeModel = employeeModel;
            employeeViewModel.DepartmentLookupModel = departmentModels.ToSelectList("DepartmentId", "DepartmentName", employeeModel.DepartmentId?.ToString(), "LocationId");
            employeeViewModel.TransactionsModel = GetTransactionsModel();
            return employeeViewModel;
        }

        /// <summary>
        /// Create/Updates/Deletes Operation
        /// </summary>
        /// <param name="employeeViewModel"></param>
        public EmployeeViewModel PostEmployeeViewModel(EmployeeViewModel employeeViewModel, string crudOperationsConstants)
        {
            CommonModel commonModel = new();
            MessageModel messageModel = new();

            commonModel.ActionCode = crudOperationsConstants;

            _employeeRepository.Validate(employeeViewModel.EmployeeModel, commonModel, ref messageModel);

            if (messageModel.MessageTypeCode == MessageTypeCodeConstants.ValidationSuccess)
                _employeeRepository.Save(employeeViewModel.EmployeeModel, commonModel, ref messageModel);

            messageModel.SetMessageDescriptions();

            employeeViewModel.MessageModel = messageModel;

            return employeeViewModel;
        }

    }
}
