﻿using Microsoft.Extensions.DependencyInjection;
using SampleCoreApp.Interfaces.UnitOfWork;
using System;
using System.Collections.Generic;
using System.Text;

namespace SampleCoreApp.UnitOfWork.StartupHelpers
{
    public static class RegisterUnitOfWorkStartup
    {
        /// <summary>
        /// Register Unit of work
        /// </summary>
        /// <param name="services">IServiceCollection</param>
        public static void RegisterUnitOfWork(ref IServiceCollection services)
        {
            services.AddScoped<IHomeUnitOfWork, HomeUnitOfWork>();            
            services.AddScoped<IEmployeeUnitOfWork, EmployeeUnitOfWork>();
            services.AddScoped<ILookupUnitOfWork, LookupUnitOfWork>();
            services.AddScoped<IDepartmentUnitOfWork, DepartmentUnitOfWork>();
        }
    }
}
