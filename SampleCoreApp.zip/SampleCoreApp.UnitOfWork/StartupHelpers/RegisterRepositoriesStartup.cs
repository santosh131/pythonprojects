﻿using Microsoft.Extensions.DependencyInjection;
using SampleCoreApp.Interfaces.Repositories;
using SampleCoreApp.Repositories;
using System;
using System.Collections.Generic;
using System.Text;

namespace SampleCoreApp.UnitOfWork.StartupHelpers
{
    public static class RegisterRepositoriesStartup
    {
        /// <summary>
        /// Registers Repositories
        /// </summary>
        /// <param name="services">IServiceCollection</param>
        public static void ResgisterRepositories(ref IServiceCollection services)
        {
            services.AddScoped<ILookupRepository, LookupRepository>();
            services.AddScoped<IHomeRepository, HomeRepository>();            
            services.AddScoped<IEmployeeRepository, EmployeeRepository>();
            services.AddScoped<IDepartmentRepository, DepartmentRepository>();
        }
    }
}
