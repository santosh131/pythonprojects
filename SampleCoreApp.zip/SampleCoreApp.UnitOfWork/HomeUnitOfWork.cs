﻿using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using SampleCoreApp.Infrastructure.Base.ApplicationHelpers;
using SampleCoreApp.Interfaces.UnitOfWork;
using SampleCoreApp.Interfaces.Repositories;
using SampleCoreApp.Infrastructure.Base.Interfaces;
using SampleCoreApp.Infrastructure.Base.Models;
using SampleCoreApp.Models;
using SampleCoreApp.Models.Models.SampleModuleModel;
using SampleCoreApp.Infrastructure.BaseModels;

namespace SampleCoreApp.UnitOfWork
{
    public class HomeUnitOfWork : RepositoryHelper, IHomeUnitOfWork
    {
        private readonly IHomeRepository _homeRepository;
        private readonly  ILookupRepository _lookupRepository;
        public HomeUnitOfWork(IDbHelper dbHelper,
            IHomeRepository homeRepository, ILookupRepository lookupRepository)
            : base(dbHelper)
        {
            _homeRepository = homeRepository;
            _lookupRepository = lookupRepository;
        }
        public List<TransactionModel> GetTransactionsModel()
        {
            List<TransactionModel> transactionsModel = new()
            {
                new TransactionModel{ TransactionCode= "", TransactionDescription= "View", IsAllowed= true },
                new TransactionModel{TransactionCode= "", TransactionDescription= "Approve", IsAllowed= true }
            };
            return transactionsModel;
        }
         
        public IHomeRepository GetHomeRepository()
        {
            return _homeRepository;
        }

        public ILookupRepository GetLookupRepository()
        {
            return _lookupRepository;
        }

        public List<FieldCodeModel> GetFieldCodeModels()
        {
            throw new NotImplementedException();
        }
    }
}
