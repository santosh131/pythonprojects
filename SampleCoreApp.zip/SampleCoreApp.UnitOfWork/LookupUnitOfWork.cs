﻿using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using SampleCoreApp.Infrastructure.Base.ApplicationHelpers;
using SampleCoreApp.Infrastructure.Base.Interfaces;
using SampleCoreApp.Infrastructure.Base.Models;
using SampleCoreApp.Interfaces.Repositories;
using SampleCoreApp.Models.Models.SampleModuleModel;
using SampleCoreApp.Models;
using SampleCoreApp.Interfaces.UnitOfWork;
using SampleCoreApp.Infrastructure.BaseModels;

namespace SampleCoreApp.UnitOfWork
{
    public class LookupUnitOfWork : RepositoryHelper, ILookupUnitOfWork
    {
        private readonly ILookupRepository _lookupRepository;
        public LookupUnitOfWork(IDbHelper dbHelper,ILookupRepository lookupRepository)
            : base(dbHelper)
        { 
            _lookupRepository = lookupRepository;
        }       

        public ILookupRepository GetLookupRepository()
        {
            return _lookupRepository;
        }

        public List<FieldCodeModel> GetFieldCodeModels()
        {
            throw new NotImplementedException();
        }
        public List<TransactionModel> GetTransactionsModel()
        {
            throw new NotImplementedException();
        }
    }
}
