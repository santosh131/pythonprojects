CREATE TABLE [dbo].[fieldcodes](
	[field_said] [int] IDENTITY(1,1) NOT NULL,
	[field_cd] [nvarchar](10) NOT NULL,
	[field_name_txt] [nvarchar](50) NOT NULL,
	[page_cd] [nvarchar](10) NOT NULL,
	[desc_txt] [nvarchar](200) NOT NULL,
	[mand_ind] [bit] NULL,
	[table_name] [nvarchar](100) NULL,
	[type] [nvarchar](50) NULL,
	[max_width] [int] NULL,
	PRIMARY KEY ([field_said])
) 

 

INSERT [dbo].[fieldcodes] ([field_said], [field_cd], [field_name_txt], [page_cd], [desc_txt], [mand_ind], [table_name], [type]) VALUES (1, N'F1000', N'employee_id', N'PC1000', N'Employee Id', 1, N'employees', N'label')
INSERT [dbo].[fieldcodes] ([field_said], [field_cd], [field_name_txt], [page_cd], [desc_txt], [mand_ind], [table_name], [type]) VALUES (2, N'F1001', N'last_name', N'PC1000', N'Last Name', 1, N'employees', N'label')
INSERT [dbo].[fieldcodes] ([field_said], [field_cd], [field_name_txt], [page_cd], [desc_txt], [mand_ind], [table_name], [type]) VALUES (3, N'F1002', N'first_name', N'PC1000', N'First Name', 1, N'employees', N'label')
INSERT [dbo].[fieldcodes] ([field_said], [field_cd], [field_name_txt], [page_cd], [desc_txt], [mand_ind], [table_name], [type]) VALUES (4, N'F1003', N'email', N'PC1000', N'Email', 1, N'employees', N'label')
INSERT [dbo].[fieldcodes] ([field_said], [field_cd], [field_name_txt], [page_cd], [desc_txt], [mand_ind], [table_name], [type]) VALUES (5, N'F1005', N'phone_number', N'PC1000', N'Phone Number', 0, N'employees', N'label')
INSERT [dbo].[fieldcodes] ([field_said], [field_cd], [field_name_txt], [page_cd], [desc_txt], [mand_ind], [table_name], [type]) VALUES (6, N'F1006', N'hire_date', N'PC1000', N'Hire Date', 0, N'employees', N'label')
INSERT [dbo].[fieldcodes] ([field_said], [field_cd], [field_name_txt], [page_cd], [desc_txt], [mand_ind], [table_name], [type]) VALUES (7, N'F1007', N'job_id', N'PC1000', N'Job Id', 0, N'jobs', N'label')
INSERT [dbo].[fieldcodes] ([field_said], [field_cd], [field_name_txt], [page_cd], [desc_txt], [mand_ind], [table_name], [type]) VALUES (8, N'F1008', N'salary', N'PC1000', N'Salary', 0, N'employees', N'label')
INSERT [dbo].[fieldcodes] ([field_said], [field_cd], [field_name_txt], [page_cd], [desc_txt], [mand_ind], [table_name], [type]) VALUES (9, N'F1009', N'manager_id', N'PC1000', N'Manager Id', 0, N'employees', N'label')
INSERT [dbo].[fieldcodes] ([field_said], [field_cd], [field_name_txt], [page_cd], [desc_txt], [mand_ind], [table_name], [type]) VALUES (10, N'F1010', N'department_id', N'PC1000', N'Department Id', 0, N'departments', N'label')
INSERT [dbo].[fieldcodes] ([field_said], [field_cd], [field_name_txt], [page_cd], [desc_txt], [mand_ind], [table_name], [type]) VALUES (11, N'F1012', N'job_title', N'PC1000', N'Job Title', 1, N'jobs', N'label')
INSERT [dbo].[fieldcodes] ([field_said], [field_cd], [field_name_txt], [page_cd], [desc_txt], [mand_ind], [table_name], [type]) VALUES (12, N'F1013', N'min_salary', N'PC1000', N'Min Salary', 1, N'jobs', N'label')
INSERT [dbo].[fieldcodes] ([field_said], [field_cd], [field_name_txt], [page_cd], [desc_txt], [mand_ind], [table_name], [type]) VALUES (13, N'F1014', N'max_salary', N'PC1000', N'Max Salary', 1, N'jobs', N'label')
INSERT [dbo].[fieldcodes] ([field_said], [field_cd], [field_name_txt], [page_cd], [desc_txt], [mand_ind], [table_name], [type]) VALUES (14, N'F1015', N'search', N'PC1000', N'Search', 0, NULL, N'button')
INSERT [dbo].[fieldcodes] ([field_said], [field_cd], [field_name_txt], [page_cd], [desc_txt], [mand_ind], [table_name], [type]) VALUES (15, N'F1016', N'reset', N'PC1000', N'Reset', 0, NULL, N'button')
INSERT [dbo].[fieldcodes] ([field_said], [field_cd], [field_name_txt], [page_cd], [desc_txt], [mand_ind], [table_name], [type]) VALUES (16, N'F1017', N'export', N'PC1000', N'Export', 0, NULL, N'button')
INSERT [dbo].[fieldcodes] ([field_said], [field_cd], [field_name_txt], [page_cd], [desc_txt], [mand_ind], [table_name], [type]) VALUES (17, N'F1018', N'print', N'PC1000', N'Print', 0, NULL, N'button')
INSERT [dbo].[fieldcodes] ([field_said], [field_cd], [field_name_txt], [page_cd], [desc_txt], [mand_ind], [table_name], [type]) VALUES (18, N'F1019', N'close', N'PC1000', N'Close', 0, NULL, N'button')
INSERT [dbo].[fieldcodes] ([field_said], [field_cd], [field_name_txt], [page_cd], [desc_txt], [mand_ind], [table_name], [type]) VALUES (19, N'F1020', N'cancel', N'PC1000', N'Cancel', 0, NULL, N'button')
INSERT [dbo].[fieldcodes] ([field_said], [field_cd], [field_name_txt], [page_cd], [desc_txt], [mand_ind], [table_name], [type]) VALUES (20, N'F1021', N'save', N'PC1000', N'Save', 0, NULL, N'button')
INSERT [dbo].[fieldcodes] ([field_said], [field_cd], [field_name_txt], [page_cd], [desc_txt], [mand_ind], [table_name], [type]) VALUES (21, N'F1022', N'employee', N'PC1000', N'Employee', 0, NULL, N'tab')
INSERT [dbo].[fieldcodes] ([field_said], [field_cd], [field_name_txt], [page_cd], [desc_txt], [mand_ind], [table_name], [type]) VALUES (22, N'F1023', N'search', N'PC1000', N'Search', 0, NULL, N'heading')
INSERT [dbo].[fieldcodes] ([field_said], [field_cd], [field_name_txt], [page_cd], [desc_txt], [mand_ind], [table_name], [type]) VALUES (23, N'F1024', N'name', N'PR1000', N'Name', 0, NULL, N'common')
INSERT [dbo].[fieldcodes] ([field_said], [field_cd], [field_name_txt], [page_cd], [desc_txt], [mand_ind], [table_name], [type]) VALUES (24, N'F1025', N'employee_name', N'PC1000', N'Employee Name', 0, NULL, N'common')
INSERT [dbo].[fieldcodes] ([field_said], [field_cd], [field_name_txt], [page_cd], [desc_txt], [mand_ind], [table_name], [type]) VALUES (25, N'F1026', N'employee_name', N'PC1000', N'Emp Name', 0, NULL, N'grid')
INSERT [dbo].[fieldcodes] ([field_said], [field_cd], [field_name_txt], [page_cd], [desc_txt], [mand_ind], [table_name], [type]) VALUES (26, N'F1027', N'department_name', N'PC1000', N'Department Name', 1, N'departments', N'label')
INSERT [dbo].[fieldcodes] ([field_said], [field_cd], [field_name_txt], [page_cd], [desc_txt], [mand_ind], [table_name], [type]) VALUES (27, N'F1028', N'street_address', N'PC1000', N'Street Address', 1, N'locations', N'label')
INSERT [dbo].[fieldcodes] ([field_said], [field_cd], [field_name_txt], [page_cd], [desc_txt], [mand_ind], [table_name], [type]) VALUES (28, N'F1029', N'postal_code', N'PC1000', N'Postal Code', 1, N'locations', N'label')
INSERT [dbo].[fieldcodes] ([field_said], [field_cd], [field_name_txt], [page_cd], [desc_txt], [mand_ind], [table_name], [type]) VALUES (29, N'F1031', N'state_province', N'PC1000', N'State Province', 1, N'locations', N'label')
INSERT [dbo].[fieldcodes] ([field_said], [field_cd], [field_name_txt], [page_cd], [desc_txt], [mand_ind], [table_name], [type]) VALUES (30, N'F1032', N'country_id', N'PC1000', N'Country Id', 1, N'countries', N'label')
INSERT [dbo].[fieldcodes] ([field_said], [field_cd], [field_name_txt], [page_cd], [desc_txt], [mand_ind], [table_name], [type]) VALUES (31, N'F1033', N'country_name', N'PC1000', N'Country Name', 1, N'countries', N'label')
INSERT [dbo].[fieldcodes] ([field_said], [field_cd], [field_name_txt], [page_cd], [desc_txt], [mand_ind], [table_name], [type]) VALUES (32, N'F1034', N'region_id', N'PC1000', N'Region Id', 1, N'regions', N'label')
INSERT [dbo].[fieldcodes] ([field_said], [field_cd], [field_name_txt], [page_cd], [desc_txt], [mand_ind], [table_name], [type]) VALUES (33, N'F1035', N'region_name', N'PC1000', N'Region Name', 1, N'regions', N'label')
INSERT [dbo].[fieldcodes] ([field_said], [field_cd], [field_name_txt], [page_cd], [desc_txt], [mand_ind], [table_name], [type]) VALUES (34, N'F1036', N'edit', N'PC1000', N'Edit', 0, NULL, N'button')

