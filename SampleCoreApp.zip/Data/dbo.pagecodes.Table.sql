CREATE TABLE [dbo].[pagecodes](
	[page_said] [int] IDENTITY(1,1) NOT NULL,
	[page_cd] [nvarchar](10) NOT NULL,
	[desc_txt] [nvarchar](100) NOT NULL,
	PRIMARY KEY (page_said)
)

INSERT [dbo].[pagecodes] ([page_said], [page_cd], [desc_txt]) VALUES (1, N'PC1000', N'Common')
INSERT [dbo].[pagecodes] ([page_said], [page_cd], [desc_txt]) VALUES (2, N'PR1000', N'Reports')
