﻿using Microsoft.Extensions.DependencyInjection;
using SampleCoreApp.Infrastructure.ApplicationHelpers;
using SampleCoreApp.Infrastructure.Base.Interfaces;
using SampleCoreApp.Interfaces.Repositories;
using SampleCoreApp.Interfaces.UnitOfWork;
using SampleCoreApp.UnitOfWork;
using SampleCoreApp.UnitOfWork.StartupHelpers;
using SampleCoreApp.Infrastructure.Constants;
using SampleCoreApp.Infrastructure.Interfaces;

namespace SampleCoreApp.Web.Infrastructure
{
    public static class RegisterStartupHelper
    {
        public static void RegisterServices(ref IServiceCollection services)
        {
            services.AddScoped<CacheStartupService>(); //Register service to set the cache on startup
            services.AddTransient<IDbHelper, DbSqlHelper>();
            services.AddSingleton<ICacheHelper, CacheHelper>();
            //services.AddTransient<ApplicationUIValues>();

            services.AddTransient<IExcelExportHelper, ExcelExportHelper>();
            services.AddTransient<IPDFExportHelper, PDFExportHelper>();
            services.AddTransient<IDelimitedExportHelper, DelimitedExportHelper>();
            RegisterRepositoriesStartup.ResgisterRepositories(ref services);
            RegisterUnitOfWorkStartup.RegisterUnitOfWork(ref services); 
        }
    }
}
