﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SampleCoreApp.Infrastructure.Base.Constants;
using SampleCoreApp.Infrastructure.Base.Models;
using SampleCoreApp.Infrastructure.BaseModels;
using SampleCoreApp.Interfaces.UnitOfWork;
using SampleCoreApp.Models.Models.SampleModuleModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace SampleCoreApp.Web.api.Controllers
{
    [Route("api/[controller]")]
    public class LookupValuesController : BaseApiController
    {
        private readonly ILookupUnitOfWork _lookupUnitOfWork;
        public LookupValuesController(ILookupUnitOfWork lookupUnitOfWork)
        {
            _lookupUnitOfWork = lookupUnitOfWork;
        }


        /// <summary>
        /// Gets the Department lookup
        /// </summary>
        /// <param name="departmentId">Department Id</param>
        /// <param name="departmentName">Department Name</param>
        /// <returns>IEnumerable<DepartmentModel></returns>
        [HttpGet]
        [Route("GetDepartmentLookup")]
        [Produces("application/json")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status200OK)]        
        public ActionResult<IEnumerable<DepartmentModel>> GetDepartmentLookup(int? departmentId, string departmentName)
        {
            DepartmentModel departmentModel =new ();
            CommonModel commonModel = new ();
            MessageModel messageModel = new ();
            commonModel.ActionCode = CRUDOperationsConstants.SelectList;

            departmentModel.DepartmentId = departmentId;
            departmentModel.DepartmentName= departmentName;

            var models = Ok(_lookupUnitOfWork.GetLookupRepository().GetDepartmentDropdownLookup(departmentModel, ref commonModel, ref messageModel));
            
            if (models == null)
            {
                return NoContent();
            }
            return Ok(models);
        }
    }
}
