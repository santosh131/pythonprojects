﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SampleCoreApp.Infrastructure.Base.Constants;
using SampleCoreApp.Infrastructure.Base.Models;
using SampleCoreApp.Interfaces.UnitOfWork;
using SampleCoreApp.Models.Models.SampleModuleModel;
using SampleCoreApp.Models.ViewModels.SampleModuleViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SampleCoreApp.Infrastructure.ApplicationHelpers;
using SampleCoreApp.Infrastructure.BaseModels;
using System.Net.Http;
using System.Net.Http.Json;
using System.Net;
using SampleCoreApp.Web.Models;
using System.Net.Mime;

namespace SampleCoreApp.Web.api
{
    [Route("api/[controller]")]
    
    public class EmployeeApiController : BaseApiController
    {
        private readonly IEmployeeUnitOfWork _employeeUnitOfWork;
        public EmployeeApiController(IEmployeeUnitOfWork employeeUnitOfWork)
        {
            _employeeUnitOfWork = employeeUnitOfWork;
        }

        [HttpGet]
        [Route("GetTransactions")]
        [Produces(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<ActionResult<List<TransactionModel>>> GetTransactions()
        {
            var models= await Task.Run(()=> { return _employeeUnitOfWork.GetTransactionsModel(); });
            if (models == null)
                return NotFound(new MessageModel() { MessageCode = "1001", MessageDescription = "Hello ", MessageType = "S" });
             return Ok(models);             
        }

        [HttpGet]
        [Route("GetEmployees")]
        [Produces(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public ActionResult<EmployeeViewModel> GetEmployees(EmployeeModel employeeModel)
        {
            employeeModel ??= new();
            SortingPagingModel sortingPagingModel= new();

            EmployeeViewModel employeeViewModel = new();
            CommonModel commonModel = new();
            MessageModel messageModel = new();
            List<DepartmentModel> departmentModels;
            List<JobModel> jobModels;

            commonModel.ActionCode = CRUDOperationsConstants.SelectList;
            sortingPagingModel.ItemsPerPage = 5;

            departmentModels = _employeeUnitOfWork.GetLookupRepository().GetDepartmentDropdownLookup(new DepartmentModel(), ref commonModel, ref messageModel).ToList();
            jobModels = _employeeUnitOfWork.GetLookupRepository().GetJobDropdownLookup(new JobModel(), ref commonModel, ref messageModel).ToList();

            employeeViewModel.DepartmentLookupModel = departmentModels.ToSelectList("DepartmentId", "DepartmentName", null, "LocationId");
            employeeViewModel.JobLookupModel = jobModels.ToSelectList("JobId", "JobTitle", null, "MinSalary");

            commonModel.ActionCode = CRUDOperationsConstants.List;
            employeeViewModel.EmployeeModels = _employeeUnitOfWork.GetEmployeeRepository().GetAll(employeeModel, commonModel, ref messageModel, ref sortingPagingModel);
            employeeViewModel.EmployeeModel = new EmployeeModel() { JobId = 6 };
            employeeViewModel.TransactionsModel = _employeeUnitOfWork.GetTransactionsModel();
            employeeViewModel.FieldCodeModels = _employeeUnitOfWork.GetFieldCodeModels();
            employeeViewModel.MessageModel = null; //set to messageModel if default message has to be shown on load
            employeeViewModel.PagingModel = sortingPagingModel;
            employeeViewModel.PagingModel.TotalItems = employeeViewModel.EmployeeModels.Count;
            if(employeeViewModel.EmployeeModels==null || employeeViewModel.EmployeeModels.Count == 0)
            {
                return NoContent();
            }
            return Ok(employeeViewModel);
        }
    }
}
