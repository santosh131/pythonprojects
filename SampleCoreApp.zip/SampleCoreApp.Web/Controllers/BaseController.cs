﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc.ViewEngines;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using SampleCoreApp.Infrastructure.ApplicationHelpers;
using SampleCoreApp.Infrastructure.Base.ApplicationHelpers;
using SampleCoreApp.Infrastructure.BaseModels;

namespace SampleCoreApp.Web.Controllers
{
    public abstract class BaseController : Controller
    {
        public BaseController()
        {

        }

        //public string RenderRazorViewToString(string viewName, object model = null)
        //{
        //Controller controller = this;
        //controller.ViewData.Model = model;
        //using (var sw = new StringWriter())
        //{
        //    ViewEngineResult viewResult;
        //    viewResult =new Microsoft.AspNetCore.Mvc.ViewEngines.CompositeViewEngine().FindView(controller.ControllerContext, viewName,false);
        //    var viewContext = new ViewContext(controller.ControllerContext, viewResult.View, controller.ViewData, controller.TempData, sw);
        //    viewResult.View.Render(viewContext, sw);
        //    viewResult.ViewEngine.ReleaseView(controller.ControllerContext, viewResult.View);
        //    return sw.GetStringBuilder().ToString();
        //}
        // return "";
        //}
        public ActionResult RenderViewsJson(string viewName, object viewModel, bool isMainPage = false,bool isJsonOnly=true)
        {
            MessageModel messageModel = new();
            if (viewModel is BaseViewModel model1)
            {
                if (model1.MessageModel != null)
                {
                    model1.MessageModel.IsJson = true;
                    messageModel = model1.MessageModel;
                }
            }

            if (AppSettings.IsModelOnly)
            {
                return Json(new { model = viewModel });
            }
            else if (!isJsonOnly)
            {
                return View(viewName, viewModel);
            }
            else
            {
                Task<string> htmlContent = RenderViewAsync(viewName, viewModel, isMainPage);
                return Json(new { htmlContent = htmlContent.Result, message = messageModel });
            }

        }

        public async Task<string> RenderViewAsync(string viewName, object model, bool isMainPage = true)
        {

            Controller controller = this;
            if (string.IsNullOrEmpty(viewName))
            {
                viewName = controller.ControllerContext.ActionDescriptor.ActionName;
            }

            controller.ViewData.Model = model;

            using var writer = new StringWriter();
            IViewEngine viewEngine = controller.HttpContext.RequestServices.GetService(typeof(ICompositeViewEngine)) as ICompositeViewEngine;
            ViewEngineResult viewResult = viewEngine.FindView(controller.ControllerContext, viewName, isMainPage);
            
            if (viewResult.Success == false)
            {
                return $"A view with the name {viewName} could not be found";
            }

            ViewContext viewContext = new(
                controller.ControllerContext,
                viewResult.View,
                controller.ViewData,
                controller.TempData,
                writer,
                new HtmlHelperOptions()
            );

            await viewResult.View.RenderAsync(viewContext);

            return writer.GetStringBuilder().ToString();
        }
    }
}
