﻿using Microsoft.AspNetCore.Mvc;
using SampleCoreApp.Infrastructure.Base.Constants;
using SampleCoreApp.Infrastructure.Base.Models;
using SampleCoreApp.Interfaces.UnitOfWork;
using SampleCoreApp.Models.Models.SampleModuleModel;
using SampleCoreApp.Models.ViewModels.SampleModuleViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using SampleCoreApp.Infrastructure.BaseModels;
using SampleCoreApp.Infrastructure.ApplicationHelpers;

namespace SampleCoreApp.Web.Controllers
{
    public class EmployeeController : BaseController
    {
        #region Variables & Constructor
        private readonly IEmployeeUnitOfWork _employeeUnitOfWork;
        public EmployeeController(IEmployeeUnitOfWork employeeUnitOfWork)
        {
            _employeeUnitOfWork = employeeUnitOfWork;
        }
        #endregion Variables & Constructor

        #region Read

        // GET: Employee
        [HttpGet]
        public ActionResult Index(EmployeeModel employeeModel, SortingPagingModel sortingPagingModel)
        {
            employeeModel ??= new();
            sortingPagingModel ??= new();

            EmployeeViewModel employeeViewModel = new();
            CommonModel commonModel = new();
            MessageModel messageModel = new();
            List<DepartmentModel> departmentModels;
            List<JobModel> jobModels;

            commonModel.ActionCode = CRUDOperationsConstants.SelectList;
            sortingPagingModel.ItemsPerPage = 5;

            departmentModels = _employeeUnitOfWork.GetLookupRepository().GetDepartmentDropdownLookup(new DepartmentModel(), ref commonModel, ref messageModel).ToList();
            jobModels = _employeeUnitOfWork.GetLookupRepository().GetJobDropdownLookup(new JobModel(), ref commonModel, ref messageModel).ToList();

            employeeViewModel.DepartmentLookupModel = departmentModels.ToSelectList("DepartmentId", "DepartmentName", null, "LocationId");
            employeeViewModel.JobLookupModel = jobModels.ToSelectList("JobId", "JobTitle", null, "MinSalary");
            
            commonModel.ActionCode = CRUDOperationsConstants.List;
            employeeViewModel.EmployeeModels = _employeeUnitOfWork.GetEmployeeRepository().GetAll(employeeModel, commonModel, ref messageModel, ref sortingPagingModel);
            employeeViewModel.EmployeeModel = new EmployeeModel() { JobId = 6 };
            employeeViewModel.TransactionsModel = _employeeUnitOfWork.GetTransactionsModel();
            employeeViewModel.FieldCodeModels = _employeeUnitOfWork.GetFieldCodeModels();
            employeeViewModel.MessageModel = null; //set to messageModel if default message has to be shown on load
            employeeViewModel.PagingModel = sortingPagingModel;
            employeeViewModel.PagingModel.TotalItems = employeeViewModel.EmployeeModels.Count;
            //return View(employeeViewModel);
            //return Json(new { PartialView = employeeViewModel });
            return RenderViewsJson(nameof(Index), employeeViewModel, true,false);
        }

        [HttpGet]
        public ActionResult SearchGrid(EmployeeModel employeeModel, SortingPagingModel sortingPagingModel)
        { 
            employeeModel ??= new();
            sortingPagingModel ??= new();

            EmployeeViewModel employeeViewModel = new();
            CommonModel commonModel = new();
            MessageModel messageModel = new(true);

            commonModel.ActionCode = CRUDOperationsConstants.List;
            sortingPagingModel.ItemsPerPage = 5;

            employeeViewModel.EmployeeModels = _employeeUnitOfWork.GetEmployeeRepository().GetAll(employeeModel, commonModel, ref messageModel, ref sortingPagingModel);
            
            employeeViewModel.FieldCodeModels = _employeeUnitOfWork.GetFieldCodeModels();
            employeeViewModel.MessageModel = messageModel.SetMessageDescriptions();
            employeeViewModel.PagingModel = sortingPagingModel;
            employeeViewModel.PagingModel.TotalItems = employeeViewModel.EmployeeModels.Count;
            //return RenderPartialViewJson(nameof(Search), employeeViewModel, true);return PartialView(employeeViewModel);
            //return Json(new { PartialView = employeeViewModel });
            return RenderViewsJson(nameof(SearchGrid), employeeViewModel, false);
        }

        // GET: Employee/Details/5

        [HttpGet]
        public ActionResult Details(int id)
        { 
            EmployeeViewModel employeeViewModel =_employeeUnitOfWork.GetEmployeeViewModel(id, CRUDOperationsConstants.Get);

            //return PartialView(nameof(Details), employeeViewModel);
            return RenderViewsJson(nameof(Details), employeeViewModel, false);
        }

        #endregion Read

        #region Create
         
        public ActionResult Create()
        {
            System.Threading.Thread.Sleep(3000);

            EmployeeViewModel employeeViewModel = _employeeUnitOfWork.GetEmployeeViewModel(null, CRUDOperationsConstants.Create);

            //return PartialView(nameof(Create), employeeViewModel);
            return RenderViewsJson(nameof(Create), employeeViewModel, false);
        }
         
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(EmployeeViewModel employeeViewModel)
        {
            _employeeUnitOfWork.PostEmployeeViewModel(employeeViewModel ,CRUDOperationsConstants.Create);

            return Json(employeeViewModel);
        }

        #endregion Create

        #region Edit

        // GET: Employee/Edit/5
        public ActionResult Edit(int id)
        {
            EmployeeViewModel employeeViewModel = _employeeUnitOfWork.GetEmployeeViewModel(id, CRUDOperationsConstants.Update);
            //return PartialView(nameof(Edit), employeeViewModel);
            return RenderViewsJson(nameof(Edit), employeeViewModel, false);
        }

        // POST: Employee/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult Edit(EmployeeViewModel employeeViewModel)
        {
            _employeeUnitOfWork.PostEmployeeViewModel(employeeViewModel, CRUDOperationsConstants.Update);

            return Json(employeeViewModel);
        }

        #endregion Edit

        #region Delete

        // GET: Employee/Delete/5
        public ActionResult Delete(int id)
        {
            EmployeeViewModel employeeViewModel = _employeeUnitOfWork.GetEmployeeViewModel(id, CRUDOperationsConstants.Update);

            //return PartialView(nameof(Delete), employeeViewModel);
            return RenderViewsJson(nameof(Delete), employeeViewModel, false);
        }

        // POST: Employee/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(EmployeeViewModel employeeViewModel)
        {
            _employeeUnitOfWork.PostEmployeeViewModel(employeeViewModel, CRUDOperationsConstants.Delete);

            return Json(employeeViewModel);
        }
        #endregion Delete
    }
}
