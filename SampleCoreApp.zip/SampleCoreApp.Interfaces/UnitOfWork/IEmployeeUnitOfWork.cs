﻿using SampleCoreApp.Infrastructure.Base.Constants;
using SampleCoreApp.Infrastructure.Interfaces;
using SampleCoreApp.Interfaces.Repositories;
using SampleCoreApp.Models.ViewModels.SampleModuleViewModels;

namespace SampleCoreApp.Interfaces.UnitOfWork
{
    public interface IEmployeeUnitOfWork : IGenericUnitOfWork
    {
        IEmployeeRepository GetEmployeeRepository();
        ILookupRepository GetLookupRepository();

        EmployeeViewModel GetEmployeeViewModel(int? id, string crudOperationsConstants);
        EmployeeViewModel PostEmployeeViewModel(EmployeeViewModel employeeViewModel, string crudOperationsConstants);
    }
}
