﻿using SampleCoreApp.Infrastructure.Interfaces;
using SampleCoreApp.Interfaces.Repositories;

namespace SampleCoreApp.Interfaces.UnitOfWork
{
    public interface ILookupUnitOfWork : IGenericUnitOfWork
    {
        ILookupRepository GetLookupRepository();
    }
}
