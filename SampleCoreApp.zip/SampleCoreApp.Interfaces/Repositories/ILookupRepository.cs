﻿using SampleCoreApp.Infrastructure.Base.Models;
using SampleCoreApp.Infrastructure.BaseModels;
using SampleCoreApp.Models.Models.SampleModuleModel;
using System;
using System.Collections.Generic;
using System.Text;

namespace SampleCoreApp.Interfaces.Repositories
{
    public interface ILookupRepository
    {
        //Add additional functions here
        IEnumerable<DepartmentModel> GetDepartmentDropdownLookup(DepartmentModel departmentModel, ref CommonModel commonModel, ref MessageModel messageModel);

        IEnumerable<LocationModel> GetLocationDropdownLookup(LocationModel locationModel, ref CommonModel commonModel, ref MessageModel messageModel);

        IEnumerable<JobModel> GetJobDropdownLookup(JobModel jobModel, ref CommonModel commonModel, ref MessageModel messageModel);

        IEnumerable<FieldCodeModel> GetFieldCodeLookup(FieldCodeModel fieldCodeModel, ref CommonModel commonModel, ref MessageModel messageModel);

        IEnumerable<MessageModel> GetMessageCodeLookup(MessageModel messageModel, ref CommonModel commonModel, ref MessageModel messageModelOutput);
    }
}
