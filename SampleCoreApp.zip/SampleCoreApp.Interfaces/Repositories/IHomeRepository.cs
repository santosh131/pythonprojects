﻿using SampleCoreApp.Infrastructure.Base.Interfaces;
using SampleCoreApp.Infrastructure.Base.Models;
using SampleCoreApp.Models;
using SampleCoreApp.Infrastructure.BaseModels;
using SampleCoreApp.Models.Models.SampleModuleModel;
using SampleCoreApp.Models.Models;
using System.Collections.Generic;

namespace SampleCoreApp.Interfaces.Repositories
{
    public interface IHomeRepository: IGenericReadRepository<HomeModel, CommonModel, MessageModel, SortingPagingModel>
    {
        //Add additional functions here
        
    }
}
