﻿using SampleCoreApp.Infrastructure.Base.Interfaces;
using SampleCoreApp.Infrastructure.BaseModels;
using SampleCoreApp.Infrastructure.Base.Models;
using SampleCoreApp.Models.Models.SampleModuleModel;
using System.Collections.Generic;

namespace SampleCoreApp.Interfaces.Repositories
{
   public  interface IDepartmentRepository :
        IGenericReadAllRepository<DepartmentModel, CommonModel, MessageModel, SortingPagingModel>
    {
        
    }
}
