﻿using SampleCoreApp.Infrastructure.Base.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace SampleCoreApp.Infrastructure.ApplicationHelpers
{
    public class DelimitedExportHelper : IDelimitedExportHelper
    {
        /// <summary>
        /// Exports the Data
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="dataSource">DataSource</param>
        /// <param name="exportFileName">ExportFileName</param>
        /// <param name="configDataSource">Configuration DataSource</param>
        /// <param name="delimitedText">DelimitedText</param>
        /// <param name="hasfileNameDateTime">HasfileNameDateTime</param>
        public void Export<T>(T dataSource, string exportFileName, T configDataSource, string delimitedText = ",", bool hasfileNameDateTime = false)
        {
            throw new NotImplementedException();
        }
    }
}
