﻿using Microsoft.Extensions.Caching.Memory;
using SampleCoreApp.Infrastructure.Base.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;
using static SampleCoreApp.Infrastructure.Constants.ApplicationConstants;

namespace SampleCoreApp.Infrastructure.ApplicationHelpers
{
    public class CacheHelper : ICacheHelper
    {
        public static CacheHelper Instance { get; private set; }

        private readonly IMemoryCache _memoryCache;

        public CacheHelper(IMemoryCache memoryCache)
        {
            _memoryCache = memoryCache;
            Instance = this;
        }

        /// <summary>
        /// Clears the entire cache
        /// </summary>
        /// <returns>bool</returns>
        public bool ClearAllCache()
        {
            return false;
        }

        /// <summary>
        /// Clears specific cache using the key
        /// </summary>
        /// <param name="key"></param>
        /// <returns>bool</returns>
        public bool ClearCache(string key)
        {
            try
            {
                _memoryCache.Remove(key);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <summary>
        /// Gets the object from cache
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="key"></param>
        /// <returns>T</returns>
        public T GetFromCache<T>(string key)
        {
            return _memoryCache.Get<T>(key);
        }

        /// <summary>
        /// Sets the object to cache
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="key"></param>
        /// <param name="dataSource"></param>
        public void SetToCache<T>(string key, T dataSource)
        {
            ClearCache(key);
            _memoryCache.Set<T>(key, dataSource);
        }
    }
}
