﻿using SampleCoreApp.Infrastructure.Base.ApplicationHelpers;
using SampleCoreApp.Infrastructure.Base.Models;
using System;
using System.Collections.Generic;

namespace SampleCoreApp.Infrastructure.BaseModels
{
    [Serializable]
    public abstract class BaseViewModel : ViewModelHelper
    {
        private MessageModel _messageModel = new();
        private SortingPagingModel _pagingModel = new();
        private List<TransactionModel> _transactionsModel = new();
        private List<FieldCodeModel> _fieldCodeModels = new();

        public MessageModel MessageModel { get => _messageModel; set => _messageModel = value; }
        public SortingPagingModel PagingModel { get => _pagingModel; set => _pagingModel = value; }
        public List<TransactionModel> TransactionsModel { get => _transactionsModel; set => _transactionsModel = value; }
        public List<FieldCodeModel> FieldCodeModels { get => _fieldCodeModels; set => _fieldCodeModels = value; }

    }
}
