﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SampleCoreApp.Infrastructure.Constants
{
    public partial class TableTypeHelpers
    {

    }
}
