﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SampleCoreApp.Infrastructure.Constants
{
    public sealed class ApplicationUIValues
    {
        public static readonly string NoRecordsFound = "No Records Found";
    }
}
