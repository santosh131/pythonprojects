﻿using SampleCoreApp.Infrastructure.Base.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace SampleCoreApp.Infrastructure.Interfaces
{
    public interface IPDFExportHelper: IExportHelper
    {
    }
}
