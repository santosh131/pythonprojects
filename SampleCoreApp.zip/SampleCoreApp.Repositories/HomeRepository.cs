﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Data;
using SampleCoreApp.Infrastructure.Base.ApplicationHelpers;
using SampleCoreApp.Infrastructure.Base.Interfaces;
using SampleCoreApp.Infrastructure.Base.Models;
using SampleCoreApp.Infrastructure.BaseModels;
using SampleCoreApp.Interfaces.Repositories;
using SampleCoreApp.Models.Models.SampleModuleModel;
using SampleCoreApp.Models.Models;

namespace SampleCoreApp.Repositories
{
    public class HomeRepository : RepositoryHelper,IHomeRepository
    { 
        public HomeRepository(IDbHelper dbHelper) :base(dbHelper)
        {
        } 

        public HomeModel Get(HomeModel t, CommonModel tcommon, ref MessageModel tmessage)
        {
            throw new NotImplementedException();
        }

        public List<HomeModel> GetAll(HomeModel t, CommonModel tcommon, ref MessageModel tmessage,ref SortingPagingModel tSortingPaging)
        {
            return new List<HomeModel>() { new HomeModel() { Message = "Result 1" },
            new HomeModel(){ Message="Result 2" } };
        } 
         
    }
}
