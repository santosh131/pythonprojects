﻿using SampleCoreApp.Infrastructure.Base.ApplicationHelpers;
using SampleCoreApp.Infrastructure.Base.Extensions;
using SampleCoreApp.Infrastructure.Base.Interfaces;
using SampleCoreApp.Infrastructure.Base.Models;
using SampleCoreApp.Infrastructure.BaseModels;

using SampleCoreApp.Interfaces.Repositories;
using SampleCoreApp.Models.Models.SampleModuleModel; 
using System;
using System.Collections.Generic;
using System.Data;

namespace SampleCoreApp.Repositories
{
    public class LookupRepository : RepositoryHelper, ILookupRepository
    {
        public LookupRepository(IDbHelper dbHelper) : base(dbHelper)
        {
        }

        public IEnumerable<DepartmentModel> GetDepartmentDropdownLookup(DepartmentModel t,ref CommonModel tcommon, ref MessageModel tmessage)
        {
            DbHelper.SetQuery("GET_DEPARTMENTS_LOOKUP", CommandType.StoredProcedure);
            DbHelper.CreateParameter("@pin_department_id", t.DepartmentId, DbType.Int32, ParameterDirection.Input);
            DbHelper.CreateParameter("@pin_department_name", t.DepartmentName, DbType.String, ParameterDirection.Input);
            
            DbHelper.CreateParameter("@pin_option_cd", tcommon.OptionCode, DbType.String, ParameterDirection.Input);
            DbHelper.CreateParameter("@pin_list_type_cd", tcommon.ListTypeCode, DbType.String, ParameterDirection.Input);
            
            DbHelper.CreateParameter("@pout_msg_cd", null, DbType.String, ParameterDirection.Output, 20);
            DbHelper.CreateParameter("@pout_msg_txt", null, DbType.String, ParameterDirection.Output, 250); 

            List<DepartmentModel> lst = DbHelper.ExecuteReader().ToCollectionUsingMethod<DepartmentModel>();
            tmessage.MessageCode = DbHelper.GetOutputParameterStringValue("@pout_msg_cd");
            tmessage.MessageText = DbHelper.GetOutputParameterStringValue("@pout_msg_txt"); 
            return lst;
        }

        public IEnumerable<FieldCodeModel> GetFieldCodeLookup(FieldCodeModel fieldCodeModel, ref CommonModel commonModel, ref MessageModel messageModel)
        {
            DbHelper.SetQuery("GET_FIELDCODES_LOOKUP", CommandType.StoredProcedure);
            DbHelper.CreateParameter("@pin_field_cd", fieldCodeModel.FieldCode, DbType.String, ParameterDirection.Input);
            DbHelper.CreateParameter("@pin_page_cd", fieldCodeModel.PageCode, DbType.String, ParameterDirection.Input);

            DbHelper.CreateParameter("@pin_option_cd", commonModel.OptionCode, DbType.String, ParameterDirection.Input);
            DbHelper.CreateParameter("@pin_list_type_cd", commonModel.ListTypeCode, DbType.String, ParameterDirection.Input);

            DbHelper.CreateParameter("@pout_msg_cd", null, DbType.String, ParameterDirection.Output, 20);
            DbHelper.CreateParameter("@pout_msg_txt", null, DbType.String, ParameterDirection.Output, 250);

            List<FieldCodeModel> lst = DbHelper.ExecuteReader().ToCollectionUsingMethod<FieldCodeModel>();
            messageModel.MessageCode = DbHelper.GetOutputParameterStringValue("@pout_msg_cd");
            messageModel.MessageText = DbHelper.GetOutputParameterStringValue("@pout_msg_txt");
            return lst;
        }

        public IEnumerable<JobModel> GetJobDropdownLookup(JobModel jobModel, ref CommonModel commonModel, ref MessageModel messageModel)
        {
            DbHelper.SetQuery("GET_JOB_LOOKUP", CommandType.StoredProcedure);
            DbHelper.CreateParameter("@pin_job_id", jobModel.JobId, DbType.Int32, ParameterDirection.Input);
            DbHelper.CreateParameter("@pin_job_title", jobModel.JobTitle, DbType.String, ParameterDirection.Input);

            DbHelper.CreateParameter("@pin_option_cd", commonModel.OptionCode, DbType.String, ParameterDirection.Input);
            DbHelper.CreateParameter("@pin_list_type_cd", commonModel.ListTypeCode, DbType.String, ParameterDirection.Input);

            DbHelper.CreateParameter("@pout_msg_cd", null, DbType.String, ParameterDirection.Output, 20);
            DbHelper.CreateParameter("@pout_msg_txt", null, DbType.String, ParameterDirection.Output, 250);

            List<JobModel> lst = DbHelper.ExecuteReader().ToCollectionUsingMethod<JobModel>();
            messageModel.MessageCode = DbHelper.GetOutputParameterStringValue("@pout_msg_cd");
            messageModel.MessageText = DbHelper.GetOutputParameterStringValue("@pout_msg_txt");
            return lst;
        }

        public IEnumerable<LocationModel> GetLocationDropdownLookup(LocationModel locationModel, ref CommonModel tcommon, ref MessageModel messageModel)
        {
            DbHelper.SetQuery("GET_LOCATION_LOOKUP", CommandType.StoredProcedure);
            DbHelper.CreateParameter("@pin_location_id", locationModel.LocationId, DbType.Int32, ParameterDirection.Input);
            DbHelper.CreateParameter("@pin_street_address", locationModel.StreetAddress, DbType.String, ParameterDirection.Input);

            DbHelper.CreateParameter("@pin_option_cd", tcommon.OptionCode, DbType.String, ParameterDirection.Input);
            DbHelper.CreateParameter("@pin_list_type_cd", tcommon.ListTypeCode, DbType.String, ParameterDirection.Input);

            DbHelper.CreateParameter("@pout_msg_cd", null, DbType.String, ParameterDirection.Output, 20);
            DbHelper.CreateParameter("@pout_msg_txt", null, DbType.String, ParameterDirection.Output, 250);

            List<LocationModel> lst = DbHelper.ExecuteReader().ToCollectionUsingMethod<LocationModel>();
            messageModel.MessageCode = DbHelper.GetOutputParameterStringValue("@pout_msg_cd");
            messageModel.MessageText = DbHelper.GetOutputParameterStringValue("@pout_msg_txt");
            return lst;
        }

        public IEnumerable<MessageModel> GetMessageCodeLookup(MessageModel messageModel, ref CommonModel commonModel, ref MessageModel messageModelOutput)
        {
            DbHelper.SetQuery("GET_MESSAGECODES_LOOKUP", CommandType.StoredProcedure);
            DbHelper.CreateParameter("@pin_msg_cd", messageModel.MessageCode, DbType.String, ParameterDirection.Input);
            DbHelper.CreateParameter("@pin_msg_txt", messageModel.MessageText, DbType.String, ParameterDirection.Input);

            DbHelper.CreateParameter("@pin_option_cd", commonModel.OptionCode, DbType.String, ParameterDirection.Input);
            DbHelper.CreateParameter("@pin_list_type_cd", commonModel.ListTypeCode, DbType.String, ParameterDirection.Input);

            DbHelper.CreateParameter("@pout_msg_cd", null, DbType.String, ParameterDirection.Output, 20);
            DbHelper.CreateParameter("@pout_msg_txt", null, DbType.String, ParameterDirection.Output, 250);

            List<MessageModel> lst = DbHelper.ExecuteReader().ToCollectionUsingMethod<MessageModel>();
            messageModel.MessageCode = DbHelper.GetOutputParameterStringValue("@pout_msg_cd");
            messageModel.MessageText = DbHelper.GetOutputParameterStringValue("@pout_msg_txt");
            return lst;
        }
    }
}
