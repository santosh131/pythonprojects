﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Text;
using SampleCoreApp.Infrastructure.BaseModels;
using SampleCoreApp.Models.Models.SampleModuleModel;

namespace SampleCoreApp.Models.ViewModels.SampleModuleViewModels
{
    [Serializable]
    public class EmployeeViewModel : BaseViewModel
    {
        public List<EmployeeModel> EmployeeModels { get; set; }

        public EmployeeModel EmployeeModel { get; set; }

        public SelectList DepartmentLookupModel { get; set; }

        public SelectList JobLookupModel { get; set; }
    }
}
