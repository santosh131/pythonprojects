﻿using SampleCoreApp.Infrastructure.Base.ApplicationHelpers;
using SampleCoreApp.Infrastructure.Base.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace SampleCoreApp.Models.Models.SampleModuleModel
{
    public class JobModel : BaseModel
    {
        [DbColumnName("job_id")]
        public int? JobId { get; set; }

        [DbColumnName("job_title")]
        public string JobTitle { get; set; }

        [DbColumnName("min_salary")]
        public decimal MinSalary { get; set; }

        [DbColumnName("max_salary")]
        public decimal Maxsalary { get; set; }
    }
}
