﻿using SampleCoreApp.Infrastructure.Base.ApplicationHelpers;
using SampleCoreApp.Infrastructure.Base.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace SampleCoreApp.Models.Models.SampleModuleModel
{
    [Serializable]
    public class DepartmentModel : BaseModel
    {
        [DbColumnName("department_id")]
        public int? DepartmentId { get; set; }

        [DbColumnName("department_name")]
        public string DepartmentName { get; set; }

        [DbColumnName("location_id")]
        public string LocationId { get; set; }
    }
}
