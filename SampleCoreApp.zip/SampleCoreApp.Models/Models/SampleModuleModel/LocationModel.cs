﻿using SampleCoreApp.Infrastructure.Base.ApplicationHelpers;
using SampleCoreApp.Infrastructure.Base.Models;
using System;
using System.Collections.Generic;
using System.Text;
namespace SampleCoreApp.Models.Models.SampleModuleModel
{
    [Serializable]
    public class LocationModel : BaseModel
    {
        [DbColumnName("location_id")]
        public int? LocationId { get; set; }

        [DbColumnName("street_address")]
        public string StreetAddress { get; set; }

        [DbColumnName("postal_code")]
        public string PostalCode { get; set; }

        [DbColumnName("city")]
        public string City { get; set; }

        [DbColumnName("state_province")]
        public string StateProvince { get; set; }

        [DbColumnName("country_id")]
        public string CountryId { get; set; }
    }
}
