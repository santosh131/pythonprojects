﻿using SampleCoreApp.Infrastructure.Base.ApplicationHelpers;
using SampleCoreApp.Infrastructure.Base.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace SampleCoreApp.Models.Models.SampleModuleModel
{
    [Serializable]
    public class EmployeeModel : BaseModel
    {
        [DbColumnName("employee_id")]
        public int? EmployeeId { get; set; }

        [DbColumnName("first_name")]       
        [Required(AllowEmptyStrings =false, ErrorMessage ="First Name is required")]
        public string FirstName { get; set; }

        [DbColumnName("last_name")]
        [Required]
        [DisplayName("Sample Name")]
        public string LastName { get; set; }

        [DbColumnName("email")]
        [DataType(DataType.EmailAddress)]
        public string Email { get; set; }

        [DbColumnName("phone_number")]
        public string PhoneNumber { get; set; }

        [DbColumnName("hire_date")]
        public DateTime HireDate { get; set; }

        [DbColumnName("job_id")]
        public int JobId { get; set; }

        [DbColumnName("salary")]
        public decimal Salary { get; set; }

        [DbColumnName("manager_id")]
        public int? ManagerId { get; set; }

        [DbColumnName("department_id")]
        public int? DepartmentId { get; set; }
    }
}
