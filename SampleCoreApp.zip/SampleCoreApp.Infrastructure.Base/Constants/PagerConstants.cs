﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SampleCoreApp.Infrastructure.Base.Constants
{
    public sealed class PagerConstants
    {
        public static readonly int MaxPageNumber = 5;
        public static readonly string ParentPagerClass = "pager-parent";
        public static readonly string PagerClass = "pager-link";
        public static readonly string SelectedPageClass = "pager-link-selected";
        public static readonly string FirstPageClass = "pager-link-first-page";
        public static readonly string PreviousPageClass = "pager-link-prev-page";                
        public static readonly string NextPageClass = "pager-link-next-page";
        public static readonly string LastPageClass = "pager-link-last-page";
        public static readonly string FirstPageCaption = "First Page";
        public static readonly string PreviousPageCaption = "Previous";
        public static readonly string NextPageCaption = "Next";
        public static readonly string LastPageCaption = "Last Page";
    }
}
