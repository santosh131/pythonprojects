﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SampleCoreApp.Infrastructure.Base.Constants
{
    public sealed class CRUDOperationsConstants
    {
        public static readonly string Get = "G";
        public static readonly string List = "L";
        public static readonly string Create = "C";
        public static readonly string Update = "U";
        public static readonly string Delete = "D";
        public static readonly string Popup = "P";
        public static readonly string SelectList = "S";
    } 
}
