﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SampleCoreApp.Infrastructure.Base.Constants
{
    public sealed class ApplicationHtmlConstants
    {
        public static readonly string LabelRequiredHtml = "<span style='color:red;font:weight:bold'>*</span>";
    }
}
