﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SampleCoreApp.Infrastructure.Base.Constants
{
    public sealed class SortOperationsConstants
    {
        public static readonly string Ascending = "asc";
        public static readonly string Descending = "desc";
        public static readonly string AscendingClass = "fa fa-sort-alpha-asc margin-top-5";
        public static readonly string DescendingClass = "fa fa-sort-alpha-desc margin-top-5";
    }
}
