﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SampleCoreApp.Infrastructure.Base.Constants
{ 
    public sealed class MessageTypeCodeConstants
    {
        public static readonly string Success = "S";
        public static readonly string ValidationSuccess = "S";
        public static readonly string SystemError = "E";
    }
}
