﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SampleCoreApp.Infrastructure.Base.Constants
{
    public sealed class LookupOptionCodeConstants
    {
        public static readonly int NoneInt = 0;
        public static readonly int SelectInt = 1;
        public static readonly int AllInt = 2;
        public static readonly string None = "-1";
        public static readonly string Select = "";
        public static readonly string All = "Z";
    }
}
