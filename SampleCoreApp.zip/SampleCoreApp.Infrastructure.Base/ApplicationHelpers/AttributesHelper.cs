﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Reflection;
using System.Text;
using System.Linq;
namespace SampleCoreApp.Infrastructure.Base.ApplicationHelpers
{
    public sealed class AttributesHelper
    {
        /// <summary>
        /// Gets the ColumnAttribute value
        /// </summary>
        /// <param name="property">PropertyInfo</param>
        /// <returns>string</returns>
        /// <remarks> get the value if ColumnAttribute exists  otherwise returns PropertyName</remarks>
        public static string GetColumnAttributeVal(PropertyInfo property)
        {
            foreach (object attrib in property.GetCustomAttributes(true))
            {
                if (attrib is ColumnAttribute attribute)
                    return attribute.Name;
            }
            return property.Name;
        }

        /// <summary>
        /// Gets the DbColumnNameAttribute value
        /// </summary>
        /// <param name="property">PropertyInfo</param>
        /// <returns>string</returns>
        /// <remarks> get the value if DbColumnNameAttribute exists  otherwise returns PropertyName</remarks>
        public static string GetDbColumnAttributeVal(PropertyInfo property)
        {
            object attrib = property.GetCustomAttributes(true).Where(p => p is DbColumnNameAttribute).FirstOrDefault();            
            if (attrib != null)
                return ((DbColumnNameAttribute)(attrib)).Name;
            else
                return property.Name;
        }
    }
}
