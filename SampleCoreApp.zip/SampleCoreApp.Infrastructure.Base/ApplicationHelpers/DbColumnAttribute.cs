﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SampleCoreApp.Infrastructure.Base.ApplicationHelpers
{
    public class DbColumnNameAttribute : Attribute
    {
        private string _name;

        public string Name { get => _name; set => _name = value; }

        public DbColumnNameAttribute(string name)
        {
            _name = name;
        }
    }
}
