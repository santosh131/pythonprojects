﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SampleCoreApp.Infrastructure.Base.ApplicationHelpers
{
    public static class BaseApplicationAppSettings
    {
        public static string ConnectionString { get; set; }

        public static bool ShowExceptionDetails { get; set; }
    }
}
