﻿using SampleCoreApp.Infrastructure.Base.ApplicationHelpers;
using SampleCoreApp.Infrastructure.Base.Constants;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace SampleCoreApp.Infrastructure.Base.Models
{
    [Serializable]
   public abstract class BaseMessageModel: ModelHelper
    {
        private string _messageCode;
        private string _messageText;

        [DbColumnName("msg_cd")]
        public string MessageCode { 
            get => _messageCode; 
            set
            {
                _messageCode = value;
                SetMessageTypeFromCache();
            }
        }

        [DbColumnName("msg_txt")]
        public string MessageText { get => _messageText; set => _messageText = value; }

        /// <summary>
        /// Sets the MessageType based on the message from cache
        /// </summary>
        public virtual void SetMessageTypeFromCache()
        {
            //Should be implemented in the child/inherited class
        }
    }
}
