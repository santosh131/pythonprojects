﻿using SampleCoreApp.Infrastructure.Base.ApplicationHelpers;
using System;
using System.Collections.Generic;
using System.Text;

namespace SampleCoreApp.Infrastructure.Base.Models
{
    [Serializable]
    public class FieldCodeModel: ModelHelper
    {
        [DbColumnName("field_cd")]
        public string FieldCode { get; set; }

        [DbColumnName("page_cd")]
        public string PageCode { get; set; }

        [DbColumnName("desc_txt")]
        public string Description { get; set; }

        /// <summary>
        /// Gets or Sets IsRequired
        /// </summary>
        /// <remarks>Used for label elements only to display the * symbol</remarks>
        [DbColumnName("mand_ind")]
        public bool IsRequired { get; set; } = false;

        [DbColumnName("max_width")]
        public int? MaxWidth { get; set; }

    }
}
