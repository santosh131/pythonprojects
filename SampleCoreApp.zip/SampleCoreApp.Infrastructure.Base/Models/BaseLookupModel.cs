﻿using SampleCoreApp.Infrastructure.Base.ApplicationHelpers;
using System;
using System.Collections.Generic;
using System.Text;

namespace SampleCoreApp.Infrastructure.Base.Models
{
    [Serializable]
    public class BaseLookupModel : ModelHelper
    {
    }
}
