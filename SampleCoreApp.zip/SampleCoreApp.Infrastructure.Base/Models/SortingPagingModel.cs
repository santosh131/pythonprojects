﻿using SampleCoreApp.Infrastructure.Base.Constants;
using System;


namespace SampleCoreApp.Infrastructure.Base.Models
{
    [Serializable]
    public class SortingPagingModel
    {
        private bool _isSort = false;
        private bool _isPaging = false;
        private int _totalItems = 0;
        private int _itemsPerPage = 10;
        private int _currentPageIndex = 1;
        private int _totalPages=1;
        private string _sortText = string.Empty;
        private string _sortOrder = SortOperationsConstants.Ascending;

        public int TotalItems { get => _totalItems; set => _totalItems = value; }
        public int CurrentPageIndex { get => _currentPageIndex; set => _currentPageIndex = value; }
        public int ItemsPerPage { get => _itemsPerPage; set => _itemsPerPage = value; }         
         
        public string SortText { get => _sortText; set => _sortText = value; }
        public string SortOrder { get => _sortOrder; set => _sortOrder = value; }
        public bool IsSort { get => _isSort; set => _isSort = value; }
        public bool IsPaging { get => _isPaging; set => _isPaging = value; }
        public int TotalPages { get => _totalPages; set => _totalPages = value; }
    }
}
