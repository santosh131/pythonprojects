﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SampleCoreApp.Infrastructure.Base.Models
{
    [Serializable]
    public class CommonModel
    {
        private string _listTypeCode = string.Empty;
        private string _optionCode = string.Empty;
        private string _optionCode2 = string.Empty;
        private string _actionCode = string.Empty;
        private string _updateTypeCode = string.Empty;
        private string _reportOptionCode = string.Empty;
        private string _reportOption1Code = string.Empty;
        private string _reportOption2Code = string.Empty;
        private string _reportTypeCode = string.Empty;
        private string _reportGroup1Code = string.Empty;
        private string _reportGroup2Code = string.Empty;
        private string _reportSort1Code = string.Empty;
        private string _reportSort2Code = string.Empty;
        private bool _fromIndicator = false;
        private bool _toIndicator = false;
        private DateTime? _fromDate = null;
        private DateTime? _toDate = null;
        private string _fromText = string.Empty;
        private string _toText = string.Empty;
        private int? _fromIntVal = null;
        private int? _toIntVal = null; 

        public string OptionCode { get => _optionCode; set => _optionCode = value; }
        public string OptionCode2 { get => _optionCode2; set => _optionCode2 = value; }
        public string ListTypeCode { get => _listTypeCode; set => _listTypeCode = value; }
        public string ActionCode { get => _actionCode; set => _actionCode = value; }
        public string UpdateTypeCode { get => _updateTypeCode; set => _updateTypeCode = value; }
        public string ReportOptionCode { get => _reportOptionCode; set => _reportOptionCode = value; }
        public string ReportTypeCode { get => _reportTypeCode; set => _reportTypeCode = value; }
        public string ReportGroup1Code { get => _reportGroup1Code; set => _reportGroup1Code = value; }
        public string ReportGroup2Code { get => _reportGroup2Code; set => _reportGroup2Code = value; }
        public string ReportOption1Code { get => _reportOption1Code; set => _reportOption1Code = value; }
        public string ReportOption2Code { get => _reportOption2Code; set => _reportOption2Code = value; }
        public bool FromIndicator { get => _fromIndicator; set => _fromIndicator = value; }
        public bool ToIndicator { get => _toIndicator; set => _toIndicator = value; }
        public DateTime? FromDate { get => _fromDate; set => _fromDate = value; }
        public DateTime? ToDate { get => _toDate; set => _toDate = value; }
        public string FromText { get => _fromText; set => _fromText = value; }
        public string ToText { get => _toText; set => _toText = value; }
        public int? FromIntVal { get => _fromIntVal; set => _fromIntVal = value; }
        public int? ToIntVal { get => _toIntVal; set => _toIntVal = value; }
        public string ReportSort1Code { get => _reportSort1Code; set => _reportSort1Code = value; }
        public string ReportSort2Code { get => _reportSort2Code; set => _reportSort2Code = value; }
    }
}
