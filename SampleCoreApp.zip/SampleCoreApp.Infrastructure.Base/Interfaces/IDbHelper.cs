﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace SampleCoreApp.Infrastructure.Base.Interfaces
{
    public interface IDbHelper
    {
        /// <summary>
        /// Resets all-Connection, Parameters, QueryText, QueryCommandType, SqlCmd
        /// </summary>
        void ResetAll();

        /// <summary>
        /// Sets the query- QueryText, QueryCommandType
        /// </summary>
        /// <param name="queryText"></param>
        /// <param name="queryCommandType"></param>
        void SetQuery(string queryText, CommandType queryCommandType);

        /// <summary>
        /// Sets the Connection String
        /// </summary>
        /// <param name="connString"></param>
        void SetConnectionString(string connString);
         
        /// <summary>
        /// Creates the Parameter
        /// </summary>
        /// <param name="name"></param>
        /// <param name="val"></param>
        /// <param name="dbType"></param>
        /// <param name="parameterDirection"></param>
        void CreateParameter(string name, object val, DbType dbType, ParameterDirection parameterDirection, int size=0);

        /// <summary>
        /// Creates the table parameter
        /// </summary>
        /// <param name="name"></param>
        /// <param name="val"></param>
        /// <param name="sqlDbType"></param>
        /// <param name="parameterDirection"></param>
        void CreateTableParameter(string name, object val, SqlDbType sqlDbType, ParameterDirection parameterDirection);

        /// <summary>
        /// Adds the parameter
        /// </summary>
        /// <param name="dataParameter"></param>
        void AddParameter(IDataParameter dataParameter);

        /// <summary>
        /// Executes the Non Query- Create,Update,Delete
        /// </summary>
        void ExecuteNonQuery();

        /// <summary>
        /// Executes the reader- Read
        /// </summary>
        /// <returns>void</returns>
        IDataReader ExecuteReader();

        /// <summary>
        /// Gets the Output Parameter
        /// </summary>
        /// <param name="name"></param>
        /// <returns>IDataParameter</returns>
        IDataParameter GetOutputParameter(string name);

        /// <summary>
        /// Gets the Debug script
        /// </summary>
        /// <returns>string</returns>
        string GetSqlDebugScript();

        /// <summary>
        /// Gets the Output parameter string value
        /// </summary>
        /// <param name="name">name</param>
        /// <returns>string</returns>
        string GetOutputParameterStringValue(string value);

        /// <summary>
        /// Gets the Output parameter Integer value
        /// </summary>
        /// <param name="value">value</param>
        /// <returns>int</returns>
        int GetOutputParameterIntegerValue(string value);

        /// <summary>
        /// Gets the Output parameter Integer64 value
        /// </summary>
        /// <param name="value">value</param>
        /// <returns>Integer64</returns>
        Int64 GetOutputParameterInteger64Value(string value);

        /// <summary>
        /// Gets the Output parameter Decimal value
        /// </summary>
        /// <param name="value">value</param>
        /// <returns>Decimal</returns>
        decimal GetOutputParameterDecimalValue(string value);

        /// <summary>
        /// Gets the Output parameter Bool value
        /// </summary>
        /// <param name="value">value</param>
        /// <returns>Bool</returns>
        bool GetOutputParameterBoolValue(string value);
       
    }
}
