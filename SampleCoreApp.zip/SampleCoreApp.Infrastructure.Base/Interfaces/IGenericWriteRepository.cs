﻿using SampleCoreApp.Infrastructure.Base.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace SampleCoreApp.Infrastructure.Base.Interfaces
{
    public interface IGenericWriteRepository<T, TCommon, TMessage, TSortingPaging>
    {
        void Insert(T t, TCommon tcommon, ref TMessage tmessage);
        void Update(T t, TCommon tcommon, ref TMessage tmessage);
        void Delete(T t, TCommon tcommon, ref TMessage tmessage);
        void Validate(T t, TCommon tcommon, ref TMessage tmessage);
    }

    public interface IGenericWriteRepository<T1, T2, TCommon, TMessage, TSortingPaging>
    {
        void Insert(T1 t1, T2 t2, TCommon tcommon, ref TMessage tmessage);
        void Update(T1 t1, T2 t2, TCommon tcommon, ref TMessage tmessage);
        void Delete(T1 t1, T2 t2, TCommon tcommon, ref TMessage tmessage);
        void Validate(T1 t1, T2 t2, TCommon tcommon, ref TMessage tmessage);
    }

    public interface IGenericWriteRepository<T1, T2,T3, TCommon, TMessage, TSortingPaging>
    {
        void Insert(T1 t1, T2 t2,T3 t3, TCommon tcommon, ref TMessage tmessage);
        void Update(T1 t1, T2 t2, T3 t3, TCommon tcommon, ref TMessage tmessage);
        void Delete(T1 t1, T2 t2, T3 t3, TCommon tcommon, ref TMessage tmessage);
        void Validate(T1 t1, T2 t2, T3 t3, TCommon tcommon, ref TMessage tmessage);
    }
}
