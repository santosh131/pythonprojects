﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SampleCoreApp.Infrastructure.Base.Interfaces
{
    public interface IGenericReadAllSaveRepository<T, TCommon, TMessage, TSortingPaging> :
       IGenericReadAllRepository<T, TCommon, TMessage, TSortingPaging>,
       IGenericSaveRepository<T, TCommon, TMessage, TSortingPaging>
    {

    }

    public interface IGenericReadAllSaveRepository<T1, T2, TCommon, TMessage, TSortingPaging> :
        IGenericReadAllRepository<T1, T2, TCommon, TMessage, TSortingPaging>,
        IGenericSaveRepository<T1, T2, TCommon, TMessage, TSortingPaging>
    {

    }

    public interface IGenericReadAllSaveRepository<T1, T2, T3, TCommon, TMessage, TSortingPaging> :
        IGenericReadAllRepository<T1, T2, T3, TCommon, TMessage, TSortingPaging>,
        IGenericSaveRepository<T1, T2, T3, TCommon, TMessage, TSortingPaging>
    {

    }
}
