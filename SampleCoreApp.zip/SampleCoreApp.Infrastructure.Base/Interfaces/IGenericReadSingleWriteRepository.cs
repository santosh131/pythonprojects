﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SampleCoreApp.Infrastructure.Base.Interfaces
{
    public interface IGenericReadSingleWriteRepository<T, TCommon, TMessage, TSortingPaging> :
        IGenericReadSingleRepository<T, TCommon, TMessage, TSortingPaging>,
        IGenericWriteRepository<T, TCommon, TMessage, TSortingPaging>
    {

    }

    public interface IGenericReadSingleWriteRepository<T1, T2, TCommon, TMessage, TSortingPaging> :
        IGenericReadSingleRepository<T1, T2, TCommon, TMessage, TSortingPaging>,
        IGenericWriteRepository<T1, T2, TCommon, TMessage, TSortingPaging>
    {

    }

    public interface IGenericReadSingleWriteRepository<T1, T2, T3, TCommon, TMessage, TSortingPaging> :
        IGenericReadSingleRepository<T1, T2, T3, TCommon, TMessage, TSortingPaging>,
        IGenericWriteRepository<T1, T2, T3, TCommon, TMessage, TSortingPaging>
    {

    }
}
