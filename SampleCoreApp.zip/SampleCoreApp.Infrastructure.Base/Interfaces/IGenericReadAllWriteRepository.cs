﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SampleCoreApp.Infrastructure.Base.Interfaces
{
    public interface IGenericReadAllWriteRepository<T, TCommon, TMessage, TSortingPaging> :
      IGenericReadAllRepository<T, TCommon, TMessage, TSortingPaging>,
      IGenericWriteRepository<T, TCommon, TMessage, TSortingPaging>
    {

    }

    public interface IGenericReadAllWriteRepository<T1, T2, TCommon, TMessage, TSortingPaging> :
        IGenericReadAllRepository<T1, T2, TCommon, TMessage, TSortingPaging>,
        IGenericWriteRepository<T1, T2, TCommon, TMessage, TSortingPaging>
    {

    }

    public interface IGenericReadAllWriteRepository<T1, T2, T3, TCommon, TMessage, TSortingPaging> :
        IGenericReadAllRepository<T1, T2, T3, TCommon, TMessage, TSortingPaging>,
        IGenericWriteRepository<T1, T2, T3, TCommon, TMessage, TSortingPaging>
    {

    }
}
