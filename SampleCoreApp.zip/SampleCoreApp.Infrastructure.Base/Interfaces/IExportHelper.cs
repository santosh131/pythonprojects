﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace SampleCoreApp.Infrastructure.Base.Interfaces
{
    public interface IExportHelper
    {
        /// <summary>
        /// Exports the Data
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="dataSource">DataSource</param> 
        /// <param name="exportFileName">ExportFileName</param>
        /// <param name="configDataSource">Configuration DataSource</param>
        /// <param name="hasfileNameDateTime">HasfileNameDateTime</param>
        /// <param name="temporaryFolderPath">TemporaryFolderPath</param>
        void Export<T>(T dataSource,  string exportFileName, T configDataSource, bool hasfileNameDateTime = false, string temporaryFolderPath = "");

        /// <summary>
        /// Exports the Data
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="dataSource">DataSource</param>
        /// <param name="exportFileName">ExportFileName</param>
        /// <param name="configDataSource">Configuration DataSource</param>
        /// <param name="hasfileNameDateTime">HasfileNameDateTime</param>
        /// <param name="temporaryFolderPath">TemporaryFolderPath</param>
        /// <param name="templateFileName">TemplateFileName</param>
        /// <param name="templateFilePath">TemplateFilePath</param>
        void Export<T>(T dataSource, string exportFileName, T configDataSource, bool hasfileNameDateTime = false, string temporaryFolderPath = "", string templateFileName = "", string templateFilePath = "");

        /// <summary>
        /// Exports the Data
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="dataSource">DataSource</param>
        /// <param name="exportFileName">ExportFileName</param>
        /// <param name="configDataSource">Configuration DataSource</param>
        /// <param name="hasfileNameDateTime">HasfileNameDateTime</param>
        /// <param name="temporaryFolderPath">TemporaryFolderPath</param>
        /// <param name="templateFullFileNamePath">templateFullFileNamePath</param>
        void Export<T>(T dataSource,  string exportFileName, T configDataSource, bool hasfileNameDateTime = false, string temporaryFolderPath = "", string templateFullFileNamePath = "");
    }
}
