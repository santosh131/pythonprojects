﻿using SampleCoreApp.Infrastructure.Base.Static;
using SampleCoreApp.Infrastructure.Base.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc.Routing;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.AspNetCore.Razor.TagHelpers;
using SampleCoreApp.Infrastructure.Base.Constants;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using SampleCoreApp.Infrastructure.Base.ApplicationHelpers;

namespace SampleCoreApp.Infrastructure.Base.HtmlTagHelpers
{
    [HtmlTargetElement("div", Attributes = "popup-container")]
    public class PopupTagHelper : TagHelper
    {
        public PopupTagHelper()
        {

        }
        public string PopupContainer { get; set; }

        public string FieldCode { get; set; }

        public string PageCode { get; set; }

        public List<FieldCodeModel> FieldCodeModels { get; set; }

        [ViewContext]
        [HtmlAttributeNotBound]
        public ViewContext ViewContext { get; set; }

        public override async Task ProcessAsync(TagHelperContext context, TagHelperOutput output)
        {
            if (PopupContainer.IsBool())
            {
                string content = output.Content.IsModified ? output.Content.GetContent().Trim() :
                 (await output.GetChildContentAsync()).GetContent().Trim();
                if (FieldCodeModels != null)
                {
                    FieldCodeModel fieldCodeModel = FieldCodeModels.Where(f => f.FieldCode == FieldCode && f.PageCode == PageCode).FirstOrDefault() ?? new FieldCodeModel();
                    output.Attributes.Add(new("data-title", fieldCodeModel?.Description));
                }
            }
        }
    }
}
