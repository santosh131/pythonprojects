﻿using SampleCoreApp.Infrastructure.Base.Static;
using SampleCoreApp.Infrastructure.Base.Constants;
using SampleCoreApp.Infrastructure.Base.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc.Routing;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.AspNetCore.Razor.TagHelpers;

using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Linq;

namespace SampleCoreApp.Infrastructure.Base.HtmlTagHelpers
{
    [HtmlTargetElement("div", Attributes = "sort-model")]
    public class SortLinkTagHelper : TagHelper
    {
        private readonly IUrlHelperFactory urlHelperFactory;

        public SortLinkTagHelper(IUrlHelperFactory helperFactory)
        {
            urlHelperFactory = helperFactory;
        }

        [ViewContext]
        [HtmlAttributeNotBound]
        public ViewContext ViewContext { get; set; }
        public SortingPagingModel SortModel { get; set; }

        public string SortAction { get; set; }

        public string SortText { get; set; }

        public string SortClass { get; set; }

        public string FieldCode { get; set; }

        public string PageCode { get; set; }
        /// <summary>
        /// Gets or Sets FieldRequired 
        /// </summary>
        /// <remarks> Leave empty or true or false</remarks>
        /// <value>String</value>
        public string FieldRequired { get; set; }

        public List<FieldCodeModel> FieldCodeModels { get; set; }

        public override async Task ProcessAsync(TagHelperContext context, TagHelperOutput output)
        {

            string content = output.Content.IsModified ? output.Content.GetContent().Trim() :
              (await output.GetChildContentAsync()).GetContent().Trim();
            if(FieldCode!=null && PageCode!=null && FieldCodeModels!=null && FieldCodeModels.Count>0)
            {
                FieldRequired ??= "";
                FieldCodeModel fieldCodeModel = FieldCodeModels.Where(f => f.FieldCode == FieldCode && f.PageCode == PageCode).FirstOrDefault() ?? new FieldCodeModel();
                content = fieldCodeModel?.Description;

            }
            IUrlHelper urlHelper = urlHelperFactory.GetUrlHelper(ViewContext);
            TagBuilder result = new ("div");
            TagBuilder tag = new ("a");
            string sortOrder = SortOperationsConstants.Ascending;
            TagBuilder tagSpan = new ("i");
            string spanClass = SortOperationsConstants.DescendingClass;
            if (SortModel.SortOrder == SortOperationsConstants.Ascending)
            {
                sortOrder = SortOperationsConstants.Descending;
                spanClass = SortOperationsConstants.AscendingClass;
            }
            spanClass =$"{spanClass} pull-right";
            object routeValues = new { CurrentPageIndex = 1, IsSort = true, IsPaging = false, SortText = SortText, SortOrder = sortOrder };
            tag.Attributes["href"] = urlHelper.Action(SortAction, routeValues);

            ////string queryString = SecurityHelpers.RouteDataToEncrytedString(routeValues);
            //string queryString = SecurityHelpers.RouteDataToEncrytedUrlParamters(routeValues);
            //string actionText= urlHelper.Action(SortAction);
            //tag.Attributes["href"] = actionText+ queryString ;

            if(!string.IsNullOrEmpty(SortClass))
            {
                tag.AddCssClass(SortClass);
            }

            tag.AddCssClass("text-nowrap");
            
            if (SortModel.IsSort && SortModel.SortText == SortText)
            {
                tagSpan.AddCssClass(spanClass);
                tag.InnerHtml.Append(content);
                //tag.InnerHtml.AppendHtml(tagSpan);    
            }
            else
            {
                tag.InnerHtml.Append(content);                
            }
            output.Attributes.Add(new TagHelperAttribute("class", "display-flex"));
            result.InnerHtml.AppendHtml(tag);
            result.InnerHtml.AppendHtml(tagSpan);
            output.Content.AppendHtml(result.InnerHtml);
        }
    }
}
