﻿using SampleCoreApp.Infrastructure.Base.Static;
using SampleCoreApp.Infrastructure.Base.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc.Routing;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.AspNetCore.Razor.TagHelpers;
using SampleCoreApp.Infrastructure.Base.Constants;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using SampleCoreApp.Infrastructure.Base.ApplicationHelpers;

namespace SampleCoreApp.Infrastructure.Base.HtmlTagHelpers
{
    [HtmlTargetElement("input", Attributes = "field-code-models")]
    public class InputTagHelper : TagHelper
    {
        public InputTagHelper()
        {

        }

        public string FieldCode { get; set; }

        public string PageCode { get; set; }

        /// <summary>
        /// Gets or Sets FieldRequired 
        /// </summary>
        /// <remarks> Leave empty or true or false</remarks>
        /// <value>String</value>
        public string FieldRequired { get; set; }

        public List<FieldCodeModel> FieldCodeModels { get; set; }

        [ViewContext]
        [HtmlAttributeNotBound]
        public ViewContext ViewContext { get; set; }

        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            TagHelperAttribute aspForAttr = context.AllAttributes.Where(a => a.Name.ToLower() == "asp-for").FirstOrDefault();
            if (aspForAttr != null)
            {
                FieldRequired ??= "";
                if (FieldCodeModels != null)
                {
                    FieldCodeModel fieldCodeModel = FieldCodeModels.Where(f => f.FieldCode == FieldCode && f.PageCode == PageCode).FirstOrDefault() ?? new FieldCodeModel();
                    string fcDesc = fieldCodeModel?.Description;
                    int? maxWidth = fieldCodeModel?.MaxWidth;
                    string displayName = ((ModelExpression)(aspForAttr.Value)).Metadata.DisplayName ??
                        ((ModelExpression)(aspForAttr.Value)).Metadata.PropertyName;
                    List<TagHelperAttribute> dataValAttrs = output.Attributes.Where(a => a.Name.StartsWith("data-val-")).ToList();
                    List<TagHelperAttribute> tagHelperAttributes = new();
                    object modVal = "";
                    foreach (TagHelperAttribute item in dataValAttrs)
                    {
                        modVal = item.Value?.ToString().Replace(displayName, fcDesc);
                        tagHelperAttributes.Add(new TagHelperAttribute(item.Name, modVal, item.ValueStyle));
                        output.Attributes.Remove(item);
                    }

                    foreach (TagHelperAttribute item in tagHelperAttributes)
                    {
                        if (item.Name.ToLower() == "data-val-required")
                        {
                            if (string.IsNullOrEmpty(FieldRequired) || FieldRequired.ToBool())
                                output.Attributes.Add(item);
                        }
                        else
                        {
                            output.Attributes.Add(item);
                        }
                    }
                    if (maxWidth.HasValue)
                    {
                        TagHelperAttribute styleAttribute0;
                        if (output.Attributes.TryGetAttribute("style", out TagHelperAttribute styleAttribute))
                        {
                            if (!styleAttribute.Value.ToString().ToLower().Contains("max-width"))
                            {
                                styleAttribute0 = new("style", $"{styleAttribute.Value};max-width:{maxWidth}px;");
                                output.Attributes.Add(styleAttribute0);
                            }
                        }
                        else
                        {
                            styleAttribute0 = new("style", $"max-width:{maxWidth}px;");
                            output.Attributes.Add(styleAttribute0);
                        }
                    }
                }
            }
        }
    }
}
