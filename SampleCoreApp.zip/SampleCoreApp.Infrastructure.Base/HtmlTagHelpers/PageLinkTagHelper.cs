﻿using SampleCoreApp.Infrastructure.Base.Static;
using SampleCoreApp.Infrastructure.Base.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc.Routing;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.AspNetCore.Razor.TagHelpers;
using SampleCoreApp.Infrastructure.Base.Constants;
using System;
using System.Collections.Generic;
using System.Text;

namespace SampleCoreApp.Infrastructure.Base.HtmlTagHelpers
{

    [HtmlTargetElement("div", Attributes = "page-model")]
    public class PageLinkTagHelper : TagHelper
    {
        private readonly IUrlHelperFactory urlHelperFactory;

        public PageLinkTagHelper(IUrlHelperFactory helperFactory)
        {
            urlHelperFactory = helperFactory;
        }

        [ViewContext]
        [HtmlAttributeNotBound]
        public ViewContext ViewContext { get; set; }
        public SortingPagingModel PageModel { get; set; }

        public string PageAction { get; set; }

        public string PageClass { get; set; }

        public int? MaxPageNbr { get; set; }

        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            IUrlHelper urlHelper = urlHelperFactory.GetUrlHelper(ViewContext);
            TagBuilder result = new("div");
            object routeValues;
            TagBuilder tag;
            int maxPageNbr = PagerConstants.MaxPageNumber;

            if (MaxPageNbr.HasValue && MaxPageNbr.Value > 0)
            {
                maxPageNbr = MaxPageNbr.Value;
            }

            if (PageModel.TotalPages > maxPageNbr)
            {
                int quotient = (PageModel.CurrentPageIndex - 1) / maxPageNbr;
                int firstIndex = quotient * maxPageNbr + 1;
                int lastIndex = firstIndex + maxPageNbr - 1;

                if (lastIndex > PageModel.TotalPages)
                {
                    lastIndex = PageModel.TotalPages;
                }

                //Before All Pages
                if (firstIndex != 1)
                {
                    //First Page
                    tag = new("a");
                    routeValues = new { CurrentPageIndex = 1, IsSort = PageModel.IsSort, IsPaging = true, SortText = PageModel.SortText, SortOrder = PageModel.SortOrder };
                    CreatePageAnchorElement(urlHelper, PagerConstants.FirstPageCaption, routeValues, PagerConstants.FirstPageClass, "", ref tag);
                    result.InnerHtml.AppendHtml(tag);

                    //Previous Page
                    tag = new("a");
                    routeValues = new { CurrentPageIndex = firstIndex - 1, IsSort = PageModel.IsSort, IsPaging = true, SortText = PageModel.SortText, SortOrder = PageModel.SortOrder };
                    CreatePageAnchorElement(urlHelper, PagerConstants.PreviousPageCaption, routeValues, PagerConstants.PreviousPageClass, "", ref tag);
                    result.InnerHtml.AppendHtml(tag);
                }

                //All Pages
                for (int i = firstIndex; i <= lastIndex; i++)
                {
                    tag = new("a");
                    routeValues = new { CurrentPageIndex = i, IsSort = PageModel.IsSort, IsPaging = true, SortText = PageModel.SortText, SortOrder = PageModel.SortOrder };
                    CreatePageAnchorElement(urlHelper, i.ToString(), routeValues, PagerConstants.PagerClass, PagerConstants.SelectedPageClass, ref tag);
                    result.InnerHtml.AppendHtml(tag);
                }

                //After All Pages
                if (lastIndex != PageModel.TotalPages)
                {
                    //Next Page
                    tag = new("a");
                    routeValues = new { CurrentPageIndex = lastIndex + 1, IsSort = PageModel.IsSort, IsPaging = true, SortText = PageModel.SortText, SortOrder = PageModel.SortOrder };
                    CreatePageAnchorElement(urlHelper, PagerConstants.NextPageCaption, routeValues, PagerConstants.NextPageClass, "", ref tag);
                    result.InnerHtml.AppendHtml(tag);

                    //Last Page
                    if (lastIndex < PageModel.TotalPages)
                    {
                        tag = new("a");
                        routeValues = new { CurrentPageIndex = PageModel.TotalPages, IsSort = PageModel.IsSort, IsPaging = true, SortText = PageModel.SortText, SortOrder = PageModel.SortOrder };
                        CreatePageAnchorElement(urlHelper, PagerConstants.LastPageCaption, routeValues, PagerConstants.LastPageClass, "", ref tag);
                        result.InnerHtml.AppendHtml(tag);
                    }
                }
                result.AddCssClass(PagerConstants.ParentPagerClass);
            }
            else
            {
                //All pages without First Page, Previous, Next, Last Page
                for (int i = 1; i <= PageModel.TotalPages; i++)
                {
                    tag = new("a");
                    routeValues = new { CurrentPageIndex = i, IsSort = PageModel.IsSort, IsPaging = true, SortText = PageModel.SortText, SortOrder = PageModel.SortOrder };
                    CreatePageAnchorElement(urlHelper, i.ToString(), routeValues, PagerConstants.PagerClass, PagerConstants.SelectedPageClass, ref tag);
                    result.InnerHtml.AppendHtml(tag);
                }
            }

            TagBuilder divParent = new("div");
            divParent.InnerHtml.AppendHtml(result);
            output.Content.AppendHtml(divParent.InnerHtml);
        }

        /// <summary>
        /// Sets the Page anchor elements
        /// </summary>
        /// <param name="urlHelper">UrlHelper</param>
        /// <param name="pageIndex">PageIndex</param>
        /// <param name="routeValues">RouteValues</param>
        /// <param name="pageLinkClass">PageLinkClass</param>
        /// <param name="pageLinkSelectedClass">pageLinkSelectedClass</param>
        /// <param name="tagBuilder">TagBuilder</param>
        /// <returns>TagBuilder</returns>
        private TagBuilder CreatePageAnchorElement(IUrlHelper urlHelper, string pageIndex, object routeValues, string pageLinkClass, string pageLinkSelectedClass, ref TagBuilder tagBuilder)
        {

            tagBuilder.Attributes["href"] = urlHelper.Action(PageAction, routeValues);

            //routeValues = new { CurrentPageIndex = i, IsSort = PageModel.IsSort, IsPaging = true, SortText = PageModel.SortText, SortOrder = PageModel.SortOrder };
            //queryString = SecurityHelpers.RouteDataToEncrytedString(routeValues);
            //tag.Attributes["href"] = urlHelper.Action(PageAction + queryString); ;

            if (!string.IsNullOrEmpty(PageClass))
            {
                tagBuilder.AddCssClass(PageClass);
            }

            tagBuilder.InnerHtml.Append(pageIndex);
            if (PageModel?.CurrentPageIndex.ToString() == pageIndex)
                tagBuilder.AddCssClass(pageLinkSelectedClass);
            else
                tagBuilder.AddCssClass(pageLinkClass);

            return tagBuilder;
        }
    }


}
