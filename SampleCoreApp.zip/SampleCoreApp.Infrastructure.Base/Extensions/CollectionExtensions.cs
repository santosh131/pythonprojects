﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Reflection;
using System.Text;
using System.Linq;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using SampleCoreApp.Infrastructure.Base.ApplicationHelpers;

namespace SampleCoreApp.Infrastructure.Base.Extensions
{
    public static class CollectionExtensions
    {
        /// <summary>
        /// Converts the list to DataTable
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="ts">List<T></param>
        /// <paramref name="fromDbColumn">FromDbColumn</paramref>
        /// <returns>DataTable</returns>
        public static DataTable ToDataTable<T>(this List<T> ts, bool fromDbColumn = true)
        {
            T obj = Activator.CreateInstance<T>();
            DataTable dataTable = new();
            string dbcolName;
            foreach (PropertyInfo prop in obj.GetType().GetProperties())
            {
                dbcolName = prop.Name;

                if (fromDbColumn)
                    dbcolName = AttributesHelper.GetDbColumnAttributeVal(prop);

                dataTable.Columns.Add(dbcolName);
            }

            foreach (T currObj in ts)
            {
                DataRow item = dataTable.NewRow();
                foreach (DataColumn col in dataTable.Columns)
                {
                    PropertyInfo prop = currObj.GetType().GetProperty(col.ColumnName);
                    if (prop != null && !object.Equals(prop.GetValue(currObj), DBNull.Value))
                    {
                        item[col.ColumnName] = prop.GetValue(currObj);
                    }
                }
                dataTable.Rows.Add(item);
            }
            return dataTable;
        }

        /// <summary>
        /// Converts the list to DataTable
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="ts">List<T></param>
        /// <returns>string</returns>
        public static string ToJson<T>(this List<T> ts)
        {
            return Newtonsoft.Json.JsonConvert.SerializeObject(ts);
        }

        /// <summary>
        /// Deep copy of list- Class should be marked with serializable attribute
        /// </summary>
        /// <typeparam name="T">T</typeparam>
        /// <param name="ts">List<T></param>
        /// <returns>List<T></returns>
        public static List<T> Clone<T>(this List<T> ts)
        {
            try
            {
                BinaryFormatter formatter = new();
                MemoryStream stream = new();
                formatter.Serialize(stream, ts);
                stream.Position = 0;
                return (List<T>)formatter.Deserialize(stream);
            }
            catch (Exception)
            {
                try
                {
                    List<T> t1 = new();
                    t1.AddRange(ts);
                    return t1;
                }
                catch (Exception)
                {
                }
            }
            return null;
        }

    }
}
