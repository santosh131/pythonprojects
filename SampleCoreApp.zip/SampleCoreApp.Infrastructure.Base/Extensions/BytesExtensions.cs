using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;
using System.Drawing;
using System.IO;

namespace SampleCoreApp.Infrastructure.Base.ApplicationHelpers
{
    public static class BytesExtensions
    {
        //TODO:
    }
}