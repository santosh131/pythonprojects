﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;
namespace SampleCoreApp.Infrastructure.Base.ApplicationHelpers
{
    public static class SessionExtensionsHelper
    {
        /// <summary>
        /// Sets object to session as string
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="session"></param>
        /// <param name="key"></param>
        /// <param name="value"></param>
        public static void Set<T>(this ISession session, string key, T value)
        {
            session.SetString(key, ObjectHelper.ToJsonString(value));
        }

        /// <summary>
        /// Gets the object from session
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="session"></param>
        /// <param name="key"></param>
        /// <returns></returns>
        public static T Get<T>(this ISession session, string key)
        {
            var value = session.GetString(key);
            return value == null ? default : value.ToObjectFromJsonString<T>();
        }
    }
}
