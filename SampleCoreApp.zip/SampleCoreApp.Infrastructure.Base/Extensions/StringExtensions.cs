﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;

namespace SampleCoreApp.Infrastructure.Base.ApplicationHelpers
{
    public static class StringExtensionHelper
    {
        public const string EmailRegex = @"^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$";

        #region Validates the value
        /// <summary>
        /// Checks if string is valid bool or not
        /// </summary>
        /// <param name="val">Value</param>
        /// <returns>bool</returns>
        public static bool IsBool(this string val)
        {
            try
            {
                bool.Parse(val);
                return true;
            }
            catch (Exception)
            {

            }
            return false;
        }

        public static DateTime Date1900 = new(1900, 1, 1);

        /// <summary>
        /// Checks if string is valid DateTime or not
        /// </summary>
        /// <param name="val">Value</param>
        /// <returns>bool</returns>
        public static bool IsDateTime(this string val)
        {
            try
            {
                DateTime.Parse(val);
                return true;
            }
            catch (Exception)
            {

            }
            return false;
        }

        /// <summary>
        /// Checks if string is valid DateTime and greater than 1900 or not
        /// </summary>
        /// <param name="val">Value</param>
        /// <returns>bool</returns>
        public static bool IsDateTimeAndGreaterThan1900(this string val)
        {
            try
            { 
                if (DateTime.Parse(val) >= Date1900)
                    return true; 
            }
            catch (Exception)
            {

            }
            return false;
        }

        /// <summary>
        /// Checks if string is valid Sql DateTime or not
        /// </summary>
        /// <param name="val">Value</param>
        /// <returns>bool</returns>
        public static bool IsSqlDateTime(this string val)
        {
            try
            {
                if (val.IsDateTime())
                {
                    if (DateTime.Parse(val) > SqlDateTime.MinValue && DateTime.Parse(val) <= SqlDateTime.MaxValue)
                        return true;
                }

            }
            catch (Exception)
            {

            }
            return false;
        }

        /// <summary>
        /// Checks if string is valid Sql DateTime or not
        /// </summary>
        /// <param name="val">Value</param>
        /// <returns>bool</returns>
        public static bool IsSqlDateTimeAndGreaterThan1900(this string val)
        {
            try
            {
                if (val.IsDateTimeAndGreaterThan1900())
                {
                    if (DateTime.Parse(val) > SqlDateTime.MinValue && DateTime.Parse(val) <= SqlDateTime.MaxValue)
                        return true;
                }

            }
            catch (Exception)
            {

            }
            return false;
        }

        /// <summary>
        /// Checks if string is valid Decimal or not
        /// </summary>
        /// <param name="val">Value</param>
        /// <returns>bool</returns>
        public static bool IsDecimal(this string val)
        {
            try
            {
                decimal.Parse(val);
                return true;
            }
            catch (Exception)
            {

            }
            return false;
        }

        /// <summary>
        /// Checks if string is valid Double or not
        /// </summary>
        /// <param name="val">Value</param>
        /// <returns>bool</returns>
        public static bool IsDouble(this string val)
        {
            try
            {
                double.Parse(val);
                return true;
            }
            catch (Exception)
            {

            }
            return false;
        }

        /// <summary>
        /// Checks if string is valid Float or not
        /// </summary>
        /// <param name="val">Value</param>
        /// <returns>bool</returns>
        public static bool IsFloat(this string val)
        {
            try
            {
                float.Parse(val);
                return true;
            }
            catch (Exception)
            {

            }
            return false;
        }

        /// <summary>
        /// Checks if string is valid Integer or not
        /// </summary>
        /// <param name="val">Value</param>
        /// <returns>bool</returns>
        public static bool IsInteger(this string val)
        {
            try
            {
                int.Parse(val);
                return true;
            }
            catch (Exception)
            {

            }
            return false;
        }

        /// <summary>
        /// Checks if string is valid Integer64 or not
        /// </summary>
        /// <param name="val">Value</param>
        /// <returns>bool</returns>
        public static bool IsInteger64(this string val)
        {
            try
            {
                Int64.Parse(val);
                return true;
            }
            catch (Exception)
            {

            }
            return false;
        }

        /// <summary>
        /// Checks if string is valid Email or not
        /// </summary>
        /// <param name="val">Value</param>
        /// <returns>bool</returns>
        public static bool IsEmail(this string val)
        {
            try{                
                if (string.IsNullOrEmpty(val))
                {
                    return true;
                }
                var regex = new Regex(EmailRegex);
                return regex.IsMatch(val);            
            }
            catch{
                return false;
            }
        }

        /// <summary>
        /// Checks if string has valid Email's or not
        /// </summary>
        /// <param name="val">Value</param>
        /// <returns>bool</returns>
        public static bool IsMultipleEmail(this string val, string delimiter)
        {
             try{   
                string[] s=val.Split(new string[]{delimiter}, StringSplitOptions.None);
                for(int i=0;i<s.Length;i++){
                    if(!s[i].IsEmail())
                    {
                        return false;
                    }
                }
             }
             catch{
                return false;
            }
            return true;
        }

        /// <summary>
        /// Checks if string is valid XML or not
        /// </summary>
        /// <param name="val">Value</param>
        /// <returns>bool</returns>
        public static bool IsXML(this string val)
        {
            try
            {
                XmlDocument xmlDocument = new();
                xmlDocument.LoadXml(val);
                return true;
            }
            catch (Exception)
            {

            }
            return false;
        }

        /// <summary>
        /// Checks if string is valid Json or not
        /// </summary>
        /// <param name="val">Value</param>
        /// <returns>bool</returns>
        public static bool IsJson(this string val)
        {
            try
            {
                Newtonsoft.Json.JsonConvert.DeserializeObject(val);
                return true;
            }
            catch (Exception)
            {

            }
            return false;
        }
        #endregion

        //----------------------------------------------------------//

        #region Converts string to different objects
        /// <summary>
        /// Converts Json string to List of objects
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="val"></param>
        /// <returns>List<T></returns>
        public static List<T> ToListFromJsonString<T>(this string val)
        {
            if (val.IsJson())
            {
                try
                {
                    return Newtonsoft.Json.JsonConvert.DeserializeObject<List<T>>(val);
                }
                catch (Exception)
                {

                }
            }
            return new List<T>();
        }

        /// <summary>
        /// Converts Json string to object
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="val"></param>
        /// <returns>List<T></returns>
        public static T ToObjectFromJsonString<T>(this string val)
        {
            try
            {
                return Newtonsoft.Json.JsonConvert.DeserializeObject<T>(val);
            }
            catch (Exception)
            {

            }
            return default;
        }

        /// <summary>
        /// Converts string to DateTime
        /// </summary>
        /// <param name="val">Value</param>
        /// <returns>int</returns>
        public static DateTime ToDateTime(this string val)
        {

            if (val.IsDateTime())
                return DateTime.Parse(val);
            else
                return new DateTime();
        }

        /// <summary>
        /// Converts string to DateTime
        /// </summary>
        /// <param name="val">Value</param>
        /// <returns>int</returns>
        public static DateTime ToSqlDateTime(this string val)
        {

            if (val.IsSqlDateTime())
                return DateTime.Parse(val);
            else
                return new DateTime();
        }

        /// <summary>
        /// Converts string to integer
        /// </summary>
        /// <param name="val">Value</param>
        /// <returns>int</returns>
        public static int ToInteger(this string val)
        {

            if (val.IsInteger())
                return int.Parse(val);
            else
                return 0;
        }

        /// <summary>
        /// Converts string to Integer64
        /// </summary>
        /// <param name="val">Value</param>
        /// <returns>int</returns>
        public static Int64 ToInteger64(this string val)
        {
            if (val.IsInteger64())
                return Int64.Parse(val);
            else
                return 0;
        }

        /// <summary>
        /// Converts string to Decimal
        /// </summary>
        /// <param name="val">Value</param>
        /// <returns>decimal</returns>
        public static decimal ToDecimal(this string val)
        {

            if (val.IsDecimal())
                return decimal.Parse(val);
            else
                return 0;
        }

        /// <summary>
        /// Converts string to Bool
        /// </summary>
        /// <param name="val">Value</param>
        /// <returns>decimal</returns>
        public static bool ToBool(this string val)
        {
            if (val.IsBool())
                return bool.Parse(val);
            else if (val == "1" || val.ToUpper() == "T" || val.ToUpper() == "TRUE")
                return true;
            else if (val == "0" || val.ToUpper() == "F" || val.ToUpper() == "FALSE")
                return false;
            else
                return false;
        }

        /// <summary>
        /// Converts string to DateTime
        /// </summary>
        /// <param name="val">Value</param>
        /// <returns>int</returns>
        public static DateTime? ToNullableDateTime(this string val)
        {
            if (val == null)
                return null;
            else if (val.IsDateTime())
                return DateTime.Parse(val);
            else
                return null;
        }

        /// <summary>
        /// Converts string to Sql DateTime
        /// </summary>
        /// <param name="val">Value</param>
        /// <returns>int</returns>
        public static object ToNullablSqlDateTime(this string val)
        {

            if (val.IsSqlDateTime())
                return DateTime.Parse(val);
            else
                return DBNull.Value;
        }

        /// <summary>
        /// Converts string to integer
        /// </summary>
        /// <param name="val">Value</param>
        /// <returns>int</returns>
        public static int? ToNullableInteger(this string val)
        {
            if (val == null)
                return null;
            else if (val.IsInteger())
                return int.Parse(val);
            else
                return null;
        }

        /// <summary>
        /// Converts string to Integer64
        /// </summary>
        /// <param name="val">Value</param>
        /// <returns>int</returns>
        public static Int64? ToNullableInteger64(this string val)
        {
            if (val == null)
                return null;
            else if (val.IsInteger64())
                return Int64.Parse(val);
            else
                return null;
        }

        /// <summary>
        /// Converts string to Decimal
        /// </summary>
        /// <param name="val">Value</param>
        /// <returns>decimal</returns>
        public static decimal? ToNullableDecimal(this string val)
        {
            if (val == null)
                return null;
            else if (val.IsDecimal())
            {
                decimal? d = decimal.Parse(val);
                return d;
            }
            else
                return null;
        }
        /// <summary>
        /// Converts string to Float
        /// </summary>
        /// <param name="val">Value</param>
        /// <returns>float</returns>
        public static float? ToNullableFloat(this string val)
        {
            if (val == null)
                return null;
            else if (val.IsFloat())
            {
                float? d = float.Parse(val);
                return d;
            }
            else
                return null;
        }

        /// <summary>
        /// Converts string to Double
        /// </summary>
        /// <param name="val">Value</param>
        /// <returns>double</returns>
        public static double? ToNullableDouble(this string val)
        {
            if (val == null)
                return null;
            else if (val.IsDouble())
            {
                double? d = double.Parse(val);
                return d;
            }
            else
                return null;
        }

        /// <summary>
        /// Converts string to Bool
        /// </summary>
        /// <param name="val">Value</param>
        /// <returns>decimal</returns>
        public static bool? ToNullableBool(this string val)
        {
            if (val == null)
                return null;
            else if (val.IsBool())
                return bool.Parse(val);
            else if (val == "1" || val.ToUpper() == "T" || val.ToUpper() == "TRUE")
                return true;
            else if (val == "0" || val.ToUpper() == "F" || val.ToUpper() == "FALSE")
                return false;
            else
                return null;
        }
        #endregion
    }
}
