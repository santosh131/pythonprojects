﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SSO;
using SSO.Constants;
using System.Security.Cryptography;
using System.Security.Cryptography.Xml;

namespace DemoSAMLApp
{
    public static class TenantHelper
    {
        public static  void SetTenants(bool isIDP = false)
        {
            List<SSOTenantDetail> lst = new List<SSOTenantDetail>();
            if (isIDP)
            {
                SSOTenantDetail tenantDetail = new SSOTenantDetail();
                tenantDetail.TenantId = "48";
                tenantDetail.Destination = "http://localhost/ICaptureDevSSO/IPublic/SSOHome.aspx?token_type=SAML&dcode=" + tenantDetail.TenantId;
                tenantDetail.AssertionConsumerServiceURL = "http://localhost/SSGIdpServer/IdpLogin.aspx";
                tenantDetail.Issuer = "http://localhost/SSGIdpServer";
                tenantDetail.CertificateIssueNbr = "5d587444fdf1a69446cbce3c19a07005";
                tenantDetail.CertificateFileName = "c:\\temp\\SSOCertificate.pfx";
                tenantDetail.CertificateFilePassword = "test123";
                tenantDetail.SAMLResponseMethod = SamlResponseConstants.SignedSAMlUnsignedAssertion;
                tenantDetail.EncodingMethod = EncodingMethodConstants.UTF8;
                //tenantDetail.EncryptionDataAlgorithm = EncryptionDataConstants.AES256_CBC;
                //tenantDetail.EncryptionKeyAlgorithm = EncryptionKeyConstants.RSA_OAEP_MGF1P;
                lst.Add(tenantDetail);

                tenantDetail = new SSOTenantDetail();
                tenantDetail.TenantId = "65";
                tenantDetail.Destination = "http://localhost/ICaptureDevSSO/IPublic/SSOHome.aspx?token_type=SAML&dcode=" + tenantDetail.TenantId;
                tenantDetail.AssertionConsumerServiceURL = "http://localhost/SSGIdpServer/IdpLogin.aspx";
                tenantDetail.Issuer = "http://localhost/SSGIdpServer";
                tenantDetail.CertificateIssueNbr = "5d587444fdf1a69446cbce3c19a07005";
                tenantDetail.CertificateFileName = "c:\\temp\\SSOCertificate.pfx";
                tenantDetail.CertificateFilePassword = "test123";
                tenantDetail.SAMLResponseMethod = SamlResponseConstants.UnsignedSAMlEncryptedAssertion;
                tenantDetail.EncodingMethod = EncodingMethodConstants.UTF8;
                //tenantDetail.EncryptionDataAlgorithm = EncryptionDataConstants.AES256_CBC;
                //tenantDetail.EncryptionKeyAlgorithm = EncryptionKeyConstants.RSA_OAEP_MGF1P;
                lst.Add(tenantDetail);
            }
            else
            {
                SSOTenantDetail tenantDetail = new SSOTenantDetail();
                tenantDetail.TenantId = "48";
                tenantDetail.Destination = "http://localhost/SSGIdpServer/IdpLogin.aspx";
                tenantDetail.AssertionConsumerServiceURL = "http://localhost/ICaptureDevSSO/IPublic/SSOHome.aspx?token_type=SAML&dcode=" + tenantDetail.TenantId;
                tenantDetail.Issuer = "http://localhost/ICaptureDevSSO";
                tenantDetail.CertificateIssueNbr = "5d587444fdf1a69446cbce3c19a07005";
                tenantDetail.CertificateFileName = "c:\\temp\\SSOCertificate.pfx";
                tenantDetail.CertificateFilePassword = "test123";
                tenantDetail.SAMLResponseMethod = SamlResponseConstants.SignedSAMlUnsignedAssertion;
                tenantDetail.EncodingMethod = EncodingMethodConstants.UTF8;
                tenantDetail.EncryptionDataAlgorithm = EncryptedXml.XmlEncAES256Url;
                tenantDetail.EncryptionKeyAlgorithm = EncryptionKeyConstants.RSA_OAEP_MGF1P;
                lst.Add(tenantDetail);

                tenantDetail = new SSOTenantDetail();
                tenantDetail.TenantId = "65";
                tenantDetail.Destination = "http://localhost/SSGIdpServer/IdpLogin.aspx";
                tenantDetail.AssertionConsumerServiceURL = "http://localhost/ICaptureDevSSO/IPublic/SSOHome.aspx?token_type=SAML&dcode=" + tenantDetail.TenantId;
                tenantDetail.Issuer = "http://localhost/ICaptureDevSSO";
                tenantDetail.CertificateIssueNbr = "5d587444fdf1a69446cbce3c19a07005";
                tenantDetail.CertificateFileName = "c:\\temp\\SSOCertificate.pfx";
                tenantDetail.CertificateFilePassword = "test123";
                tenantDetail.SAMLResponseMethod = SamlResponseConstants.UnsignedSAMlEncryptedAssertion;
                tenantDetail.EncodingMethod = EncodingMethodConstants.UTF8;
                //tenantDetail.EncryptionDataAlgorithm = EncryptionDataConstants.AES256_CBC;
                //tenantDetail.EncryptionKeyAlgorithm = EncryptionKeyConstants.RSA_OAEP_MGF1P;
                lst.Add(tenantDetail);

            }
            foreach (var item in lst)
            {
                SSOTenants.RegisterTenant(item);
            }

        }
    }
}
