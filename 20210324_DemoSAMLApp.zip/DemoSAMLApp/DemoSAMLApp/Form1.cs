﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using SSO;
using System.Security.Cryptography.X509Certificates;
using System.Xml;

namespace DemoSAMLApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            SSO.SSOTenants.ClearTenants();
            TenantHelper.SetTenants();
        }

        private string _tenantId = "48";
        private Dictionary<string, string> Attributes
        {
            get
            {
                Dictionary<string, string> dic = new Dictionary<string, string>();
                dic.Add("disctrictcode", "48");
                dic.Add("username", "sjanapala");
                return dic;
            }
        }

        private void btnCreateRequest_Click(object sender, EventArgs e)
        {
            string samlMethod = comboBox1.SelectedItem.ToString();
            SSOTenantDetail tenantDetail = SSOTenants.TenantDetails.Where(c => c.TenantId == _tenantId).FirstOrDefault();
            if (tenantDetail != null)
            {
                tenantDetail.SAMLResponseMethod = samlMethod;
                SAMLDocumentModel output;
                BaseSAML baseSAML;
                SAMLConcrete samlConcrete = new SAMLConcrete();
                samlConcrete.SAMLModel = SAMLHelper.FillModelFromTenant(tenantDetail);
                samlConcrete.SAMLModel.Attributes = Attributes;
                baseSAML = samlConcrete.GetBaseSAML();
                output = baseSAML.CreateRequest();
                if (baseSAML.IsOperation)
                {
                    txtCreateOutput.Text = output.XmlDocument.OuterXml;
                    txtCreateOutputBytes.Text = output.GetBase64String();
                }
                else
                    MessageBox.Show(baseSAML.OperationFailedMessage);
            }
        }

        private void btnReadRequest_Click(object sender, EventArgs e)
        {
            string samlMethod = comboBox1.SelectedItem.ToString();
            SSOTenantDetail tenantDetail = SSOTenants.TenantDetails.Where(c => c.TenantId == _tenantId).FirstOrDefault();
            if (tenantDetail != null)
            {
                tenantDetail.SAMLResponseMethod = samlMethod;
                SAMLDocumentModel output;
                BaseSAML baseSAML;
                SAMLConcrete samlConcrete = new SAMLConcrete();
                samlConcrete.SAMLModel = SAMLHelper.FillModelFromTenant(tenantDetail);
                samlConcrete.SAMLModel.Attributes = Attributes;
                samlConcrete.SAMLModel.RequestResponse = txtCreateOutputBytes.Text;
                baseSAML = samlConcrete.GetBaseSAML();
                output = baseSAML.ReadRequest();
                if (baseSAML.IsOperation)
                {
                    txtReadOutput.Text = output.XmlDocument.OuterXml;
                }
                else
                    MessageBox.Show(baseSAML.OperationFailedMessage);
            }
        }

        private void btnCreateResponse_Click(object sender, EventArgs e)
        {
            string samlMethod = comboBox1.SelectedItem.ToString();
            SSOTenantDetail tenantDetail = SSOTenants.TenantDetails.Where(c => c.TenantId == _tenantId).FirstOrDefault();
            if (tenantDetail != null)
            {
                tenantDetail.SAMLResponseMethod = samlMethod;
                SAMLDocumentModel output;
                BaseSAML baseSAML;
                SAMLConcrete samlConcrete = new SAMLConcrete();
                samlConcrete.SAMLModel = SAMLHelper.FillModelFromTenant(tenantDetail);
                samlConcrete.SAMLModel.Attributes = Attributes;
                samlConcrete.SAMLModel.RequestResponse = txtCreateOutputBytes.Text;
                baseSAML = samlConcrete.GetBaseSAML();
                output = baseSAML.CreateResponse();
                if (baseSAML.IsOperation)
                {
                    txtCreateResponseOutput.Text = output.XmlDocument.OuterXml;
                    txtCreateResponseOutputBytes.Text = output.GetBase64String();
                }
                else
                    MessageBox.Show(baseSAML.OperationFailedMessage);
            }
        }

        private void btnReadResponse_Click(object sender, EventArgs e)
        {
            try
            {

                string samlMethod = comboBox1.SelectedItem.ToString();
                SSOTenantDetail tenantDetail = SSOTenants.TenantDetails.Where(c => c.TenantId == _tenantId).FirstOrDefault();
                if (tenantDetail != null)
                {
                    tenantDetail.SAMLResponseMethod = samlMethod;
                    SAMLDocumentModel output;
                    BaseSAML baseSAML;
                    SAMLConcrete samlConcrete = new SAMLConcrete();
                    samlConcrete.SAMLModel = SAMLHelper.FillModelFromTenant(tenantDetail);
                    samlConcrete.SAMLModel.Attributes = Attributes;
                    XmlDocument xdoc = new XmlDocument();
                    if (txtCreateResponseOutput.Text != "")
                    {
                        xdoc.LoadXml(txtCreateResponseOutput.Text);
                        txtCreateResponseOutputBytes.Text = System.Convert.ToBase64String(Encoding.UTF8.GetBytes(xdoc.OuterXml));
                    }
                    samlConcrete.SAMLModel.RequestResponse = txtCreateResponseOutputBytes.Text;
                    baseSAML = samlConcrete.GetBaseSAML();
                    output = baseSAML.ReadResponse();
                    if (baseSAML.IsOperation)
                        txtReadResponseOutput.Text = output.XmlDocument.OuterXml;
                    else
                        MessageBox.Show(baseSAML.OperationFailedMessage);

                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnXMLRequestToBytes_Click(object sender, EventArgs e)
        {
            SAMLDocumentModel output = new SAMLDocumentModel();
            output.XmlDocument = new System.Xml.XmlDocument();
            output.XmlDocument.LoadXml(txtCreateOutput.Text);
            txtCreateOutputBytes.Text = output.GetBase64String();
        }

        private void btnClearAll_Click(object sender, EventArgs e)
        {
            txtCreateOutput.Text = string.Empty;
            txtCreateOutputBytes.Text = string.Empty;
            txtReadOutput.Text = string.Empty;
            txtCreateResponseOutput.Text = string.Empty;
            txtCreateResponseOutputBytes.Text = string.Empty;
            txtReadResponseOutput.Text = string.Empty;
        }
    }
}
