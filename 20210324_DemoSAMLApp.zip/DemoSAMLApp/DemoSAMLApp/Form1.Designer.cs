﻿namespace DemoSAMLApp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCreateRequest = new System.Windows.Forms.Button();
            this.btnReadRequest = new System.Windows.Forms.Button();
            this.btnCreateResponse = new System.Windows.Forms.Button();
            this.btnReadResponse = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtCreateOutput = new System.Windows.Forms.RichTextBox();
            this.txtReadOutput = new System.Windows.Forms.RichTextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtCreateOutputBytes = new System.Windows.Forms.RichTextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtCreateResponseOutputBytes = new System.Windows.Forms.RichTextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtCreateResponseOutput = new System.Windows.Forms.RichTextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtReadResponseOutput = new System.Windows.Forms.RichTextBox();
            this.btnXMLRequestToBytes = new System.Windows.Forms.Button();
            this.btnClearAll = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnCreateRequest
            // 
            this.btnCreateRequest.Location = new System.Drawing.Point(38, 167);
            this.btnCreateRequest.Name = "btnCreateRequest";
            this.btnCreateRequest.Size = new System.Drawing.Size(132, 46);
            this.btnCreateRequest.TabIndex = 0;
            this.btnCreateRequest.Text = "Create Request";
            this.btnCreateRequest.UseVisualStyleBackColor = true;
            this.btnCreateRequest.Click += new System.EventHandler(this.btnCreateRequest_Click);
            // 
            // btnReadRequest
            // 
            this.btnReadRequest.Location = new System.Drawing.Point(38, 281);
            this.btnReadRequest.Name = "btnReadRequest";
            this.btnReadRequest.Size = new System.Drawing.Size(132, 46);
            this.btnReadRequest.TabIndex = 1;
            this.btnReadRequest.Text = "Read Request";
            this.btnReadRequest.UseVisualStyleBackColor = true;
            this.btnReadRequest.Click += new System.EventHandler(this.btnReadRequest_Click);
            // 
            // btnCreateResponse
            // 
            this.btnCreateResponse.Location = new System.Drawing.Point(38, 350);
            this.btnCreateResponse.Name = "btnCreateResponse";
            this.btnCreateResponse.Size = new System.Drawing.Size(132, 46);
            this.btnCreateResponse.TabIndex = 2;
            this.btnCreateResponse.Text = "Create Response";
            this.btnCreateResponse.UseVisualStyleBackColor = true;
            this.btnCreateResponse.Click += new System.EventHandler(this.btnCreateResponse_Click);
            // 
            // btnReadResponse
            // 
            this.btnReadResponse.Location = new System.Drawing.Point(38, 418);
            this.btnReadResponse.Name = "btnReadResponse";
            this.btnReadResponse.Size = new System.Drawing.Size(132, 46);
            this.btnReadResponse.TabIndex = 3;
            this.btnReadResponse.Text = "Read Response";
            this.btnReadResponse.UseVisualStyleBackColor = true;
            this.btnReadResponse.Click += new System.EventHandler(this.btnReadResponse_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "UnsignedSAMlUnsignedAssertion",
            "SignedSAMlUnsignedAssertion",
            "UnsignedSAMlSignedAssertion",
            "SignedSAMlSignedAssertion",
            "UnsignedSAMlEncryptedAssertion"});
            this.comboBox1.Location = new System.Drawing.Point(138, 22);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(228, 21);
            this.comboBox1.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(38, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "SAML Method";
            // 
            // txtCreateOutput
            // 
            this.txtCreateOutput.Location = new System.Drawing.Point(196, 96);
            this.txtCreateOutput.Name = "txtCreateOutput";
            this.txtCreateOutput.Size = new System.Drawing.Size(462, 117);
            this.txtCreateOutput.TabIndex = 6;
            this.txtCreateOutput.Text = "";
            // 
            // txtReadOutput
            // 
            this.txtReadOutput.Location = new System.Drawing.Point(664, 99);
            this.txtReadOutput.Name = "txtReadOutput";
            this.txtReadOutput.Size = new System.Drawing.Size(462, 252);
            this.txtReadOutput.TabIndex = 7;
            this.txtReadOutput.Text = "";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(369, 80);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "Create Output";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(876, 80);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "Read Output";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(369, 220);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(113, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "Create Output in Bytes";
            // 
            // txtCreateOutputBytes
            // 
            this.txtCreateOutputBytes.Location = new System.Drawing.Point(196, 236);
            this.txtCreateOutputBytes.Name = "txtCreateOutputBytes";
            this.txtCreateOutputBytes.Size = new System.Drawing.Size(462, 115);
            this.txtCreateOutputBytes.TabIndex = 10;
            this.txtCreateOutputBytes.Text = "";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(369, 588);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(164, 13);
            this.label5.TabIndex = 15;
            this.label5.Text = "Create Response Output in Bytes";
            // 
            // txtCreateResponseOutputBytes
            // 
            this.txtCreateResponseOutputBytes.Location = new System.Drawing.Point(196, 604);
            this.txtCreateResponseOutputBytes.Name = "txtCreateResponseOutputBytes";
            this.txtCreateResponseOutputBytes.Size = new System.Drawing.Size(462, 115);
            this.txtCreateResponseOutputBytes.TabIndex = 14;
            this.txtCreateResponseOutputBytes.Text = "";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(369, 448);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(124, 13);
            this.label6.TabIndex = 13;
            this.label6.Text = "Create Response Output";
            // 
            // txtCreateResponseOutput
            // 
            this.txtCreateResponseOutput.Location = new System.Drawing.Point(196, 464);
            this.txtCreateResponseOutput.Name = "txtCreateResponseOutput";
            this.txtCreateResponseOutput.Size = new System.Drawing.Size(462, 117);
            this.txtCreateResponseOutput.TabIndex = 12;
            this.txtCreateResponseOutput.Text = "";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(876, 445);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(119, 13);
            this.label7.TabIndex = 17;
            this.label7.Text = "Read Response Output";
            // 
            // txtReadResponseOutput
            // 
            this.txtReadResponseOutput.Location = new System.Drawing.Point(664, 464);
            this.txtReadResponseOutput.Name = "txtReadResponseOutput";
            this.txtReadResponseOutput.Size = new System.Drawing.Size(462, 252);
            this.txtReadResponseOutput.TabIndex = 16;
            this.txtReadResponseOutput.Text = "";
            // 
            // btnXMLRequestToBytes
            // 
            this.btnXMLRequestToBytes.Location = new System.Drawing.Point(38, 222);
            this.btnXMLRequestToBytes.Name = "btnXMLRequestToBytes";
            this.btnXMLRequestToBytes.Size = new System.Drawing.Size(132, 46);
            this.btnXMLRequestToBytes.TabIndex = 18;
            this.btnXMLRequestToBytes.Text = "XML Request to Bytes";
            this.btnXMLRequestToBytes.UseVisualStyleBackColor = true;
            this.btnXMLRequestToBytes.Click += new System.EventHandler(this.btnXMLRequestToBytes_Click);
            // 
            // btnClearAll
            // 
            this.btnClearAll.Location = new System.Drawing.Point(41, 640);
            this.btnClearAll.Name = "btnClearAll";
            this.btnClearAll.Size = new System.Drawing.Size(132, 46);
            this.btnClearAll.TabIndex = 19;
            this.btnClearAll.Text = "Clear All";
            this.btnClearAll.UseVisualStyleBackColor = true;
            this.btnClearAll.Click += new System.EventHandler(this.btnClearAll_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1158, 781);
            this.Controls.Add(this.btnClearAll);
            this.Controls.Add(this.btnXMLRequestToBytes);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtReadResponseOutput);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtCreateResponseOutputBytes);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtCreateResponseOutput);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtCreateOutputBytes);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtReadOutput);
            this.Controls.Add(this.txtCreateOutput);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.btnReadResponse);
            this.Controls.Add(this.btnCreateResponse);
            this.Controls.Add(this.btnReadRequest);
            this.Controls.Add(this.btnCreateRequest);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCreateRequest;
        private System.Windows.Forms.Button btnReadRequest;
        private System.Windows.Forms.Button btnCreateResponse;
        private System.Windows.Forms.Button btnReadResponse;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RichTextBox txtCreateOutput;
        private System.Windows.Forms.RichTextBox txtReadOutput;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RichTextBox txtCreateOutputBytes;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.RichTextBox txtCreateResponseOutputBytes;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.RichTextBox txtCreateResponseOutput;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.RichTextBox txtReadResponseOutput;
        private System.Windows.Forms.Button btnXMLRequestToBytes;
        private System.Windows.Forms.Button btnClearAll;
    }
}

