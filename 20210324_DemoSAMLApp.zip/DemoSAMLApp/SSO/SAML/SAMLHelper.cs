﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Security.Saml20;
using System.Xml.Serialization;
using System.IO;
using System.Security.Cryptography.X509Certificates;
using System.Xml;
using SSO.Constants;
using System.Security.Cryptography.Xml;

namespace SSO
{
    public static class SAMLHelper
    {
        #region Public Method
        /// <summary>
        /// Set the Certificate
        /// </summary>
        /// <param name="tenantDetail"></param>
        /// <returns></returns>
        public static CertificateInfo GetCertificateInfo(SSOTenantDetail tenantDetail)
        {
            CertificateInfo cInfo = new CertificateInfo();
            cInfo.IssueNbr = tenantDetail.CertificateIssueNbr;
            cInfo.FileName = tenantDetail.CertificateFileName;
            cInfo.Password = tenantDetail.CertificateFilePassword;
            cInfo.StoreName = StoreName.Root;
            cInfo.StoreLocation = StoreLocation.LocalMachine;
            cInfo.X509FindType = X509FindType.FindBySerialNumber;
            cInfo.ServerCertificate = LoadCertificate(cInfo);
            if (cInfo.ServerCertificate != null)
            {
                cInfo.HasCertificate = true;
            }
            return cInfo;
        }

        public static SAMLDocumentModel FillModelFromTenant(SSOTenantDetail tenantDetail)
        {
            SAMLDocumentModel model = new SAMLDocumentModel();
            model.TenantDetail = tenantDetail;
            model.CertificateInfo = GetCertificateInfo(tenantDetail);
            return model;
        }
        // <summary>
        /// Sets the servers certificate to variable
        /// </summary>
        /// <param name="certificateIssueNbr">CertificateIssueNbr</param>
        /// <param name="certficateFileName">CertficateFileName</param>
        /// <param name="certificatePassword">CertificatePassword</param>
        public static X509Certificate2 LoadCertificate(CertificateInfo cInfo)
        {
            if (cInfo != null)
            {
                X509Certificate2 cert = null;
                if (!string.IsNullOrEmpty(cInfo.IssueNbr))
                    cert = LoadCertificate(cInfo.StoreLocation, cInfo.StoreName, cInfo.X509FindType, cInfo.IssueNbr);

                if (cert == null && !string.IsNullOrEmpty(cInfo.FileName) && !string.IsNullOrEmpty(cInfo.Password))
                    cert = LoadCertificateFromFile(cInfo.FileName, cInfo.Password);

                return cert;
            }

            return null;
        }

        /// <summary>
        /// Loads the certificate from the store using the file and its password
        /// </summary>
        /// <param name="fileName"></param>
        /// <param name="password"></param>
        /// <param name="storeLocation"></param>
        /// <param name="storeName"></param>
        /// <param name="findType"></param>
        /// <param name="findValue"></param>
        /// <returns></returns>
        public static X509Certificate2 LoadCertificateFromFile(string fileName, string password)
        {
            X509Certificate2 cert = null;

            if (System.IO.File.Exists(fileName))
            {
                cert = new X509Certificate2(fileName, password);
            }
            return cert;
        }

        /// <summary>
        /// Loads the certificate from the store
        /// </summary>
        /// <param name="storeLocation"></param>
        /// <param name="storeName"></param>
        /// <param name="findType"></param>
        /// <param name="findValue"></param>
        /// <returns></returns>
        public static X509Certificate2 LoadCertificate(StoreLocation storeLocation, StoreName storeName, X509FindType findType, object findValue)
        {
            X509Certificate2 cert = null;
            X509Store store = new X509Store(storeName, storeLocation);
            store.Open(OpenFlags.ReadOnly);
            X509Certificate2Collection coll = store.Certificates.Find(findType, findValue, true);
            if (coll.Count > 0)
                cert = coll[0];
            store.Close();
            return cert;
        }


        /// <summary>
        /// Gets the value from SAML Attributes collection
        /// </summary>
        /// <param name="items">IEnumerable(Of AttributeType)</param>
        /// <param name="key">Key</param>
        /// <returns>string</returns>
        /// <remarks></remarks>
        public static string GetSAMLAttrValue(IEnumerable<AttributeType> items, string key)
        {
            string valVariable = string.Empty;
            var ele = items.Where(a => a.Name.ToString().ToLower() == key).FirstOrDefault();

            if (ele != null)
            {
                if (ele.AttributeValue != null)
                {
                    try
                    {
                        valVariable = ele.AttributeValue[0].ToString();
                    }
                    catch (Exception)
                    {
                    }
                }
            }
            return valVariable;
        }

        /// <summary>
        /// Get Element
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="val"></param>
        /// <returns></returns>
        public static T GetElementDeserialized<T>(string val)
        {
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(T));
            StringReader strReader = new StringReader(val);
            T t = (T)xmlSerializer.Deserialize(strReader);
            return t;
        }

        /// <summary>
        /// Get Element
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="val"></param>
        /// <returns></returns>
        public static string GetElementSerialized<T>(T val)
        {
            string output = "";
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(T));
            using (StringWriter stringWriter = new StringWriter())
            {
                using (XmlWriter xmlWriter = XmlWriter.Create(stringWriter))
                {
                    xmlSerializer.Serialize(xmlWriter, val);
                    output = stringWriter.ToString();
                }
            }
            return output;
        }

        public static XmlDocument RemoveDeclaration(XmlDocument xmlDoc)
        {
            if (xmlDoc.FirstChild.NodeType == XmlNodeType.XmlDeclaration)
                xmlDoc.RemoveChild(xmlDoc.FirstChild);

            return xmlDoc;
        }

        public static XmlDocument GetElementSerializedToXMLDoc<T>(T val)
        {
            string xmlText = SAMLHelper.GetElementSerialized<T>(val);
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.LoadXml(xmlText);
            xmlDoc = SAMLHelper.RemoveDeclaration(xmlDoc);
            return xmlDoc;
        }

        public static XmlDocument SetXMLNamespaceManager(XmlDocument document)
        {
            // Add name spaces
            XmlNamespaceManager namespaceManager = new XmlNamespaceManager(document.NameTable);
            namespaceManager.AddNamespace("samlp", "urn:oasis:names:tc:SAML:2.0:protocol");
            namespaceManager.AddNamespace("saml", "urn:oasis:names:tc:SAML:2.0:assertion");
            namespaceManager.AddNamespace("ds", "http://www.w3.org/2000/09/xmldsig#");
            namespaceManager.AddNamespace("xenc", "http://www.w3.org/2001/04/xmlenc#");
            return document;
        }

        public static Encoding GetEncoding(string encodingMethod)
        {
            if (string.IsNullOrEmpty(encodingMethod))
            {
                encodingMethod = "";
            }

            if (encodingMethod.ToLower() == EncodingMethodConstants.ASCII.ToLower())
            {
                return Encoding.ASCII;
            }
            if (encodingMethod.ToLower() == EncodingMethodConstants.Default.ToLower())
            {
                return Encoding.Default;
            }
            if (encodingMethod.ToLower() == EncodingMethodConstants.Unicode.ToLower())
            {
                return Encoding.Unicode;
            }
            if (encodingMethod.ToLower() == EncodingMethodConstants.UTF7.ToLower())
            {
                return Encoding.UTF7;
            }
            if (encodingMethod.ToLower() == EncodingMethodConstants.UTF8.ToLower())
            {
                return Encoding.UTF8;
            }
            if (encodingMethod.ToLower() == EncodingMethodConstants.UTF32.ToLower())
            {
                return Encoding.UTF32;
            }
            return Encoding.Default;
        }
        #endregion

        #region Public SAML Element

        /// <summary>
        /// Gets the XMlDocument from Base64
        /// </summary>
        /// <param name="base64string"></param>
        /// <param name="encoding"></param>
        /// <returns></returns>
        public static XmlDocument Base64ToXmlDocument(string base64string, string encoding)
        {
            if (!string.IsNullOrEmpty(base64string))
            {
                Byte[] bytes = System.Convert.FromBase64String(base64string);
                string _samlXMLResponse = SAMLHelper.GetEncoding(encoding).GetString(bytes);
                XmlDocument xdoc = new XmlDocument();
                xdoc.LoadXml(_samlXMLResponse);
                return xdoc;
            }
            return null;
        }

        /// <summary>
        /// Gets the Response Type
        /// </summary>
        /// <param name="xmlString"></param>
        /// <returns></returns>
        public static ResponseType GetSAMLResponseType(string xmlString)
        {
            try
            {
                XmlSerializer serializer = new XmlSerializer(typeof(ResponseType));

                using (StringReader reader = new StringReader(xmlString))
                {
                    return (ResponseType)(serializer.Deserialize(reader));
                }
            }
            catch (Exception)
            {
                 
            }
            return null;
        }


        /// <summary>
        ///  Gets the Encrypted assertion attributes
        ///  </summary>
        ///  <param name="xmlString">XmlString</param>
        ///  <returns>IEnumerable of AttributeType</returns>
        ///  <remarks></remarks>
        public static EncryptedElementType GetSAMLEncryptedElementType(string xmlString)
        {
            if (!string.IsNullOrEmpty(xmlString))
            {
                ResponseType responseType = GetSAMLResponseType(xmlString);
                return GetSAMLEncryptedElementType(responseType);
            }
            return null;    
        }

        /// <summary>
        ///  Gets the Encrypted assertion attributes
        ///  </summary>
        ///  <param name="xmlString">XmlString</param>
        ///  <returns>IEnumerable of AttributeType</returns>
        ///  <remarks></remarks>
        public static EncryptedElementType GetSAMLEncryptedElementType(ResponseType responseType)
        {
            if (responseType != null)
            {
                IEnumerable<EncryptedElementType> eles = responseType.Items.OfType<EncryptedElementType>();
                if (eles != null && eles.Count() > 0)
                {
                    EncryptedElementType encType = eles.First();
                    if (encType != null)
                    {
                        return encType;
                    }
                }
            }
            return null;
        }

        /// <summary>
        ///  Gets the Encrypted assertion attributes
        ///  </summary>
        ///  <param name="xmlString">XmlString</param>
        ///  <returns>IEnumerable of AttributeType</returns>
        ///  <remarks></remarks>
        public static EncryptedDataType GetSAMLEncryptedData(string xmlString)
        {
            if (!string.IsNullOrEmpty(xmlString))
            {
                EncryptedElementType eeType = GetSAMLEncryptedElementType(xmlString);
                EncryptedDataType ed = GetSAMLEncryptedData(eeType);
                return ed;
            }
            return null;
        }

        /// <summary>
        ///  Gets the Encrypted assertion attributes
        ///  </summary>
        ///  <param name="xmlString">XmlString</param>
        ///  <returns>IEnumerable of AttributeType</returns>
        ///  <remarks></remarks>
        public static EncryptedDataType GetSAMLEncryptedData(ResponseType responseType)
        {
            if (responseType != null)
            {
                EncryptedElementType eeType = GetSAMLEncryptedElementType(responseType);
                EncryptedDataType ed = new EncryptedDataType();
                ed = GetSAMLEncryptedData(eeType);
                return ed;
            }
            return null;
        }

        /// <summary>
        ///  Gets the Encrypted assertion attributes
        ///  </summary>
        ///  <param name="xmlString">XmlString</param>
        ///  <returns>IEnumerable of AttributeType</returns>
        ///  <remarks></remarks>
        public static EncryptedDataType GetSAMLEncryptedData(EncryptedElementType eeType)
        {
            if (eeType != null)
            {
                EncryptedDataType ed = new EncryptedDataType();
                ed = eeType.EncryptedData;
                //TODO:
                return ed;
            }
            return null;
        }

        /// <summary>
        ///  Gets the Encrypted assertion attributes
        ///  </summary>
        ///  <param name="xmlString">XmlString</param>
        ///  <returns>IEnumerable of AttributeType</returns>
        ///  <remarks></remarks>
        public static AssertionType GetSAMLAssertionType(string xmlString)
        {
            if (!string.IsNullOrEmpty(xmlString))
            {
                ResponseType responseType = GetSAMLResponseType(xmlString);
                return GetSAMLAssertionType(responseType);
            }
            return null;
        }

        /// <summary>
        ///  Gets the Encrypted assertion attributes
        ///  </summary>
        ///  <param name="xmlString">XmlString</param>
        ///  <returns>IEnumerable of AttributeType</returns>
        ///  <remarks></remarks>
        public static AssertionType GetSAMLAssertionType(ResponseType responseType)
        {
            if (responseType != null)
            {
                IEnumerable<AssertionType> eles = responseType.Items.OfType<AssertionType>();
                if (eles != null && eles.Count() > 0)
                {
                    return eles.First();
                }
            }
            return null;
        }

        /// <summary>
        ///  Gets the assertion attributes
        ///  </summary>
        ///  <param name="xmlString">XmlString</param>
        ///  <returns>IEnumerable of AttributeType</returns>
        ///  <remarks></remarks>
        public static IEnumerable<AttributeType> GetSAMLAttributeType(string xmlString)
        {
            AssertionType assertionType = GetSAMLAssertionType(xmlString);
            if (assertionType != null)
            {
                AttributeStatementType attributeStatementType = assertionType.Items.OfType<AttributeStatementType>().First();

                if (attributeStatementType != null && attributeStatementType.Items != null)
                    return attributeStatementType.Items.OfType<AttributeType>();
            }
            return null;
        }

        /// <summary>
        ///  Gets the assertion attributes
        ///  </summary>
        ///  <param name="xmlString">XmlString</param>
        ///  <returns>IEnumerable of AttributeType</returns>
        ///  <remarks></remarks>
        public static IEnumerable<AttributeType> GetSAMLAttributeType(AssertionType assertionType)
        {
            if (assertionType != null)
            {
                AttributeStatementType attributeStatementType = assertionType.Items.OfType<AttributeStatementType>().First();

                if (attributeStatementType != null && attributeStatementType.Items != null)
                    return attributeStatementType.Items.OfType<AttributeType>();
            }
            return null;
        }

        /// <summary>
        ///  Gets the assertion attributes
        ///  </summary>
        ///  <param name="xmlString">XmlString</param>
        ///  <returns>IEnumerable of AttributeType</returns>
        ///  <remarks></remarks>
        public static SignedInfoType GetSAMLSignedInfoType(string xmlString)
        {
            if (!string.IsNullOrEmpty(xmlString))
            {
                ResponseType responseType = GetSAMLResponseType(xmlString);
                return GetSAMLSignedInfoType(responseType);
            }
            return null;
        }

        /// <summary>
        ///  Gets the assertion attributes
        ///  </summary>
        ///  <param name="xmlString">XmlString</param>
        ///  <returns>IEnumerable of AttributeType</returns>
        ///  <remarks></remarks>
        public static SignedInfoType GetSAMLSignedInfoType(ResponseType responseType)
        {
            if (responseType != null)
            {
                IEnumerable<SignedInfoType> eles = responseType.Items.OfType<SignedInfoType>();
                if (eles != null && eles.Count() > 0)
                    return eles.First();
            }
            return null;
        }

        /// <summary>
        ///  Gets the assertion attributes
        ///  </summary>
        ///  <param name="xmlString">XmlString</param>
        ///  <returns>IEnumerable of AttributeType</returns>
        ///  <remarks></remarks>
        public static SignedInfoType GetSAMLAssertionSignedInfoType(string xmlString)
        {
            if (!string.IsNullOrEmpty(xmlString))
            {
                ResponseType responseType = GetSAMLResponseType(xmlString);
                return GetSAMLAssertionSignedInfoType(responseType);
            }
            return null;
        }

        /// <summary>
        ///  Gets the assertion attributes
        ///  </summary>
        ///  <param name="xmlString">XmlString</param>
        ///  <returns>IEnumerable of AttributeType</returns>
        ///  <remarks></remarks>
        public static SignedInfoType GetSAMLAssertionSignedInfoType(ResponseType responseType)
        {
            if (responseType != null)
            {
                AssertionType assertionType = GetSAMLAssertionType(responseType);
                return GetSAMLAssertionSignedInfoType(assertionType);
            }
            return null;
        }

        /// <summary>
        ///  Gets the assertion attributes
        ///  </summary>
        ///  <param name="xmlString">XmlString</param>
        ///  <returns>IEnumerable of AttributeType</returns>
        ///  <remarks></remarks>
        public static SignedInfoType GetSAMLAssertionSignedInfoType(AssertionType assertionType)
        {
            if (assertionType != null)
            {
                IEnumerable<SignedInfoType> eles = assertionType.Items.OfType<SignedInfoType>();
                if (eles != null && eles.Count() > 0)
                    return eles.First();
            }
            return null;
        }

        /// <summary>
        /// Gets the Response Method
        /// </summary>
        /// <param name="samlDocModel">SAMLDocumentModel</param>
        /// <returns>string</returns>
        public static string GetResponseMethod(SAMLDocumentModel samlDocModel)
        {
            string respMethod = string.Empty;
            if (samlDocModel != null)
            {
                
                if(samlDocModel.HasAssertion)
                {
                    respMethod = SamlResponseConstants.UnsignedSAMlUnsignedAssertion.ToLower();
                    if (samlDocModel.HasAssertionSignedInfo)
                    {
                        respMethod = SamlResponseConstants.UnsignedSAMlSignedAssertion.ToLower();
                    }

                    if (samlDocModel.HasSignedInfo)
                    {
                        respMethod = SamlResponseConstants.SignedSAMlUnsignedAssertion.ToLower();
                    }

                    if (samlDocModel.HasSignedInfo && samlDocModel.HasAssertionSignedInfo)
                    {
                        respMethod = SamlResponseConstants.SignedSAMlSignedAssertion.ToLower();
                    }
                }

                else if (samlDocModel.HasEncryptedAssertion)
                {
                    respMethod = SamlResponseConstants.UnsignedSAMlEncryptedAssertion.ToLower();
                    
                    if (samlDocModel.HasSignedInfo)
                    {
                        respMethod = SamlResponseConstants.SignedSAMlEncryptedAssertion.ToLower();
                    }
                    //TODO: UnSigned SAMl & Signed Encrypted Assertion
                    //TODO: Signed SAMl & Signed Encrypted Assertion
                }
            }

            return string.Empty;
        }

        /// <summary>
        /// Gets the EncryptionKeyAlgorithm
        /// </summary>
        /// <param name="encryptedDataType">EncryptedDataType</param>
        /// <returns>string</returns>
        public static string GetEncryptionMethodKey(EncryptedElementType encryptedElementType)
        {
            if (encryptedElementType != null)
            {
                //TODO:
                if (encryptedElementType.EncryptedKey != null && encryptedElementType.EncryptedKey.Count() > 0)
                {
                    EncryptedKeyType encryptedKey = encryptedElementType.EncryptedKey[0];
                    return encryptedKey.EncryptionMethod.Algorithm;
                }
            }

            return string.Empty;
        }

        /// <summary>
        /// Gets the EncryptionDataAlgorithm
        /// </summary>
        /// <param name="encryptedDataType">EncryptedDataType</param>
        /// <returns>string</returns>
        public static string GetEncryptionMethodData(EncryptedDataType encryptedDataType)
        {
            if (encryptedDataType != null)
            {
                return encryptedDataType.EncryptionMethod.Algorithm;
                //TODO:
            }
            return string.Empty;
        }
        #endregion
    }
}
