﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Security.Saml20;
using System.Xml;
using System.Net;
using Security.Saml;
using System.Security.Cryptography.X509Certificates;
using System.IO;
using System.Xml.Serialization;
using System.Security.Cryptography.Xml;
using SSO.Constants;

namespace SSO.Methods
{
    public class UnsignedSAMlSignedAssertion : BaseSAML
    {
        public UnsignedSAMlSignedAssertion(SAMLDocumentModel _samlModel)
        {
            this.SAMLModel = _samlModel;
        }

        public override SAMLDocumentModel CreateRequest()
        {
            string authNXml = "";
            string acnsUrl = this.SAMLModel.TenantDetail.AssertionConsumerServiceURL;
            string protoBinding = string.IsNullOrEmpty(this.SAMLModel.TenantDetail.ProtocalBinding) ? "urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST" : this.SAMLModel.TenantDetail.ProtocalBinding;
            XmlDocument _samlDocument = new XmlDocument();
            CertificateInfo cInfo;

            //Create the AuthnRequestType
            AuthnRequestType _authnRequest = new AuthnRequestType()
            {
                Issuer = new NameIDType()
                {
                    Value = this.SAMLModel.TenantDetail.Issuer
                },
                Destination = this.SAMLModel.TenantDetail.Destination,
                NameIDPolicy = new NameIDPolicyType()
                {
                    AllowCreate = true,
                    Format = "urn:oasis:names:tc:SAML:1.1:nameid-format:emailAddress"
                },
                ID = "_" + Guid.NewGuid().ToString(),
                AssertionConsumerServiceURL = this.SAMLModel.TenantDetail.AssertionConsumerServiceURL,
                ProtocolBinding = protoBinding
            };

            //Serialize AuthnRequestType to string
            authNXml = SAMLHelper.GetElementSerialized<AuthnRequestType>(_authnRequest);

            //Load the Serialized AuthnRequestType to XMLDocument
            _samlDocument.LoadXml(authNXml);

            _samlDocument = SAMLHelper.RemoveDeclaration(_samlDocument);

            //Insert the certificate to XMLDocument
            cInfo = this.SAMLModel.CertificateInfo;
            if (cInfo != null && cInfo.HasCertificate)
            {
                if (this.SAMLModel.CertificateInfo.ServerCertificate != null)
                {
                    XmlElement signature = GetSignatureElement(_samlDocument, this.SAMLModel.CertificateInfo.ServerCertificate, "ID", _authnRequest.ID);

                    _samlDocument.DocumentElement.InsertBefore(signature,
                        _samlDocument.DocumentElement.ChildNodes[1]);
                }
            }

            OutputSAMLRequest = this.SAMLModel.Clone();
            OutputSAMLRequest.XmlDocument = _samlDocument;
            OutputSAMLRequest.AuthnRequest = _authnRequest;
            return OutputSAMLRequest;
        }

        public override SAMLDocumentModel ReadRequest()
        {
            OutputSAMLRequest = new SAMLDocumentModel();
            try
            {
                byte[] bytes = Convert.FromBase64String(this.SAMLModel.RequestResponse);
                string authnReqStr = SAMLHelper.GetEncoding(this.SAMLModel.TenantDetail.EncodingMethod).GetString(bytes); //Encoding.UTF8.GetString(bytes);
                AuthnRequestType authnRequest = SAMLHelper.GetElementDeserialized<AuthnRequestType>(authnReqStr);
                XmlDocument doc = new XmlDocument();
                doc.LoadXml(authnReqStr);
                doc = SAMLHelper.RemoveDeclaration(doc);

                OutputSAMLRequest = this.SAMLModel.Clone();
                OutputSAMLRequest.XmlDocument = doc;
                return OutputSAMLRequest;
            }
            catch (Exception)
            {
            }
            return null;
        }


        public override SAMLDocumentModel CreateResponse()
        {
            ResponseType response = new ResponseType();
            XmlDocument _samlDocument = new XmlDocument();
            NameIDType issuerForResponse = new NameIDType();
            StatusType status = new StatusType();
            StringWriter stringWriter = new StringWriter();
            XmlWriterSettings settings = new XmlWriterSettings();
             
            CertificateInfo cInfo;
            XmlSerializer responseSerializer;
            XmlWriter responseWriter;
            string samlString = string.Empty;
            AssertionType assertionType;

            // Response Main Area
            response.ID = "_" + Guid.NewGuid().ToString();
            response.Destination = this.SAMLModel.TenantDetail.Destination;
            response.Version = "2.0";
            response.IssueInstant = System.DateTime.UtcNow;


            issuerForResponse.Value = this.SAMLModel.TenantDetail.Issuer;

            response.Issuer = issuerForResponse;

            //Set the status
            status.StatusCode = new StatusCodeType();
            status.StatusCode.Value = "urn:oasis:names:tc:SAML:2.0:status:" + this.SAMLModel.Status;
            response.Status = status;

            responseSerializer = new XmlSerializer(response.GetType());

            settings.OmitXmlDeclaration = true;
            settings.Indent = true;
            settings.Encoding = SAMLHelper.GetEncoding(this.SAMLModel.TenantDetail.EncodingMethod); // Encoding.UTF8;

            responseWriter = XmlTextWriter.Create(stringWriter, settings);

            assertionType = CreateSamlAssertion();            
            
            //Sign the assertion
            string assertionTypeSerialzed = SAMLHelper.GetElementSerialized<AssertionType>(assertionType);
            XmlDocument assertionTypeDoc = new XmlDocument();
            assertionTypeDoc.LoadXml(assertionTypeSerialzed);
            assertionTypeDoc =SAMLHelper.RemoveDeclaration(assertionTypeDoc);
            
            //insert the signature
            cInfo = this.SAMLModel.CertificateInfo;
            if (cInfo != null && cInfo.HasCertificate)
            {
                if (this.SAMLModel.CertificateInfo.ServerCertificate != null)
                {
                    XmlElement signature = GetSignatureElement(assertionTypeDoc, this.SAMLModel.CertificateInfo.ServerCertificate, "ID", assertionType.ID);

                    assertionTypeDoc.DocumentElement.InsertBefore(signature,
                        assertionTypeDoc.DocumentElement.ChildNodes[1]);
                }
            }

            response.Items =new AssertionType[]{ SAMLHelper.GetElementDeserialized<AssertionType>(assertionTypeDoc.OuterXml)};

            responseSerializer.Serialize(responseWriter, response);
            responseWriter.Close();

            samlString = stringWriter.ToString();

            samlString = samlString.Replace("SubjectConfirmationData",
                string.Format("SubjectConfirmationData NotOnOrAfter=\"{0:o}\" Recipient=\"{1}\"",
                DateTime.UtcNow.AddMinutes(5), this.SAMLModel.TenantDetail.Destination));

            stringWriter.Close();

            _samlDocument.LoadXml(samlString);

            

            OutputSAMLResponse = this.SAMLModel.Clone();
            OutputSAMLResponse.XmlDocument = _samlDocument;
            return OutputSAMLResponse;
        }

        public override SAMLDocumentModel ReadResponse()
        {
            OutputSAMLResponse = new SAMLDocumentModel();
            try
            {
                Byte[] bytes = System.Convert.FromBase64String(this.SAMLModel.RequestResponse);
                string _samlXMLResponse = SAMLHelper.GetEncoding(this.SAMLModel.TenantDetail.EncodingMethod).GetString(bytes);// Encoding.UTF8.GetString(bytes);
                XmlDocument _samlDocument = new XmlDocument();
                _samlDocument.LoadXml(_samlXMLResponse);

                this.SAMLModel.AssertionAttributes = SAMLHelper.GetSAMLAttributeType(_samlXMLResponse);
                this.SAMLModel.IsValidSAML = true;
                OutputSAMLResponse = this.SAMLModel.Clone();
                OutputSAMLResponse.XmlDocument = _samlDocument;
                return OutputSAMLResponse;
            }
            catch (Exception)
            {
            }

            return null;
        }

        /// <summary>
        /// Signs an XML Document for a Saml Response
        /// </summary>
        /// <param name="xml"></param>
        /// <param name="cert2"></param>
        /// <param name="referenceId"></param>
        /// <returns></returns>
        public override bool VerifySignRequestDoc()
        {
            X509Certificate2 cert2 = null;
            if (this.SAMLModel.CertificateInfo != null)
            {
                cert2 = this.SAMLModel.CertificateInfo.ServerCertificate;
            }
            return VerifySignDoc(this.OutputSAMLRequest.XmlDocument, cert2);
        }

        /// <summary>
        /// Signs an XML Document for a Saml Response
        /// </summary>
        /// <param name="xml"></param>
        /// <param name="cert2"></param>
        /// <param name="referenceId"></param>
        /// <returns></returns>
        public override bool VerifySignResponseDoc()
        {
            X509Certificate2 cert2 = null;
            if (this.SAMLModel.CertificateInfo != null)
            {
                cert2 = this.SAMLModel.CertificateInfo.ServerCertificate;
            }
            return VerifySignDoc(this.OutputSAMLResponse.XmlDocument, cert2);
        }


        /// <summary>
        /// Signs an XML Document for a Saml Response
        /// </summary>
        /// <param name="xml"></param>
        /// <param name="cert2"></param>
        /// <param name="referenceId"></param>
        /// <returns></returns>
        public override bool VerifySignDoc(XmlDocument doc, X509Certificate2 cert2)
        {
            bool isVerified = false;
            if (cert2 == null)
            {
                return isVerified;
            }
            //// Create a new XML document.
            //XmlDocument xmlDocument = new XmlDocument();

            //// Load the passed XML file into the document. 
            //xmlDocument.Load(Name);

            // Create a new SignedXml object and pass it
            // the XML document class.
            SignedXml signedXml = new SignedXml(doc);

            // Find the "Signature" node and create a new
            // XmlNodeList object.
            XmlNodeList nodeList = doc.GetElementsByTagName("Signature");

            // Load the signature node.
            signedXml.LoadXml((XmlElement)nodeList[0]);

            // Check the signature and return the result.

            try
            {
                isVerified = signedXml.CheckSignature(cert2.PrivateKey);
            }
            catch (Exception)
            {

            }
            if (!isVerified)
            {
                KeyInfoX509Data kd = signedXml.Signature.KeyInfo.OfType<KeyInfoX509Data>().First();
                if (kd.Certificates.Count > 0)
                {
                    string recpublicKey = ((X509Certificate2)kd.Certificates[0]).GetPublicKeyString();
                    string cerpublicKey = cert2.GetPublicKeyString();
                    if (recpublicKey == cerpublicKey)
                        isVerified = true;
                }
            }
            return isVerified;
        }

        /// <summary>
        /// Creates a Version 1.1 Saml Assertion
        /// </summary>
        public override AssertionType CreateSamlAssertion()
        {
            // Here we create some SAML assertion with ID and Issuer name. 
            AssertionType assertion = new AssertionType();
            assertion.ID = "_" + Guid.NewGuid().ToString();

            NameIDType issuerForAssertion = new NameIDType();
            issuerForAssertion.Value = this.SAMLModel.TenantDetail.Issuer.Trim();

            assertion.Issuer = issuerForAssertion;
            assertion.Version = "2.0";

            assertion.IssueInstant = System.DateTime.UtcNow;

            //Not before, not after conditions 
            ConditionsType conditions = new ConditionsType();
            conditions.NotBefore = DateTime.UtcNow;
            conditions.NotBeforeSpecified = true;
            conditions.NotOnOrAfter = DateTime.UtcNow.AddMinutes(5);
            conditions.NotOnOrAfterSpecified = true;

            AudienceRestrictionType audienceRestriction = new AudienceRestrictionType();
            audienceRestriction.Audience = new string[] { this.SAMLModel.TenantDetail.Domain.Trim() };

            conditions.Items = new ConditionAbstractType[] { audienceRestriction };

            //Name Identifier to be used in Saml Subject
            NameIDType nameIdentifier = new NameIDType();
            nameIdentifier.NameQualifier = this.SAMLModel.TenantDetail.Domain.Trim();
            nameIdentifier.Value = this.SAMLModel.TenantDetail.Subject.Trim();

            SubjectConfirmationType subjectConfirmation = new SubjectConfirmationType();
            SubjectConfirmationDataType subjectConfirmationData = new SubjectConfirmationDataType();

            subjectConfirmation.Method = "urn:oasis:names:tc:SAML:2.0:cm:bearer";
            subjectConfirmation.SubjectConfirmationData = subjectConfirmationData;
            // 
            // Create some SAML subject. 
            SubjectType samlSubject = new SubjectType();

            AttributeStatementType attrStatement = new AttributeStatementType();
            AuthnStatementType authStatement = new AuthnStatementType();
            authStatement.AuthnInstant = DateTime.UtcNow;
            AuthnContextType context = new AuthnContextType();
            context.ItemsElementName = new ItemsChoiceType5[] { ItemsChoiceType5.AuthnContextClassRef };
            context.Items = new object[] { "AuthnContextClassRef" };
            authStatement.AuthnContext = context;

            samlSubject.Items = new object[] { nameIdentifier, subjectConfirmation };

            assertion.Subject = samlSubject;

            IPHostEntry ipEntry =
                Dns.GetHostEntry(System.Environment.MachineName);

            SubjectLocalityType subjectLocality = new SubjectLocalityType();
            subjectLocality.Address = ipEntry.AddressList[0].ToString();

            if (this.SAMLModel.Attributes == null)
            {
                this.SAMLModel.Attributes = new Dictionary<string, string>();
            }
            attrStatement.Items = new AttributeType[this.SAMLModel.Attributes.Count];
            int i = 0;
            // Create userName SAML attributes. 
            foreach (KeyValuePair<string, string> attribute in this.SAMLModel.Attributes)
            {
                AttributeType attr = new AttributeType();
                attr.Name = attribute.Key;
                attr.NameFormat = "urn:oasis:names:tc:SAML:2.0:attrname-format:basic";
                attr.AttributeValue = new object[] { attribute.Value };
                attrStatement.Items[i] = attr;
                i++;
            }
            assertion.Conditions = conditions;

            assertion.Items = new StatementAbstractType[] { authStatement, attrStatement };

            return assertion;

        }
        public override EncryptedElementType CreateEncryptionSamlAssertion()
        {
            throw new NotImplementedException("Not valid for " + SamlResponseConstants.UnsignedSAMlSignedAssertion);
        }

        #region Private Methods


        /// <summary>
        /// Signs an XML Document for a Saml Response
        /// </summary>
        /// <param name="xml"></param>
        /// <param name="cert2"></param>
        /// <param name="referenceId"></param>
        /// <returns></returns>
        private XmlElement GetSignatureElement(XmlDocument doc, X509Certificate2 cert2, string referenceId, string referenceValue)
        {
            SamlSignedXml sig = new SamlSignedXml(doc, referenceId);
            // Add the key to the SignedXml xmlDocument. 
            sig.SigningKey = cert2.PrivateKey;

            // Create a reference to be signed. 
            Reference reference = new Reference();

            reference.Uri = String.Empty;
            reference.Uri = "#" + referenceValue;

            // Add an enveloped transformation to the reference. 
            XmlDsigEnvelopedSignatureTransform env = new
                XmlDsigEnvelopedSignatureTransform();
            XmlDsigC14NTransform env2 = new XmlDsigC14NTransform();

            reference.AddTransform(env);
            reference.AddTransform(env2);

            // Add the reference to the SignedXml object. 
            sig.AddReference(reference);

            // Add an RSAKeyValue KeyInfo (optional; helps recipient find key to validate). 
            KeyInfo keyInfo = new KeyInfo();
            KeyInfoX509Data keyData = new KeyInfoX509Data(cert2);

            keyInfo.AddClause(keyData);

            sig.KeyInfo = keyInfo;

            // Compute the signature. 
            sig.ComputeSignature();

            // Get the XML representation of the signature and save it to an XmlElement object. 
            XmlElement xmlDigitalSignature = sig.GetXml();

            return xmlDigitalSignature;
        }

        #endregion

    }
}
