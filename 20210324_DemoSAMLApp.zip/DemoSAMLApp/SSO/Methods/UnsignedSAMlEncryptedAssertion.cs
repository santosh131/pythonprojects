﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Security.Saml20;
using System.Xml;
using System.Net;
using Security.Saml;
using System.Security.Cryptography.X509Certificates;
using System.IO;
using System.Xml.Serialization;
using System.Security.Cryptography.Xml;
using SSO.Constants;
using SSO.Encryption;
using SSO.Models;
using System.Security.Cryptography;

namespace SSO.Methods
{
    public class UnsignedSAMlEncryptedAssertion : BaseSAML
    {
        public UnsignedSAMlEncryptedAssertion(SAMLDocumentModel _samlModel)
        {
            this.SAMLModel = _samlModel;
            this.IsOperation = false;
        }

        public override SAMLDocumentModel CreateRequest()
        {
            try
            {
                this.IsOperation = false;
                this.OperationFailedMessage = string.Empty;
                string authNXml = "";
                string acnsUrl = this.SAMLModel.TenantDetail.AssertionConsumerServiceURL;
                string protoBinding = string.IsNullOrEmpty(this.SAMLModel.TenantDetail.ProtocalBinding) ? "urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST" : this.SAMLModel.TenantDetail.ProtocalBinding;
                XmlDocument _samlDocument = new XmlDocument();

                //Create the AuthnRequestType
                AuthnRequestType _authnRequest = new AuthnRequestType()
                {
                    Issuer = new NameIDType()
                    {
                        Value = this.SAMLModel.TenantDetail.Issuer
                    },
                    Destination = this.SAMLModel.TenantDetail.Destination,
                    NameIDPolicy = new NameIDPolicyType()
                    {
                        AllowCreate = true,
                        Format = "urn:oasis:names:tc:SAML:1.1:nameid-format:emailAddress"
                    },
                    ID = "_" + Guid.NewGuid().ToString(),
                    AssertionConsumerServiceURL = this.SAMLModel.TenantDetail.AssertionConsumerServiceURL,
                    ProtocolBinding = protoBinding
                };

                //Serialize AuthnRequestType to string
                authNXml = SAMLHelper.GetElementSerialized<AuthnRequestType>(_authnRequest);

                //Load the Serialized AuthnRequestType to XMLDocument
                _samlDocument.LoadXml(authNXml);

                _samlDocument = SAMLHelper.RemoveDeclaration(_samlDocument);


                OutputSAMLRequest = this.SAMLModel.Clone();
                OutputSAMLRequest.XmlDocument = _samlDocument;
                OutputSAMLRequest.AuthnRequest = _authnRequest;
                this.IsOperation = true;
            }
            catch (Exception ex)
            {
                this.OperationFailedMessage = ex.Message;
            }
            return OutputSAMLRequest;
        }

        public override SAMLDocumentModel ReadRequest()
        {
            this.IsOperation = false;
            this.OperationFailedMessage = string.Empty;
            OutputSAMLRequest = new SAMLDocumentModel();
            try
            {
                byte[] bytes = Convert.FromBase64String(this.SAMLModel.RequestResponse);
                string authnReqStr = SAMLHelper.GetEncoding(this.SAMLModel.TenantDetail.EncodingMethod).GetString(bytes); //Encoding.UTF8.GetString(bytes);
                AuthnRequestType authnRequest = SAMLHelper.GetElementDeserialized<AuthnRequestType>(authnReqStr);
                XmlDocument doc = new XmlDocument();
                doc.LoadXml(authnReqStr);
                doc = SAMLHelper.RemoveDeclaration(doc);

                OutputSAMLRequest = this.SAMLModel.Clone();
                OutputSAMLRequest.XmlDocument = doc;
                this.IsOperation = true;
                return OutputSAMLRequest;
            }
            catch (Exception ex)
            {
                this.OperationFailedMessage = ex.Message;
            }
            return null;
        }


        public override SAMLDocumentModel CreateResponse()
        {
            try
            {

                this.IsOperation = false;
                this.OperationFailedMessage = string.Empty;
                ResponseType response = new ResponseType();
                XmlDocument _samlDocument = new XmlDocument();
                NameIDType issuerForResponse = new NameIDType();
                StatusType status = new StatusType();
                StringWriter stringWriter = new StringWriter();
                XmlWriterSettings settings = new XmlWriterSettings();

                XmlSerializer responseSerializer;
                XmlWriter responseWriter;
                string samlString = string.Empty;
                //AssertionType assertionType;
                EncryptedElementType encryptedElementType;

                // Response Main Area
                response.ID = "_" + Guid.NewGuid().ToString();
                response.Destination = this.SAMLModel.TenantDetail.Destination;
                response.Version = "2.0";
                response.IssueInstant = System.DateTime.UtcNow;


                issuerForResponse.Value = this.SAMLModel.TenantDetail.Issuer;

                response.Issuer = issuerForResponse;

                //Set the status
                status.StatusCode = new StatusCodeType();
                status.StatusCode.Value = "urn:oasis:names:tc:SAML:2.0:status:" + this.SAMLModel.Status;
                response.Status = status;

                responseSerializer = new XmlSerializer(response.GetType());

                settings.OmitXmlDeclaration = true;
                settings.Indent = true;
                settings.Encoding = SAMLHelper.GetEncoding(this.SAMLModel.TenantDetail.EncodingMethod); //Encoding.UTF8;

                responseWriter = XmlTextWriter.Create(stringWriter, settings);

                //assertionType = CreateSamlAssertion();
                encryptedElementType = CreateEncryptionSamlAssertion();

                response.Items = new EncryptedElementType[] { encryptedElementType };

                responseSerializer.Serialize(responseWriter, response);
                responseWriter.Close();

                samlString = stringWriter.ToString();

                samlString = samlString.Replace("SubjectConfirmationData",
                    string.Format("SubjectConfirmationData NotOnOrAfter=\"{0:o}\" Recipient=\"{1}\"",
                    DateTime.UtcNow.AddMinutes(5), this.SAMLModel.TenantDetail.Destination));

                stringWriter.Close();

                _samlDocument.LoadXml(samlString);

                _samlDocument = SAMLHelper.SetXMLNamespaceManager(_samlDocument); //TODO: 
                OutputSAMLResponse = this.SAMLModel.Clone();
                OutputSAMLResponse.XmlDocument = _samlDocument;
                this.IsOperation = true;
                return OutputSAMLResponse;

            }
            catch (Exception ex)
            {
                this.OperationFailedMessage = ex.Message;
            }
            return null;
        }

        public override SAMLDocumentModel ReadResponse()
        {
            this.IsOperation = false;
            this.OperationFailedMessage = string.Empty;
            OutputSAMLResponse = new SAMLDocumentModel();
            try
            {
                EncryptedDataType edType = this.SAMLModel.EncryptedDataType;
                //Get the Encrypted key element
                EncryptedKey ek = new EncryptedKey();
                ek.LoadXml(edType.KeyInfo.Items[0] as XmlElement);

                //Get the certificate from the EncryptedKey -KeyInfo
                KeyInfoX509Data kX509Data = ek.KeyInfo.OfType<KeyInfoX509Data>().FirstOrDefault();
                CertificateInfo cInfo = new CertificateInfo();
                cInfo.IssueNbr = ((X509IssuerSerial)kX509Data.IssuerSerials[0]).SerialNumber;
                cInfo.FileName = "";
                cInfo.Password = "";
                cInfo.StoreName = StoreName.Root;
                cInfo.StoreLocation = StoreLocation.LocalMachine;
                cInfo.X509FindType = X509FindType.FindBySerialNumber;

                X509Certificate2 x509Cert = SAMLHelper.LoadCertificate(cInfo);

                //Get the BaseEncryption
                EncryptionModel em = new EncryptionModel();
                em.EncryptionDataMethod = this.SAMLModel.EncryptionMethodData;// EncryptedXml.XmlEncAES256Url;
                em.EncryptionKeyMethod = this.SAMLModel.EncryptionMethodKey;//EncryptedXml.XmlEncRSA15Url,EncryptedXml.XmlEncRSAOAEPUrl
                 
                BaseEncryption baseEncryption = new BaseEncryption(em);
                BaseEncryptionData baseEncryptionData = baseEncryption.GetBaseEncryptionData();
                BaseEncryptionKey baseEncryptionKey = baseEncryption.GetBaseEncryptionKey();

                //Decrypt the key
                byte[] keycipheData = ek.CipherData.CipherValue;
                byte[] decryptedKeybytes = baseEncryptionKey.Decrypt(keycipheData, x509Cert, this.SAMLModel.TenantDetail.EncodingMethod);

               //decrypt the data using the key
                this.SAMLModel.XmlDocument = baseEncryptionData.Decrypt(this.SAMLModel, decryptedKeybytes);

                //Test
                //EncryptedData ed = new EncryptedData();

                //ed.CipherData = new CipherData(edType.CipherData.Item as byte[]);

                //ed.EncryptionMethod = new EncryptionMethod()
                //{
                //    KeyAlgorithm = edType.EncryptionMethod.Algorithm
                //};

                //ed.Encoding = edType.Encoding;s
                //baseEncryptionData.DecryptWithString(ed,Encoding.UTF8.GetString( decryptedKeybytes), this.SAMLModel); 
                //Test

                this.SAMLModel.IsValidSAML = true;
                OutputSAMLResponse = this.SAMLModel.Clone();
                OutputSAMLResponse.XmlDocument = this.SAMLModel.XmlDocument;
                this.IsOperation = true;

                return OutputSAMLResponse;
            }
            catch (Exception ex)
            {
                this.OperationFailedMessage = ex.Message;
            }

            return null;
        }

        /// <summary>
        /// Signs an XML Document for a Saml Response
        /// </summary>
        /// <param name="xml"></param>
        /// <param name="cert2"></param>
        /// <param name="referenceId"></param>
        /// <returns></returns>
        public override bool VerifySignRequestDoc()
        {
            return true;
        }

        /// <summary>
        /// Signs an XML Document for a Saml Response
        /// </summary>
        /// <param name="xml"></param>
        /// <param name="cert2"></param>
        /// <param name="referenceId"></param>
        /// <returns></returns>
        public override bool VerifySignResponseDoc()
        {
            return true;
        }


        /// <summary>
        /// Signs an XML Document for a Saml Response
        /// </summary>
        /// <param name="xml"></param>
        /// <param name="cert2"></param>
        /// <param name="referenceId"></param>
        /// <returns></returns>
        public override bool VerifySignDoc(XmlDocument doc, X509Certificate2 cert2)
        {
            return true;
        }

        /// <summary>
        /// Creates a Version 1.1 Saml Assertion
        /// </summary>
        public override AssertionType CreateSamlAssertion()
        {
            // Here we create some SAML assertion with ID and Issuer name. 
            AssertionType assertion = new AssertionType();
            assertion.ID = "_" + Guid.NewGuid().ToString();

            NameIDType issuerForAssertion = new NameIDType();
            issuerForAssertion.Value = this.SAMLModel.TenantDetail.Issuer.Trim();

            assertion.Issuer = issuerForAssertion;
            assertion.Version = "2.0";

            assertion.IssueInstant = System.DateTime.UtcNow;

            //Not before, not after conditions 
            ConditionsType conditions = new ConditionsType();
            conditions.NotBefore = DateTime.UtcNow;
            conditions.NotBeforeSpecified = true;
            conditions.NotOnOrAfter = DateTime.UtcNow.AddMinutes(5);
            conditions.NotOnOrAfterSpecified = true;

            AudienceRestrictionType audienceRestriction = new AudienceRestrictionType();
            audienceRestriction.Audience = new string[] { this.SAMLModel.TenantDetail.Domain.Trim() };

            conditions.Items = new ConditionAbstractType[] { audienceRestriction };

            //Name Identifier to be used in Saml Subject
            NameIDType nameIdentifier = new NameIDType();
            nameIdentifier.NameQualifier = this.SAMLModel.TenantDetail.Domain.Trim();
            nameIdentifier.Value = this.SAMLModel.TenantDetail.Subject.Trim();

            SubjectConfirmationType subjectConfirmation = new SubjectConfirmationType();
            SubjectConfirmationDataType subjectConfirmationData = new SubjectConfirmationDataType();

            subjectConfirmation.Method = "urn:oasis:names:tc:SAML:2.0:cm:bearer";
            subjectConfirmation.SubjectConfirmationData = subjectConfirmationData;
            // 
            // Create some SAML subject. 
            SubjectType samlSubject = new SubjectType();

            AttributeStatementType attrStatement = new AttributeStatementType();
            AuthnStatementType authStatement = new AuthnStatementType();
            authStatement.AuthnInstant = DateTime.UtcNow;
            AuthnContextType context = new AuthnContextType();
            context.ItemsElementName = new ItemsChoiceType5[] { ItemsChoiceType5.AuthnContextClassRef };
            context.Items = new object[] { "AuthnContextClassRef" };
            authStatement.AuthnContext = context;

            samlSubject.Items = new object[] { nameIdentifier, subjectConfirmation };

            assertion.Subject = samlSubject;

            IPHostEntry ipEntry =
                Dns.GetHostEntry(System.Environment.MachineName);

            SubjectLocalityType subjectLocality = new SubjectLocalityType();
            subjectLocality.Address = ipEntry.AddressList[0].ToString();

            if (this.SAMLModel.Attributes == null)
            {
                this.SAMLModel.Attributes = new Dictionary<string, string>();
            }
            attrStatement.Items = new AttributeType[this.SAMLModel.Attributes.Count];
            int i = 0;
            // Create userName SAML attributes. 
            foreach (KeyValuePair<string, string> attribute in this.SAMLModel.Attributes)
            {
                AttributeType attr = new AttributeType();
                attr.Name = attribute.Key;
                attr.NameFormat = "urn:oasis:names:tc:SAML:2.0:attrname-format:basic";
                attr.AttributeValue = new object[] { attribute.Value };
                attrStatement.Items[i] = attr;
                i++;
            }
            assertion.Conditions = conditions;

            assertion.Items = new StatementAbstractType[] { authStatement, attrStatement };

            return assertion;

        }
        public override EncryptedElementType CreateEncryptionSamlAssertion()
        {
            EncryptionModel em = new EncryptionModel();
            em.EncryptionDataMethod = this.SAMLModel.TenantDetail.EncryptionDataAlgorithm;// EncryptedXml.XmlEncAES256Url;
            em.EncryptionKeyMethod = this.SAMLModel.TenantDetail.EncryptionKeyAlgorithm;//EncryptedXml.XmlEncRSA15Url,EncryptedXml.XmlEncRSAOAEPUrl
            //Create the Saml Assertion
            AssertionType assertionType = CreateSamlAssertion();
            XmlDocument testDoc = SAMLHelper.GetElementSerializedToXMLDoc<AssertionType>(assertionType);
            EncryptedElementType encryptedElementType = new EncryptedElementType();

            EncryptedDataType encryptedDataType = new EncryptedDataType()
            {
                Type = em.EncryptionDataMethod
            };

            //Get the Base Encryption 
            BaseEncryption baseEncryption = new BaseEncryption(em);

            //----------------------------
            //Create EncryptedDataType
            BaseEncryptionData baseEncryptionData = baseEncryption.GetBaseEncryptionData();
            XmlDocument assertionXMLDoc = new XmlDocument();
            assertionXMLDoc = SAMLHelper.GetElementSerializedToXMLDoc<AssertionType>(assertionType);
            RijndaelManaged rijndaelManaged = new RijndaelManaged();
            //string key = "mysmallkey12345512987651";// Guid.NewGuid().ToString();
            // Encrypt assertion with key          
            byte[] encryptedData = baseEncryptionData.Encrypt(assertionXMLDoc, out rijndaelManaged);
            //byte[] encryptedData = baseEncryptionData.EncryptWithString(assertionXMLDoc,key); //test

            //Create Encryption Method, CipherData
            EncryptionMethodType dataEncryptionMethodType = new EncryptionMethodType();
            CipherDataType cipherDataType = new CipherDataType();
            CipherData cipherData = new CipherData(encryptedData);

            dataEncryptionMethodType.Algorithm = em.EncryptionDataMethod;
            cipherDataType.Item = cipherData.CipherValue;

            //Assign Encryption Method, CipherData to EncryptedDataType
            encryptedDataType.EncryptionMethod = dataEncryptionMethodType;
            encryptedDataType.CipherData = cipherDataType;

            //-------------------------
            // Encrypt symmetric key
            BaseEncryptionKey baseEncryptionKey = baseEncryption.GetBaseEncryptionKey();
            EncryptedKeyType ekType = new EncryptedKeyType();

            //Encrypt key
            //byte[] keyBytes = SAMLHelper.GetEncoding(this.SAMLModel.TenantDetail.EncodingMethod).GetBytes(key);//test
            //byte[] cryptedData = baseEncryptionKey.Encrypt(keyBytes, this.SAMLModel.CertificateInfo.ServerCertificate, this.SAMLModel.TenantDetail.EncodingMethod);//test
            byte[] cryptedData = baseEncryptionKey.Encrypt(rijndaelManaged.Key, this.SAMLModel.CertificateInfo.ServerCertificate, this.SAMLModel.TenantDetail.EncodingMethod);

            //Create EncryptedKeyType
            EncryptionMethodType keyEncryptionMethodType = new EncryptionMethodType();
            CipherDataType keyCipherDataType = new CipherDataType();
            CipherData keyCipherData = new CipherData(cryptedData);

            keyEncryptionMethodType.Algorithm = em.EncryptionKeyMethod;
            keyCipherDataType.Item = keyCipherData.CipherValue;

            // Add an RSAKeyValue KeyInfo (optional; helps recipient find key to validate). 
            KeyInfoType kiType = new KeyInfoType();

            ItemsChoiceType2[] icType2 = new ItemsChoiceType2[] { ItemsChoiceType2.X509Data };
            X509DataType x509DataType = new X509DataType();
            X509IssuerSerialType x509IssueSerialType = new X509IssuerSerialType();
            x509IssueSerialType.X509IssuerName = this.SAMLModel.CertificateInfo.ServerCertificate.IssuerName.Name;
            x509IssueSerialType.X509SerialNumber = this.SAMLModel.CertificateInfo.ServerCertificate.SerialNumber;

            x509DataType.Items = new X509IssuerSerialType[] { x509IssueSerialType };
            x509DataType.ItemsElementName = new ItemsChoiceType[] { ItemsChoiceType.X509IssuerSerial };

            kiType.Items = new X509DataType[] { x509DataType };
            kiType.ItemsElementName = icType2;

            //Assign Encryption Method, CipherData to EncryptedKeyType
            ekType.EncryptionMethod = keyEncryptionMethodType;
            ekType.CipherData = keyCipherDataType;
            ekType.KeyInfo = kiType;

            //Assign EncryptedKeyType to KeyInfoType
            KeyInfoType keyInfoTypeED = new KeyInfoType();
            keyInfoTypeED.Items = new XmlElement[] { SAMLHelper.GetElementSerializedToXMLDoc<EncryptedKeyType>(ekType).DocumentElement };// new EncryptedKeyType[] { ekType };
            keyInfoTypeED.ItemsElementName = new ItemsChoiceType2[] { ItemsChoiceType2.Item };
            encryptedDataType.KeyInfo = keyInfoTypeED;

            //---------------------------------------
            //Assign to EncryptedElementType
            encryptedElementType.EncryptedData = encryptedDataType;
            //encryptedElementType.EncryptedKey = new EncryptedKeyType[] { ekType };
            return encryptedElementType;
        }

        #region Private Methods


        /// <summary>
        /// Signs an XML Document for a Saml Response
        /// </summary>
        /// <param name="xml"></param>
        /// <param name="cert2"></param>
        /// <param name="referenceId"></param>
        /// <returns></returns>
        private XmlElement GetSignatureElement(XmlDocument doc, X509Certificate2 cert2, string referenceId, string referenceValue)
        {
            SamlSignedXml sig = new SamlSignedXml(doc, referenceId);
            // Add the key to the SignedXml xmlDocument. 
            sig.SigningKey = cert2.PrivateKey;

            // Create a reference to be signed. 
            Reference reference = new Reference();

            reference.Uri = String.Empty;
            reference.Uri = "#" + referenceValue;

            // Add an enveloped transformation to the reference. 
            XmlDsigEnvelopedSignatureTransform env = new
                XmlDsigEnvelopedSignatureTransform();
            XmlDsigC14NTransform env2 = new XmlDsigC14NTransform();

            reference.AddTransform(env);
            reference.AddTransform(env2);

            // Add the reference to the SignedXml object. 
            sig.AddReference(reference);

            // Add an RSAKeyValue KeyInfo (optional; helps recipient find key to validate). 
            KeyInfo keyInfo = new KeyInfo();
            KeyInfoX509Data keyData = new KeyInfoX509Data(cert2);

            keyInfo.AddClause(keyData);

            sig.KeyInfo = keyInfo;

            // Compute the signature. 
            sig.ComputeSignature();

            // Get the XML representation of the signature and save it to an XmlElement object. 
            XmlElement xmlDigitalSignature = sig.GetXml();

            return xmlDigitalSignature;
        }

        #endregion

    }
}
