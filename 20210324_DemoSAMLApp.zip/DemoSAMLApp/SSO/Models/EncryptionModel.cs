﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SSO.Models
{
    public class EncryptionModel
    {
        public string EncryptionKeyMethod { get; set; }
        public string EncryptionDataMethod { get; set; }
    }
}
