﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using Security.Saml20;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
using System.Security.Cryptography.Xml;

namespace SSO
{
    public class SAMLDocumentModel
    {
        private XmlDocument _XmlDocument;
        private string _RequestResponse = "";

        private bool _isResponse = false;
        private bool _IsValidSAML = false;
        private Dictionary<string, string> _Attributes;

        private SSOTenantDetail _SSOTenantDetail;
        private AuthnRequestType _authnRequest;
        private string _Status = "";
        private CertificateInfo _Certificate;
        private IEnumerable<AttributeType> _AssertionAttributes;
        private ResponseType _ResponseType;
        private AssertionType _AssertionType;
        private EncryptedElementType _EncryptedElementType;
        private EncryptedDataType _EncryptedDataType;
        private SignedInfoType _SignedInfo;
        private SignedInfoType _AssertionSignedInfo;
        private SignedInfoType _EncryptedAssertionSignedInfo;
        private string _EncryptionMethodKey;
        private string _EncryptionMethodData;
        private string _ResponseMethod { get; set; }
        #region public Porperties


        public XmlDocument XmlDocument { get { return _XmlDocument; } set { _XmlDocument = value; } }
        public string RequestResponse { get { return _RequestResponse; } set { _RequestResponse = value; } }

        public string Status { get { return _Status; } set { _Status = value; } }

        public CertificateInfo CertificateInfo { get { return _Certificate; } set { _Certificate = value; } }
        public Dictionary<string, string> Attributes { get { return _Attributes; } set { _Attributes = value; } }
        public IEnumerable<AttributeType> AssertionAttributes { get { return _AssertionAttributes; } set { _AssertionAttributes = value; } }

        public string ResponseMethod
        {
            get { return _ResponseMethod; }
            set { _ResponseMethod = value; }
        }

        public bool IsValidSAML
        {
            get { return _IsValidSAML; }
            set { _IsValidSAML = value; }
        }
        public AuthnRequestType AuthnRequest
        {
            get { return _authnRequest; }
            set { _authnRequest = value; }
        }
        public bool IsResponse
        {
            get { return _isResponse; }
            set { _isResponse = value; }
        }

        public EncryptedElementType EncryptedElementType
        {
            get { return _EncryptedElementType; }
            set { _EncryptedElementType = value; }
        }

        public EncryptedDataType EncryptedDataType
        {
            get { return _EncryptedDataType; }
            set { _EncryptedDataType = value; }
        }

        public string EncryptionMethodKey
        {
            get { return _EncryptionMethodKey; }
            set { _EncryptionMethodKey = value; }
        }

        public string EncryptionMethodData
        {
            get { return _EncryptionMethodData; }
            set { _EncryptionMethodData = value; }
        }

        public SignedInfoType SignedInfo
        {
            get { return _SignedInfo; }
            set { _SignedInfo = value; }
        }

        public SignedInfoType AssertionSignedInfo
        {
            get { return _AssertionSignedInfo; }
            set { _AssertionSignedInfo = value; }
        }

        public ResponseType ResponseType
        {
            get { return _ResponseType; }
            set { _ResponseType = value; }
        }


        public SSOTenantDetail TenantDetail
        {
            get { return _SSOTenantDetail; }
            set { _SSOTenantDetail = value; }

        }

        public bool HasAssertion
        {
            get
            {
                if (_AssertionType != null)
                    return true;
                else return false;
            }
        }

        public bool HasEncryptedAssertion
        {
            get
            {
                if (_EncryptedElementType != null)
                    return true;
                else return false;
            }
        }

        public bool HasEncryptedData
        {
            get
            {
                if (_EncryptedDataType != null)
                    return true;
                else return false;
            }
        }

        public bool HasSignedInfo
        {
            get
            {
                if (_SignedInfo != null)
                    return true;
                else return false;
            }
        }

        public bool HasAssertionSignedInfo
        {
            get
            {
                if (_AssertionSignedInfo != null)
                    return true;
                else return false;
            }
        }

        public bool HasEncryptedAssertionSignedInfo
        {
            get
            {
                if (_EncryptedAssertionSignedInfo != null)
                    return true;
                else return false;
            }
        }

        public bool HasResponseType
        {
            get
            {
                if (_ResponseType != null)
                    return true;
                else return false;
            }
        }
        #endregion


        #region Public Methods

        public void DecodeFromResponse()
        {
            if (this.XmlDocument == null)
            {
                if (this._SSOTenantDetail != null)
                    this.XmlDocument = SAMLHelper.Base64ToXmlDocument(_RequestResponse, this._SSOTenantDetail.EncodingMethod);
            }
            if (this.XmlDocument != null)
            {
                //Get Response 
                _ResponseType = SAMLHelper.GetSAMLResponseType(this.XmlDocument.OuterXml);

                //Get Assertions
                _AssertionType = SAMLHelper.GetSAMLAssertionType(_ResponseType);
                _EncryptedElementType = SAMLHelper.GetSAMLEncryptedElementType(_ResponseType);
                _EncryptedDataType = SAMLHelper.GetSAMLEncryptedData(_EncryptedElementType);

                //Get Signatures
                _SignedInfo = SAMLHelper.GetSAMLSignedInfoType(_ResponseType);
                _AssertionSignedInfo = SAMLHelper.GetSAMLAssertionSignedInfoType(_AssertionType);

                //Get Encryption Methods
                _EncryptionMethodData = SAMLHelper.GetEncryptionMethodData(_EncryptedDataType);
                _EncryptionMethodKey = SAMLHelper.GetEncryptionMethodData(_EncryptedDataType);

                _ResponseMethod = SAMLHelper.GetResponseMethod(this);
            }
        }

        /// <summary>
        /// Gets the bytes 
        /// </summary>
        /// <returns></returns>
        public byte[] GetBytes()
        {
            try
            {
                return SAMLHelper.GetEncoding(TenantDetail.EncodingMethod).GetBytes(this.XmlDocument.OuterXml);
            }
            catch (Exception)
            {

            }
            return null;

        }
        /// <summary>
        /// Gets the Base 64 string for XmlDocument
        /// </summary>
        /// <returns></returns>
        public string GetBase64String()
        {
            try
            {
                return System.Convert.ToBase64String(GetBytes());
            }
            catch (Exception)
            {
                return string.Empty;
            }

        }

        /// <summary>
        /// Clones the current object
        /// </summary>
        /// <returns></returns>
        public SAMLDocumentModel Clone()
        {
            try
            {
                IFormatter formatter = new BinaryFormatter();
                using (var stream = new MemoryStream())
                {
                    formatter.Serialize(stream, this);
                    stream.Seek(0, SeekOrigin.Begin);
                    return (SAMLDocumentModel)formatter.Deserialize(stream);
                }
            }
            catch (Exception)
            {

            }
            return this;
        }


        #endregion
    }
}
