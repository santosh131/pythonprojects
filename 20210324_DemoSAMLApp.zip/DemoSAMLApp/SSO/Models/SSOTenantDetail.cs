﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SSO
{
    public class SSOTenantDetail
    {
        private string _ProtocalBinding;
        public string _Domain = string.Empty;
        public string _Subject = string.Empty;

        public string TenantId { get; set; }
        public string CertificateIssueNbr { get; set; }
        public string CertificateFileName { get; set; }
        public string CertificateFilePassword { get; set; }
        /// <summary>
        /// Gets or Sets IdpUrl (Destination)
        /// </summary>
        public string Destination { get; set; }
        /// <summary>
        /// Gets or Sets SPUrl (AssertionConsumerServiceURL)
        /// </summary>
        public string AssertionConsumerServiceURL { get; set; }

        public string Issuer { get; set; }

        public string SAMLResponseMethod { get; set; }

        public string EncodingMethod { get; set; }

        public string EncryptionKeyAlgorithm { get; set; }

        public string EncryptionDataAlgorithm { get; set; }

        public string Domain
        {
            get
            { 
                return _Domain;
            }
            set { _ProtocalBinding = value; }
        }
        public string Subject
        {
            get
            {

                return _Subject;
            }
            set { _Subject = value; }
        }
        public string ProtocalBinding
        {
            get
            {
                if (string.IsNullOrEmpty(_ProtocalBinding))
                    return "urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST";
                return _ProtocalBinding;
            }
            set { _ProtocalBinding = value; }
        }
    }
}
