﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Security.Cryptography.X509Certificates;

namespace SSO
{
   public class CertificateInfo
    {
       public string IssueNbr { get; set; }
       public string FileName { get; set; }
       public string Password { get; set; }
       public bool HasCertificate { get; set; }
       public StoreName StoreName { get; set; }
       public StoreLocation StoreLocation { get; set; }
       public X509Certificate2 ServerCertificate { get; set; }
       public X509FindType X509FindType { get; set; }
    }
}
