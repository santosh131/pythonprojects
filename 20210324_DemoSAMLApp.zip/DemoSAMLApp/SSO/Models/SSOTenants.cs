﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SSO
{
    public static class SSOTenants
    {
        private static List<SSOTenantDetail> _tenantDetails { get; set; }

        public static void RegisterTenant(SSOTenantDetail tenantDetail)
        {
            if (_tenantDetails == null)
                _tenantDetails = new List<SSOTenantDetail>();
            _tenantDetails.Add(tenantDetail);
        }

        public static void ClearTenants()
        {
            _tenantDetails = new List<SSOTenantDetail>();
        }


        public static List<SSOTenantDetail> TenantDetails
        {
            get
            {
                return _tenantDetails;
            }
        }
    }
}
