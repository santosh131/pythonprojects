﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Security.Saml20;
using System.Xml;
using System.Security.Cryptography.X509Certificates;
using System.IO;
using System.Xml.Serialization;

namespace SSO
{
    public abstract class BaseSAML
    {
        #region Public Properties
        public bool IsOperation { get; set; }
        public string OperationFailedMessage { get; set; }

        public SAMLDocumentModel SAMLModel { get; set; }
        public SAMLDocumentModel OutputSAMLRequest { get; set; }
        public SAMLDocumentModel OutputSAMLResponse { get; set; }

        #endregion

        #region Public Abstract

        public abstract SAMLDocumentModel CreateRequest();
        public abstract SAMLDocumentModel CreateResponse();

        public abstract SAMLDocumentModel ReadRequest();
        public abstract SAMLDocumentModel ReadResponse();

        public abstract bool VerifySignRequestDoc();
        public abstract bool VerifySignResponseDoc();
        public abstract bool VerifySignDoc(XmlDocument doc, X509Certificate2 cert);

        public abstract AssertionType CreateSamlAssertion();
        public abstract EncryptedElementType CreateEncryptionSamlAssertion();

        #endregion
    }
}
