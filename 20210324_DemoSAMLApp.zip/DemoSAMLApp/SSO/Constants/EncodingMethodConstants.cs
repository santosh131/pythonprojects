﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SSO.Constants
{
    public static class EncodingMethodConstants
    {        
        public const string ASCII = "ASCII";
        public const string Default = "Default";
        public const string Unicode = "Unicode";
        public const string UTF7 = "UTF7";
        public const string UTF8 = "UTF8";
        public const string UTF32 = "UTF32";
    }
}
