﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SSO.Constants
{
   public static class EncryptionKeyConstants
    {
       public const string RSA_1_5 = "rsa-1-5";
       public const string RSA_OAEP_MGF1P = "rsa-oaep-mgf1p";
    }
}
