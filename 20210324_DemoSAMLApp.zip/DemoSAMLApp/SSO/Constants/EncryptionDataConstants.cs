﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SSO.Constants
{
   public static class EncryptionDataConstants
    {
       public const string TRIPLEDES_CBC = "tripledes-cbc";
       public const string AES128_CBC = "aes128-cbc";
       public const string AES192_CBC = "aes192-cbc";
       public const string AES256_CBC = "aes256-cbc"; 
    }
}
