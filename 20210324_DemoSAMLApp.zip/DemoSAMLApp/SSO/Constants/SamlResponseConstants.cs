﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SSO.Constants
{
    public class SamlResponseConstants
    {
        public const string UnsignedSAMlUnsignedAssertion = "UnsignedSAMlUnsignedAssertion";
        public const string UnsignedSAMlSignedAssertion = "UnsignedSAMlSignedAssertion";
        public const string SignedSAMlUnsignedAssertion = "SignedSAMlUnsignedAssertion";
        public const string SignedSAMlSignedAssertion = "SignedSAMlSignedAssertion";
        public const string UnsignedSAMlEncryptedAssertion = "UnsignedSAMlEncryptedAssertion";
        public const string UnsignedSAMlEncryptedSignedAssertion = "UnsignedSAMlEncryptedSignedAssertion";
        public const string SignedSAMlEncryptedAssertion = "SignedSAMlEncryptedAssertion";
        public const string SignedSAMlEncryptedSignedAssertion = "SignedSAMlEncryptedSignedAssertion";
    }
}
