﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SSO.Models;
using SSO.Constants;
using SSO.Encryption.EncryptData;
using SSO.Encryption.EncryptKey;
using System.Security.Cryptography.Xml;

namespace SSO.Encryption
{
    public class BaseEncryption : IEncryption
    {
        public EncryptionModel EncryptionModel { get; set; }

        public BaseEncryption()
        {

        }
        public BaseEncryption(EncryptionModel encryptionModel)
        {
            EncryptionModel = encryptionModel;
        }

        /// <summary>
        /// Gets the Base Encryption Data
        /// </summary>
        /// <returns>BaseEncryptionData</returns>
        public BaseEncryptionData GetBaseEncryptionData()
        {
            //if (EncryptionModel.EncryptionDataMethod == EncryptionDataConstants.TRIPLEDES_CBC)
            //{
            //    return new TRIPLEDES_CBC();
            //}
            //if (EncryptionModel.EncryptionDataMethod == EncryptionDataConstants.AES128_CBC)
            //{
            //    return new AES128_CBC();
            //}
            //if (EncryptionModel.EncryptionDataMethod == EncryptionDataConstants.AES192_CBC)
            //{
            //    return new AES192_CBC();
            //}
            if (EncryptionModel.EncryptionDataMethod == EncryptedXml.XmlEncAES256Url)
            {
                return new AES256_CBC();
            }
            return null;
        }

        /// <summary>
        /// Gets the Base Encryption Key
        /// </summary>
        /// <returns>BaseEncryptionKey</returns>
        public BaseEncryptionKey GetBaseEncryptionKey()
        {
            if (EncryptionModel.EncryptionKeyMethod == EncryptionKeyConstants.RSA_1_5)
            {
                return new RSA_1_5();
            }
            else if (EncryptionModel.EncryptionKeyMethod == EncryptionKeyConstants.RSA_OAEP_MGF1P)
            {
                return new RSA_OAEP_MGF1P();
            }
            return null;
        }
        
    }
}
