﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Security.Cryptography;

namespace SSO.Encryption.EncryptData
{
    public class AES192_CBC : BaseEncryptionData
    {
        public override byte[] Encrypt(byte[] plainBytes, byte[] secretKey)
        {
            throw new NotImplementedException();
        }

        public override byte[] Decrypt(byte[] encryptedBytes, byte[] secretKey)
        {
            throw new NotImplementedException();
        }

        public override string Encrypt(string plainText, string secretKey)
        {
            throw new NotImplementedException();
        }

        public override string Decrypt(string encryptedText, string secretKey)
        {
            throw new NotImplementedException();
        }

        public override RijndaelManaged CreateSymmetricKey()
        {
            throw new NotImplementedException();
        }
    }
}
