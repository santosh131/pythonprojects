﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Security.Cryptography;
using System.IO;
using System.Xml;
using System.Security.Cryptography.Xml;
using Security.Saml20;

namespace SSO.Encryption.EncryptData
{
    public class AES256_CBC : BaseEncryptionData
    {
        //public override byte[] Encrypt(byte[] plainBytes, byte[] secretKey)
        //{
        //    throw new NotImplementedException();
        //}

        //public override byte[] Decrypt(byte[] encryptedBytes, byte[] secretKey)
        //{
        //    throw new NotImplementedException();
        //}

        //public override string Encrypt(string plainText, string secretKey)
        //{
        //    byte[] cipherData;
        //    Aes aes = Aes.Create();
        //    aes.Key = Encoding.UTF8.GetBytes(secretKey);
        //    aes.GenerateIV();
        //    aes.Mode = CipherMode.CBC;
        //    ICryptoTransform cipher = aes.CreateEncryptor(aes.Key, aes.IV);

        //    using (MemoryStream ms = new MemoryStream())
        //    {
        //        using (CryptoStream cs = new CryptoStream(ms, cipher, CryptoStreamMode.Write))
        //        {
        //            using (StreamWriter sw = new StreamWriter(cs))
        //            {
        //                sw.Write(plainText);
        //            }
        //        }

        //        cipherData = ms.ToArray();
        //    }

        //    byte[] combinedData = new byte[aes.IV.Length + cipherData.Length];
        //    Array.Copy(aes.IV, 0, combinedData, 0, aes.IV.Length);
        //    Array.Copy(cipherData, 0, combinedData, aes.IV.Length, cipherData.Length);
        //    return Convert.ToBase64String(combinedData);
        //}

        //public override string Decrypt(string encryptedText, string secretKey)
        //{
        //    string plainText;
        //    byte[] combinedData = Convert.FromBase64String(encryptedText);
        //    Aes aes = Aes.Create();
        //    aes.Key = Encoding.UTF8.GetBytes(secretKey);
        //    byte[] iv = new byte[aes.BlockSize / 8];
        //    byte[] cipherText = new byte[combinedData.Length - iv.Length];
        //    Array.Copy(combinedData, iv, iv.Length);
        //    Array.Copy(combinedData, iv.Length, cipherText, 0, cipherText.Length);
        //    aes.IV = iv;
        //    aes.Mode = CipherMode.CBC;
        //    ICryptoTransform decipher = aes.CreateDecryptor(aes.Key, aes.IV);

        //    using (MemoryStream ms = new MemoryStream(cipherText))
        //    {
        //        using (CryptoStream cs = new CryptoStream(ms, decipher, CryptoStreamMode.Read))
        //        {
        //            using (StreamReader sr = new StreamReader(cs))
        //            {
        //                plainText = sr.ReadToEnd();
        //            }
        //        }

        //        return plainText;
        //    }
        //}

        public override RijndaelManaged CreateSymmetricKey()
        {
            // create symmetric key
            var key = new RijndaelManaged();
            key.BlockSize = 128;
            key.KeySize = 256;
            key.Padding = PaddingMode.ISO10126;
            key.Mode = CipherMode.CBC;

            return key;
        }

        /// <summary>
        /// Encrypts the data using symmetric key
        /// </summary>
        /// <param name="assertionXMLDoc"></param>
        /// <param name="namespaceManager"></param>
        public override byte[] Encrypt(XmlDocument assertionXMLDoc, out RijndaelManaged rijndaelManaged)
        {
            rijndaelManaged = CreateSymmetricKey();
            EncryptedXml eXml = new EncryptedXml();

            return eXml.EncryptData(assertionXMLDoc.DocumentElement, rijndaelManaged, false);

        }

        /// <summary>
        /// Encrypts the data using symmetric key
        /// </summary>
        /// <param name="assertionXMLDoc"></param>
        /// <param name="namespaceManager"></param>
        public override XmlDocument Decrypt(SAMLDocumentModel samlModel, byte[] key)
        {
            EncryptedXml eXml = new EncryptedXml();
            var rijndaelManaged = CreateSymmetricKey();
            rijndaelManaged.Key = key;

            XmlDocument xDoc = samlModel.XmlDocument;
            XmlElement encryptedElement = null;
            XmlElement encryptedAssertionElement = null; 

            try
            {
                //encryptedElement = xDoc.GetElementsByTagName("EncryptedData")[0] as XmlElement;
                //if (encryptedElement==null)
                //encryptedElement = xDoc.GetElementsByTagName("xenc:EncryptedData","http://www.w3.org/2001/04/xmlenc#")[0] as XmlElement;
                encryptedElement = xDoc.GetElementsByTagName("EncryptedData", EncryptedXml.XmlEncNamespaceUrl)[0] as XmlElement;
                encryptedAssertionElement = xDoc.GetElementsByTagName("EncryptedAssertion")[0] as XmlElement; 
            }
            catch (Exception)
            {

            }

            // Create an EncryptedData object and populate it.
            EncryptedData edElement = new EncryptedData();
            edElement.LoadXml(encryptedElement);            

            edElement.EncryptionMethod = new EncryptionMethod(samlModel.TenantDetail.EncryptionDataAlgorithm);


            byte[] output = eXml.DecryptData(edElement, rijndaelManaged);
            // Replace the encryptedData element with the plaintext XML element.
            eXml.ReplaceData(encryptedAssertionElement, output);
            return xDoc;
             
        }


        /// <summary>
        /// Encrypts the data using symmetric key
        /// </summary>
        /// <param name="assertionXMLDoc"></param>
        /// <param name="namespaceManager"></param>
        public override byte[] EncryptWithString(XmlDocument assertionXMLDoc, string secretKey)
        {
            var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(secretKey);


            //AesCryptoServiceProvider aesSP = new AesCryptoServiceProvider();
            byte[] combinedData = plainTextBytes;// Convert.FromBase64String(secretKey);
            Aes aes = Aes.Create();
            aes.Key = Encoding.UTF8.GetBytes(secretKey);
            byte[] iv = new byte[aes.BlockSize / 8];
            byte[] cipherText = new byte[combinedData.Length - iv.Length];
            Array.Copy(combinedData, iv, iv.Length);
            Array.Copy(combinedData, iv.Length, cipherText, 0, cipherText.Length);
            aes.IV = iv;
            aes.Mode = CipherMode.CBC;

            EncryptedXml eXml = new EncryptedXml();

            return eXml.EncryptData(assertionXMLDoc.DocumentElement, aes, false);

        }

        /// <summary>
        /// Encrypts the data using symmetric key
        /// </summary>
        /// <param name="assertionXMLDoc"></param>
        /// <param name="namespaceManager"></param>
        public override XmlDocument DecryptWithString(EncryptedData encryptedData, string secretKey, SAMLDocumentModel samlModel)
        {
            var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(secretKey);
            byte[] combinedData = plainTextBytes;
            Aes aes = Aes.Create();
            aes.Key = Encoding.UTF8.GetBytes(secretKey);
            byte[] iv = new byte[aes.BlockSize / 8];
            byte[] cipherText = new byte[combinedData.Length - iv.Length];
            Array.Copy(combinedData, iv, iv.Length);
            Array.Copy(combinedData, iv.Length, cipherText, 0, cipherText.Length);
            aes.IV = iv;
            aes.Mode = CipherMode.CBC;

            EncryptedXml eXml = new EncryptedXml();
            encryptedData.EncryptionMethod = new EncryptionMethod(samlModel.TenantDetail.EncryptionDataAlgorithm);

            byte[] output = eXml.DecryptData(encryptedData, aes);
            XmlDocument xDoc = samlModel.XmlDocument;
            XmlElement encryptedElement = xDoc.GetElementsByTagName("EncryptedData")[0] as XmlElement;
            // Create an EncryptedData object and populate it.
            EncryptedData edElement = new EncryptedData();
            edElement.LoadXml(encryptedElement);

            // Replace the encryptedData element with the plaintext XML element.
            eXml.ReplaceData(encryptedElement, output);
           
            return xDoc;
        }
    }
}
