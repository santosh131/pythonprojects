﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Security.Cryptography;
using System.Xml;
using System.Security.Cryptography.Xml;

namespace SSO.Encryption
{
    public abstract class BaseEncryptionData
    {
        //public abstract byte[] Encrypt(byte[] plainBytes, byte[] secretKey);
      //  public abstract byte[] Decrypt(byte[] encryptedBytes, byte[] secretKey);

        //public abstract string Encrypt(string plainText, string secretKey);
       // public abstract string Decrypt(string encryptedText, string secretKey);

        public abstract RijndaelManaged CreateSymmetricKey();
        public abstract byte[] Encrypt(XmlDocument assertionXMLDoc,out RijndaelManaged rijndaelManaged);
        public abstract XmlDocument Decrypt(SAMLDocumentModel samlModel, byte[] key);

        public abstract byte[] EncryptWithString(XmlDocument assertionXMLDoc, string secretKey);
        public abstract XmlDocument DecryptWithString(EncryptedData encryptedData, string secretKey, SAMLDocumentModel samlModel);
    }
}
