﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Security.Saml20;
using System.Security.Cryptography.X509Certificates;

namespace SSO.Encryption
{
    public abstract class BaseEncryptionKey
    {
        /// <summary>
        /// RSA Encrypt
        /// </summary>
        /// <param name="encryptedKeyType"></param>
        /// <param name="cer"></param>
        /// <returns></returns>
        /// <remarks>rsa-oaep-mgf1p</remarks>
        public abstract byte[] Encrypt(byte[] plainObject, X509Certificate2 cer, string encodingMethod);

        /// <summary>
        /// RSA Decrypt
        /// </summary>
        /// <param name="encryptedKeyType"></param>
        /// <param name="cer"></param>
        /// <returns></returns>
        /// <remarks>rsa-oaep-mgf1p</remarks>
        public abstract byte[] Decrypt(byte[] encryptedObject, X509Certificate2 cer, string encodingMethod);


    }
}
