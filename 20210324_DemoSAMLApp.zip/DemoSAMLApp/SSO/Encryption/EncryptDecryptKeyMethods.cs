﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Security.Cryptography;
using Security.Saml20;
using System.Security.Cryptography.X509Certificates;

namespace SSO
{
    public class EncryptDecryptKeyMethods
    {
        /// <summary>
        /// RSA Encrypt
        /// </summary>
        /// <param name="encryptedKeyType"></param>
        /// <param name="cer"></param>
        /// <returns></returns>
        /// <remarks>rsa-oaep-mgf1p</remarks>
        public static string RSAEncrypt(EncryptedKeyType encryptedKeyType, X509Certificate2 cer)
        {
            //Create a UnicodeEncoder to convert between byte array and string.
            UnicodeEncoding ByteConverter = new UnicodeEncoding();

            byte[] dataToEncrypt = encryptedKeyType.CipherData.Item as byte[];
            RSACryptoServiceProvider rsa = (RSACryptoServiceProvider)cer.PrivateKey;
            byte[] d = rsa.Encrypt(dataToEncrypt, true);
            return Encoding.ASCII.GetString(d);
        } 

        /// <summary>
        /// RSA Decrypt
        /// </summary>
        /// <param name="encryptedKeyType"></param>
        /// <param name="cer"></param>
        /// <returns></returns>
        /// <remarks>rsa-oaep-mgf1p</remarks>
        public static string RSADecrypt(EncryptedKeyType encryptedKeyType, X509Certificate2 cer)
        {
            byte[] data = encryptedKeyType.CipherData.Item as byte[];             
            RSACryptoServiceProvider rsa = (RSACryptoServiceProvider)cer.PrivateKey;            
            byte[] d = rsa.Decrypt(data, true);            
            return  Encoding.ASCII.GetString(d);
        }

        /// <summary>
        /// RSA Encrypt
        /// </summary>
        /// <param name="encryptedKeyType"></param>
        /// <param name="cer"></param>
        /// <returns></returns>
        /// <remarks>rsa-oaep-mgf1p</remarks>
        public static byte[] RSAEncryptToBytes(EncryptedKeyType encryptedKeyType, X509Certificate2 cer)
        {
            //Create a UnicodeEncoder to convert between byte array and string.
            UnicodeEncoding ByteConverter = new UnicodeEncoding();

            byte[] dataToEncrypt = encryptedKeyType.CipherData.Item as byte[];
            RSACryptoServiceProvider rsa = (RSACryptoServiceProvider)cer.PrivateKey;
            return  rsa.Encrypt(dataToEncrypt, true);
        }

        /// <summary>
        /// RSA Decrypt
        /// </summary>
        /// <param name="encryptedKeyType"></param>
        /// <param name="cer"></param>
        /// <returns></returns>
        /// <remarks>rsa-oaep-mgf1p</remarks>
        public static byte[] RSADecryptToBytes(EncryptedKeyType encryptedKeyType, X509Certificate2 cer)
        {
            byte[] data = encryptedKeyType.CipherData.Item as byte[];
            RSACryptoServiceProvider rsa = (RSACryptoServiceProvider)cer.PrivateKey;
            return rsa.Decrypt(data, true);
        } 
         
    }
}
