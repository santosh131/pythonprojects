﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Security.Saml20;
namespace SSO.Encryption.EncryptKey
{
    public class RSA_1_5 : BaseEncryptionKey
    {
        public override byte[] Encrypt(byte[] plainObject, System.Security.Cryptography.X509Certificates.X509Certificate2 cer, string encodingMethod)
        {
            throw new NotImplementedException();
        }

        public override byte[] Decrypt(byte[] encryptedObject, System.Security.Cryptography.X509Certificates.X509Certificate2 cer, string encodingMethod)
        {
            throw new NotImplementedException();
        }
    }
}
