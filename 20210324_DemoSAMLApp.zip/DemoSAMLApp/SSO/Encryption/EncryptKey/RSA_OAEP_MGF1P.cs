﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Security.Saml20;
using System.Security.Cryptography.X509Certificates;
using System.Security.Cryptography;

namespace SSO.Encryption.EncryptKey
{
    public class RSA_OAEP_MGF1P :BaseEncryptionKey
    {
        /// <summary>
        /// RSA Encrypt
        /// </summary>
        /// <param name="encryptedKeyType"></param>
        /// <param name="cer"></param>
        /// <returns></returns>
        /// <remarks>rsa-oaep-mgf1p</remarks>
        public override byte[] Encrypt(byte[] plainObject, X509Certificate2 cer, string encodingMethod)
        {
            //Create a UnicodeEncoder to convert between byte array and string.
            UnicodeEncoding ByteConverter = new UnicodeEncoding();

           // byte[] dataToEncrypt = plainObject as byte[];
            RSACryptoServiceProvider rsa = cer.PublicKey.Key as RSACryptoServiceProvider;
            return rsa.Encrypt(plainObject, true);
        }

        /// <summary>
        /// RSA Decrypt
        /// </summary>
        /// <param name="encryptedKeyType"></param>
        /// <param name="cer"></param>
        /// <returns></returns>
        /// <remarks>rsa-oaep-mgf1p</remarks>
        public override byte[] Decrypt(byte[] encryptedObject, X509Certificate2 cer, string encodingMethod)
        {
            byte[] data = encryptedObject as byte[];
            RSACryptoServiceProvider rsa = (RSACryptoServiceProvider)cer.PrivateKey;
           return rsa.Decrypt(data, true);            
        }

    }
}
