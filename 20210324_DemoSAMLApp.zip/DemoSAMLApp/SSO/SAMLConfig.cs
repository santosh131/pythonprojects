﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SSO
{
     [Serializable]
    public class SAMLConfig
    {
        private string _name;

        public string name
        {
            get { return _name; }
            set { _name = value; }
        }

        private string _caption;

        public string caption
        {
            get { return _caption; }
            set { _caption = value; }
        }

        private string _issuer;

        public string issuer
        {
            get { return _issuer; }
            set { _issuer = value; }
        }

        private string _destination;

        public string destination
        {
            get { return _destination; }
            set { _destination = value; }
        }

        private string _spurl;

        public string spurl
        {
            get { return _spurl; }
            set { _spurl = value; }
        }

        private string _certificatevalue;

        public string certificatevalue
        {
            get { return _certificatevalue; }
            set { _certificatevalue = value; }
        }

        private string _certificatename;

        public string certificatename
        {
            get { return _certificatename; }
            set { _certificatename = value; }
        }


        private string _certificatepassword;

        public string certificatepassword
        {
            get { return _certificatepassword; }
            set { _certificatepassword = value; }
        }

        public Dictionary<string, string> attrs { get; set; }

        private string _samlmethod;

        public string samlmethod
        {
            get { return _samlmethod; }
            set { _samlmethod = value; }
        }

        private string _tenantId;

        public string TenantId
        {
            get { return _tenantId; }
            set { _tenantId = value; }
        }
        


        public SAMLConfig Fill(SSOTenantDetail ssoTenantDetail)
        {
            _certificatename = ssoTenantDetail.CertificateFileName;
            _certificatepassword= ssoTenantDetail.CertificateFilePassword;
            _certificatevalue= ssoTenantDetail.CertificateIssueNbr;
            _destination= ssoTenantDetail.IdpUrl;
            _spurl= ssoTenantDetail.SPUrl;
            _tenantId= ssoTenantDetail.TenantId;
            _issuer = ssoTenantDetail.Issuer;
            _samlmethod = ssoTenantDetail.SAMlMethod;
            return this;
        }
    }
}
