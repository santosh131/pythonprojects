﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;
using Security.Saml20;
using System.IO;
using System.Xml;
using System.Security.Cryptography.X509Certificates;
using SSO.Methods;
using SSO.Constants;

namespace SSO
{
    public class SAMLConcrete : ISAML
    {
        public SAMLDocumentModel SAMLModel { get; set; }
        public SAMLConcrete()
        {

        }
        //public SAMLConcrete(SAMLDocumentModel samlModel)
        //{
        //    this.SAMLModel = samlModel;
        //}
        //public XmlDocument LoadFromSAMLModel(SAMLDocumentModel samlModel)
        //{
        //    XmlDocument doc = new XmlDocument();
        //    if (!string.IsNullOrEmpty(this.SAMLModel.RequestResponse))
        //    {
        //        byte[] bytes = Convert.FromBase64String(this.SAMLModel.RequestResponse);
        //        string ReqResStr = Encoding.UTF8.GetString(bytes);
        //        doc.LoadXml(ReqResStr);
        //        if (!samlModel.IsResponse)
        //        {
        //            this.SAMLModel.AuthnRequest = SAMLHelper.GetElementDeserialized<AuthnRequestType>(ReqResStr);
        //        }
        //        this.SAMLModel.XmlDocument = doc;
        //    }
        //    return doc;
        //}

        /// <summary>
        /// Gets the BaseSAML is based on config
        /// </summary>
        /// <param name="config"></param>
        /// <returns>BaseSAML</returns>
        /// <remarks>Used in Service Provider server </remarks>
        public BaseSAML GetBaseSAML()
        {
            this.SAMLModel.DecodeFromResponse();

            BaseSAML baseSaml = null;
            string respMethod = this.SAMLModel.ResponseMethod;
            if (string.IsNullOrEmpty(respMethod))
              respMethod=  this.SAMLModel.TenantDetail.SAMLResponseMethod.ToLower();

            if (respMethod == SamlResponseConstants.UnsignedSAMlUnsignedAssertion.ToLower())
            {
                baseSaml = new UnsignedSAMlUnsignedAssertion(this.SAMLModel);
            }
            else if (respMethod == SamlResponseConstants.SignedSAMlUnsignedAssertion.ToLower())
            {
                baseSaml = new SignedSAMLUnsignedAssertion(this.SAMLModel);
            }
            else if (respMethod == SamlResponseConstants.UnsignedSAMlSignedAssertion.ToLower())
            {
                baseSaml = new UnsignedSAMlSignedAssertion(this.SAMLModel);
            }
            else if (respMethod == SamlResponseConstants.SignedSAMlSignedAssertion.ToLower())
            {
                baseSaml = new SignedSAMlSignedAssertion(this.SAMLModel);
            }
            else if (respMethod == SamlResponseConstants.UnsignedSAMlEncryptedAssertion.ToLower())
            {
                baseSaml = new UnsignedSAMlEncryptedAssertion(this.SAMLModel);
            }
            return baseSaml;
        }


    }
}
