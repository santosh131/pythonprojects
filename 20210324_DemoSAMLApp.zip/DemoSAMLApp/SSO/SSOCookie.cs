﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Web;

namespace SSO
{
    public static class SSOCookie
    {
        public static string SSOCookieName = ConfigurationManager.AppSettings["CookieName"] + "SSO";
        /// <summary>
        /// Sets the value to the cookie
        /// </summary>
        /// <param name="cookieVal">cookieVal</param>
        /// <remarks></remarks>
        public static void SetSSOCookie(string cookieVal, ref HttpRequest request, ref HttpResponse response)
        {
            var cookieOld = GetCookie(ref request);
            if (cookieOld!=null)
            {
                cookieOld.Expires = new DateTime(1900, 1, 1);
                response.Cookies.Remove(SSOCookieName);
            }

            var cookie = new HttpCookie(SSOCookieName);
            cookie.Expires = DateTime.Now.AddDays(5);
            cookie.Value = cookieVal;
            response.Cookies.Add(cookie);
        }

        /// <summary>
        /// Gets the cookie
        /// </summary>
        /// <returns></returns>
        /// <remarks></remarks>
        public static HttpCookie GetCookie(ref HttpRequest request)
        {
            return request.Cookies[SSOCookieName];
        }

        /// <summary>
        /// Removes the cookie
        /// </summary>
        /// <returns></returns>
        /// <remarks></remarks>
        public static void RemoveCookie(ref HttpRequest request, ref HttpResponse response)
        {
            var cookieOld = GetCookie(ref request);
            if (cookieOld != null)
            {
                cookieOld.Expires = new DateTime(1900, 1, 1);
                response.Cookies.Remove(SSOCookieName);
            }

            var cookie = new HttpCookie(SSOCookieName);
            cookie.Expires = DateTime.Now.AddDays(-1);
            cookie.Value = "";
            response.Cookies.Add(cookie);
        }
    }
}
